import React, { useState } from 'react';
import { 
  ArrowLeft, 
  MoreVertical, 
  Heart, 
  MessageCircle, 
  Send, 
  Repeat2, 
  Bookmark, 
  Info,
  Play
} from 'lucide-react';
import { 
  ResponsiveContainer, 
  LineChart, 
  Line, 
  XAxis, 
  YAxis, 
  Tooltip, 
  CartesianGrid 
} from 'recharts';

// Mock data for Views over time chart
const viewsOverTimeData = [
  { time: '0', hours: 0, views: 0, typical: 0 },
  { time: '2h', hours: 2, views: 250, typical: 200, comparison: '41% lower than typical' },
  { time: '4h', hours: 4, views: 796, typical: 500, comparison: '62% higher than typical' },
  { time: '6h', hours: 6, views: 1445, typical: 800, comparison: '65% higher than typical' },
  { time: '8h', hours: 8, views: 1570, typical: 900, comparison: '176% higher than typical' },
  { time: '11h', hours: 11, views: 3794, typical: 1200, comparison: '157% higher than typical' },
  { time: '14h', hours: 14, views: 3800, typical: 1400, comparison: '154% higher than typical' },
  { time: '18h', hours: 18, views: 3800, typical: 1300 },
  { time: '22h', hours: 22, views: 3800, typical: 2800 },
];

// Mock data for Video Retention chart
const retentionData = [
  { timeSec: 0, timeLabel: '0:00', retention: 100 },
  { timeSec: 5, timeLabel: '0:05', retention: 55 },
  { timeSec: 10, timeLabel: '0:10', retention: 30 },
  { timeSec: 15, timeLabel: '0:15', retention: 12 },
  { timeSec: 20, timeLabel: '0:20', retention: 7 },
  { timeSec: 30, timeLabel: '0:30', retention: 4 },
  { timeSec: 49, timeLabel: '0:49', retention: 3.5 },
  { timeSec: 97, timeLabel: '1:37', retention: 3 },
];

// Mock data for Likes interaction chart (sharp peaks using linear type)
const likesInteractionData = [
  { time: '0:00', val: 0 },
  { time: '0:02', val: 33 },
  { time: '0:04', val: 0 },
  { time: '0:06', val: 18 },
  { time: '0:08', val: 33 },
  { time: '0:10', val: 0 },
  { time: '0:15', val: 18 },
  { time: '0:20', val: 5 },
  { time: '0:30', val: 18 },
  { time: '0:44', val: 0 },
  { time: '1:37', val: 0 },
];

export default function ReelInsightsDashboard() {
  const [viewFilter, setViewFilter] = useState('All');
  const [audienceTab, setAudienceTab] = useState('Gender');

  const [viewsIndex, setViewsIndex] = useState(undefined);
  const [retentionIndex, setRetentionIndex] = useState(undefined);
  const [likesIndex, setLikesIndex] = useState(undefined);

  return (
    <div className="min-h-screen bg-[#121212] text-white font-sans flex justify-center pb-12 select-none">
      <div className="w-full max-w-[430px] bg-[#121212] min-h-screen flex flex-col border-x border-zinc-900 shadow-2xl">
        
        {/* Top Header */}
        <div className="flex items-center justify-between px-4 py-3 sticky top-0 bg-[#121212]/95 backdrop-blur z-20 border-b border-zinc-900/50">
          <div className="flex items-center space-x-4">
            <button className="text-white hover:text-zinc-300 transition-colors">
              <ArrowLeft className="w-6 h-6" />
            </button>
            <h1 className="text-lg font-semibold tracking-tight">Reel insights</h1>
          </div>
          <button className="text-white hover:text-zinc-300 transition-colors">
            <MoreVertical className="w-5 h-5" />
          </button>
        </div>

        {/* Video Thumbnail & Details */}
        <div className="px-4 pt-3 pb-4 border-b border-zinc-800/60">
          <div className="flex flex-col items-center">
            <div className="w-[110px] h-[195px] rounded-xl overflow-hidden bg-zinc-800 shadow-lg relative border border-white/10">
              <img 
                src="https://images.unsplash.com/photo-1514525253161-7a46d19cd819?q=80&w=400&auto=format&fit=crop" 
                alt="Reel thumbnail" 
                className="w-full h-full object-cover"
              />
              <div className="absolute inset-0 flex items-center justify-center bg-black/20">
                <div className="w-8 h-8 rounded-full bg-black/60 flex items-center justify-center backdrop-blur-sm">
                  <Play className="w-4 h-4 text-white fill-white ml-0.5" />
                </div>
              </div>
            </div>
            
            <p className="text-xs text-zinc-300 text-center mt-3 px-2 line-clamp-1">
              Brantley Gilbert celebrated the release of his 8th studio album "SINS OF...
            </p>
            <p className="text-[11px] text-zinc-500 mt-1">
              October 15 · Duration 1:38
            </p>
          </div>

          {/* Engagement Icons Row */}
          <div className="grid grid-cols-5 gap-2 mt-5 px-4 text-center">
            <div className="flex flex-col items-center space-y-1">
              <Heart className="w-5 h-5 text-white stroke-[2]" />
              <span className="text-xs font-medium text-zinc-200">6</span>
            </div>
            <div className="flex flex-col items-center space-y-1">
              <MessageCircle className="w-5 h-5 text-white stroke-[2]" />
              <span className="text-xs font-medium text-zinc-200">4</span>
            </div>
            <div className="flex flex-col items-center space-y-1">
              <Send className="w-5 h-5 text-white stroke-[2]" />
              <span className="text-xs font-medium text-zinc-200">0</span>
            </div>
            <div className="flex flex-col items-center space-y-1">
              <Repeat2 className="w-5 h-5 text-white stroke-[2]" />
              <span className="text-xs font-medium text-zinc-200">0</span>
            </div>
            <div className="flex flex-col items-center space-y-1">
              <Bookmark className="w-5 h-5 text-white stroke-[2]" />
              <span className="text-xs font-medium text-zinc-200">0</span>
            </div>
          </div>
        </div>

        {/* Overview Section */}
        <div className="px-4 py-4 border-b border-zinc-800/60">
          <div className="flex items-center space-x-1.5 mb-3">
            <h2 className="text-sm font-semibold text-zinc-200">Overview</h2>
            <Info className="w-3.5 h-3.5 text-zinc-400" />
          </div>
          <div className="space-y-3">
            <div className="flex justify-between items-center text-sm">
              <span className="text-zinc-300">Views</span>
              <span className="font-semibold text-white">5,139</span>
            </div>
            <div className="flex justify-between items-center text-sm">
              <span className="text-zinc-300">Watch time</span>
              <span className="font-semibold text-white">2h 2m 36s</span>
            </div>
            <div className="flex justify-between items-center text-sm">
              <span className="text-zinc-300">Interactions</span>
              <span className="font-semibold text-white">10</span>
            </div>
            <div className="flex justify-between items-center text-sm">
              <span className="text-zinc-300">Profile activity</span>
              <span className="font-semibold text-white">0</span>
            </div>
          </div>
        </div>

        {/* Views & Donut Chart Section */}
        <div className="px-4 py-5 border-b border-zinc-800/60 flex flex-col items-center">
          <div className="w-full flex items-center justify-start space-x-1.5 mb-2">
            <h2 className="text-sm font-semibold text-zinc-200">Views</h2>
            <Info className="w-3.5 h-3.5 text-zinc-400" />
          </div>

          <div className="relative w-48 h-48 my-2 flex items-center justify-center">
            <svg className="w-full h-full transform -rotate-90" viewBox="0 0 100 100">
              <circle
                cx="50"
                cy="50"
                r="40"
                fill="transparent"
                stroke="#8a2be2"
                strokeWidth="8"
                strokeDasharray="251.2"
                strokeDashoffset="0"
                strokeLinecap="round"
              />
            </svg>
            <div className="absolute inset-0 flex flex-col items-center justify-center text-center">
              <span className="text-[11px] text-zinc-400 tracking-wide">Views</span>
              <span className="text-2xl font-bold tracking-tight mt-0.5">5,139</span>
            </div>
          </div>

          <div className="w-full space-y-2 mt-3 px-2">
            <div className="flex items-center justify-between text-xs">
              <div className="flex items-center space-x-2">
                <div className="w-2 h-2 rounded-full bg-[#d946ef]"></div>
                <span className="text-zinc-300">Followers</span>
              </div>
              <span className="text-zinc-300 font-medium">0.0%</span>
            </div>
            <div className="flex items-center justify-between text-xs">
              <div className="flex items-center space-x-2">
                <div className="w-2 h-2 rounded-full bg-[#8a2be2]"></div>
                <span className="text-zinc-300">Non-followers</span>
              </div>
              <span className="text-zinc-300 font-medium">100.0%</span>
            </div>
          </div>
        </div>

        {/* Views Over Time Section */}
        <div className="px-4 py-5 border-b border-zinc-800/60">
          <h2 className="text-sm font-semibold text-zinc-200 mb-3">Views over time</h2>
          
          <div className="flex space-x-2 mb-4">
            {['All', 'Followers', 'Non-followers'].map((tab) => (
              <button
                key={tab}
                onClick={() => setViewFilter(tab)}
                className={`px-4 py-1.5 rounded-full text-xs font-medium transition-all ${
                  viewFilter === tab 
                    ? 'bg-zinc-200 text-black font-semibold' 
                    : 'bg-[#262626] text-zinc-300 hover:bg-zinc-700'
                }`}
              >
                {tab}
              </button>
            ))}
          </div>

          <div 
            className="h-44 w-full mt-2 relative"
            onTouchEnd={() => setViewsIndex(undefined)}
            onTouchCancel={() => setViewsIndex(undefined)}
          >
            <ResponsiveContainer width="100%" height="100%">
              <LineChart 
                data={viewsOverTimeData} 
                margin={{ top: 32, right: 10, left: -25, bottom: 0 }}
                activeIndex={viewsIndex}
                onMouseMove={(state) => {
                  if (state && state.activeTooltipIndex !== undefined) {
                    setViewsIndex(state.activeTooltipIndex);
                  }
                }}
                onTouchMove={(state) => {
                  if (state && state.activeTooltipIndex !== undefined) {
                    setViewsIndex(state.activeTooltipIndex);
                  }
                }}
                onMouseLeave={() => setViewsIndex(undefined)}
              >
                <CartesianGrid strokeDasharray="3 3" stroke="#262626" vertical={false} />
                <XAxis dataKey="time" stroke="#71717a" fontSize={10} tickLine={false} axisLine={false} />
                <YAxis stroke="#71717a" fontSize={10} tickLine={false} axisLine={false} ticks={[0, 2000, 4000]} />
                <Tooltip 
                  isAnimationActive={false}
                  cursor={{ stroke: '#ffffff', strokeWidth: 1, strokeDasharray: 'none' }}
                  position={{ y: 0 }}
                  active={viewsIndex !== undefined}
                  content={({ active, payload }) => {
                    if (active && payload && payload.length) {
                      const data = payload[0].payload;
                      return (
                        <div className="transform -translate-x-1/2 pointer-events-none">
                          <div className="bg-[#1e1e1e] text-white px-3.5 py-1.5 rounded-lg text-xs shadow-2xl border border-white/10 flex flex-col items-center whitespace-nowrap">
                            <span className="font-bold text-xs">{data.views} views</span>
                            {data.comparison && <span className="text-zinc-400 text-[10px]">{data.comparison}</span>}
                          </div>
                        </div>
                      );
                    }
                    return null;
                  }} 
                />
                <Line 
                  type="monotone" 
                  dataKey="views" 
                  stroke="#d946ef" 
                  strokeWidth={2.5} 
                  dot={false}
                  activeDot={viewsIndex !== undefined ? { r: 5, fill: '#d946ef', stroke: '#fff', strokeWidth: 2 } : false} 
                />
                <Line 
                  type="monotone" 
                  dataKey="typical" 
                  stroke="#71717a" 
                  strokeWidth={2} 
                  strokeDasharray="4 4" 
                  dot={false} 
                  activeDot={false}
                />
              </LineChart>
            </ResponsiveContainer>
          </div>

          <div className="flex items-center justify-center space-x-6 mt-3 text-[11px] text-zinc-400">
            <div className="flex items-center space-x-1.5">
              <div className="w-2 h-2 rounded-full bg-[#d946ef]"></div>
              <span>This reel</span>
            </div>
            <div className="flex items-center space-x-1.5">
              <div className="w-2 h-2 rounded-full bg-zinc-500"></div>
              <span>Your typical reel views</span>
            </div>
          </div>
        </div>

        {/* Top Sources of Views Section */}
        <div className="px-4 py-5 border-b border-zinc-800/60">
          <h2 className="text-sm font-semibold text-zinc-200 mb-4">Top sources of views</h2>
          <div className="space-y-3.5">
            <div>
              <div className="flex justify-between text-xs mb-1.5">
                <span className="text-zinc-300">Reels tab</span>
                <span className="font-semibold text-white">51.5%</span>
              </div>
              <div className="w-full bg-[#262626] h-1.5 rounded-full overflow-hidden">
                <div className="bg-[#d946ef] h-full rounded-full" style={{ width: '51.5%' }}></div>
              </div>
            </div>
            <div>
              <div className="flex justify-between text-xs mb-1.5">
                <span className="text-zinc-300">Profile</span>
                <span className="font-semibold text-white">33.8%</span>
              </div>
              <div className="w-full bg-[#262626] h-1.5 rounded-full overflow-hidden">
                <div className="bg-[#d946ef] h-full rounded-full" style={{ width: '33.8%' }}></div>
              </div>
            </div>
            <div>
              <div className="flex justify-between text-xs mb-1.5">
                <span className="text-zinc-300">Explore</span>
                <span className="font-semibold text-white">14.7%</span>
              </div>
              <div className="w-full bg-[#262626] h-1.5 rounded-full overflow-hidden">
                <div className="bg-[#d946ef] h-full rounded-full" style={{ width: '14.7%' }}></div>
              </div>
            </div>
            <div className="flex justify-between items-center text-xs pt-2">
              <span className="text-zinc-300">Viewers</span>
              <span className="font-semibold text-white">1,168</span>
            </div>
          </div>
        </div>

        {/* Retention Section */}
        <div className="px-4 py-5 border-b border-zinc-800/60">
          <div className="flex items-center space-x-1.5 mb-3">
            <h2 className="text-sm font-semibold text-zinc-200">Retention</h2>
            <Info className="w-3.5 h-3.5 text-zinc-400" />
          </div>

          <div className="flex justify-center my-3">
            <div className="w-[100px] h-[175px] rounded-xl overflow-hidden bg-zinc-800 shadow-md border border-white/10 relative">
              <img 
                src="https://images.unsplash.com/photo-1514525253161-7a46d19cd819?q=80&w=400&auto=format&fit=crop" 
                alt="Retention frame" 
                className="w-full h-full object-cover"
              />
              <div className="absolute inset-0 flex items-center justify-center bg-black/20">
                <div className="w-7 h-7 rounded-full bg-black/60 flex items-center justify-center backdrop-blur-sm">
                  <Play className="w-3.5 h-3.5 text-white fill-white ml-0.5" />
                </div>
              </div>
            </div>
          </div>

          <div 
            className="h-32 w-full mt-2 relative"
            onTouchEnd={() => setRetentionIndex(undefined)}
            onTouchCancel={() => setRetentionIndex(undefined)}
          >
            <ResponsiveContainer width="100%" height="100%">
              <LineChart 
                data={retentionData} 
                margin={{ top: 32, right: 10, left: -25, bottom: 0 }}
                activeIndex={retentionIndex}
                onMouseMove={(state) => {
                  if (state && state.activeTooltipIndex !== undefined) {
                    setRetentionIndex(state.activeTooltipIndex);
                  }
                }}
                onTouchMove={(state) => {
                  if (state && state.activeTooltipIndex !== undefined) {
                    setRetentionIndex(state.activeTooltipIndex);
                  }
                }}
                onMouseLeave={() => setRetentionIndex(undefined)}
              >
                <CartesianGrid strokeDasharray="3 3" stroke="#262626" vertical={false} />
                <XAxis dataKey="timeLabel" stroke="#71717a" fontSize={10} tickLine={false} axisLine={false} />
                <YAxis stroke="#71717a" fontSize={10} tickLine={false} axisLine={false} ticks={[0, 50, 100]} />
                <Tooltip 
                  isAnimationActive={false}
                  cursor={{ stroke: '#ffffff', strokeWidth: 1, strokeDasharray: 'none' }}
                  position={{ y: 0 }}
                  active={retentionIndex !== undefined}
                  content={({ active, payload }) => {
                    if (active && payload && payload.length) {
                      const data = payload[0].payload;
                      return (
                        <div className="transform -translate-x-1/2 pointer-events-none">
                          <div className="bg-[#1e1e1e] text-white px-3 py-1 rounded-lg text-xs shadow-2xl border border-white/10 flex flex-col items-center whitespace-nowrap">
                            <span className="font-bold text-xs">{data.retention}%</span>
                            <span className="text-zinc-400 text-[10px]">{data.timeLabel}</span>
                          </div>
                        </div>
                      );
                    }
                    return null;
                  }} 
                />
                <Line 
                  type="monotone" 
                  dataKey="retention" 
                  stroke="#d946ef" 
                  strokeWidth={2} 
                  dot={false}
                  activeDot={retentionIndex !== undefined ? { r: 5, fill: '#d946ef', stroke: '#fff', strokeWidth: 2 } : false} 
                />
              </LineChart>
            </ResponsiveContainer>
          </div>

          <div className="space-y-2 mt-4 pt-2 border-t border-zinc-900">
            <div className="flex justify-between text-xs">
              <span className="text-zinc-300">This reel's skip rate</span>
              <span className="font-semibold text-white">4.0%</span>
            </div>
            <div className="flex justify-between text-xs">
              <span className="text-zinc-300">Your typical skip rate</span>
              <span className="font-semibold text-white">0.7%</span>
            </div>
          </div>
        </div>

        {/* Interactions & Donut Chart Section */}
        <div className="px-4 py-5 border-b border-zinc-800/60 flex flex-col items-center">
          <div className="w-full flex items-center justify-start space-x-1.5 mb-2">
            <h2 className="text-sm font-semibold text-zinc-200">Interactions</h2>
            <Info className="w-3.5 h-3.5 text-zinc-400" />
          </div>

          <div className="relative w-48 h-48 my-2 flex items-center justify-center">
            <svg className="w-full h-full transform -rotate-90" viewBox="0 0 100 100">
              <circle
                cx="50"
                cy="50"
                r="40"
                fill="transparent"
                stroke="#8a2be2"
                strokeWidth="8"
                strokeDasharray="251.2"
                strokeDashoffset="0"
                strokeLinecap="round"
              />
            </svg>
            <div className="absolute inset-0 flex flex-col items-center justify-center text-center">
              <span className="text-[11px] text-zinc-400 tracking-wide">Interactions</span>
              <span className="text-2xl font-bold tracking-tight mt-0.5">10</span>
            </div>
          </div>

          <div className="w-full space-y-2 mt-3 px-2">
            <div className="flex items-center justify-between text-xs">
              <div className="flex items-center space-x-2">
                <div className="w-2 h-2 rounded-full bg-[#d946ef]"></div>
                <span className="text-zinc-300">Followers</span>
              </div>
              <span className="text-zinc-300 font-medium">0.0%</span>
            </div>
            <div className="flex items-center justify-between text-xs">
              <div className="flex items-center space-x-2">
                <div className="w-2 h-2 rounded-full bg-[#8a2be2]"></div>
                <span className="text-zinc-300">Non-followers</span>
              </div>
              <span className="text-zinc-300 font-medium">100.0%</span>
            </div>
          </div>
        </div>

        {/* When People Liked Your Reel Section */}
        <div className="px-4 py-5 border-b border-zinc-800/60">
          <h2 className="text-sm font-semibold text-zinc-200 mb-3">When people liked your reel</h2>

          <div className="flex justify-center my-3">
            <div className="w-[100px] h-[175px] rounded-xl overflow-hidden bg-zinc-800 shadow-md border border-white/10 relative">
              <img 
                src="https://images.unsplash.com/photo-1514525253161-7a46d19cd819?q=80&w=400&auto=format&fit=crop" 
                alt="Likes frame" 
                className="w-full h-full object-cover"
              />
              <div className="absolute inset-0 flex items-center justify-center bg-black/20">
                <div className="w-7 h-7 rounded-full bg-black/60 flex items-center justify-center backdrop-blur-sm">
                  <Play className="w-3.5 h-3.5 text-white fill-white ml-0.5" />
                </div>
              </div>
            </div>
          </div>

          <div 
            className="h-32 w-full mt-2 relative"
            onTouchEnd={() => setLikesIndex(undefined)}
            onTouchCancel={() => setLikesIndex(undefined)}
          >
            <ResponsiveContainer width="100%" height="100%">
              <LineChart 
                data={likesInteractionData} 
                margin={{ top: 32, right: 10, left: -25, bottom: 0 }}
                activeIndex={likesIndex}
                onMouseMove={(state) => {
                  if (state && state.activeTooltipIndex !== undefined) {
                    setLikesIndex(state.activeTooltipIndex);
                  }
                }}
                onTouchMove={(state) => {
                  if (state && state.activeTooltipIndex !== undefined) {
                    setLikesIndex(state.activeTooltipIndex);
                  }
                }}
                onMouseLeave={() => setLikesIndex(undefined)}
              >
                <CartesianGrid strokeDasharray="3 3" stroke="#262626" vertical={false} />
                <XAxis dataKey="time" stroke="#71717a" fontSize={10} tickLine={false} axisLine={false} />
                <YAxis stroke="#71717a" fontSize={10} tickLine={false} axisLine={false} ticks={[0, 20, 40]} />
                <Tooltip 
                  isAnimationActive={false}
                  cursor={{ stroke: '#ffffff', strokeWidth: 1, strokeDasharray: 'none' }}
                  position={{ y: 0 }}
                  active={likesIndex !== undefined}
                  content={({ active, payload }) => {
                    if (active && payload && payload.length) {
                      const data = payload[0].payload;
                      return (
                        <div className="transform -translate-x-1/2 pointer-events-none">
                          <div className="bg-[#1e1e1e] text-white px-3 py-1 rounded-lg text-xs shadow-2xl border border-white/10 flex flex-col items-center whitespace-nowrap">
                            <span className="font-bold text-xs">{data.val}%</span>
                            <span className="text-zinc-400 text-[10px]">{data.time}</span>
                          </div>
                        </div>
                      );
                    }
                    return null;
                  }} 
                />
                <Line 
                  type="linear" 
                  dataKey="val" 
                  stroke="#d946ef" 
                  strokeWidth={2} 
                  dot={false}
                  activeDot={likesIndex !== undefined ? { r: 5, fill: '#d946ef', stroke: '#fff', strokeWidth: 2 } : false} 
                />
              </LineChart>
            </ResponsiveContainer>
          </div>

          <div className="space-y-3 mt-4 pt-3 border-t border-zinc-900">
            <div className="flex justify-between items-center text-sm">
              <span className="text-zinc-300">Likes</span>
              <span className="font-semibold text-white">6</span>
            </div>
            <div className="flex justify-between items-center text-sm">
              <span className="text-zinc-300">Comments</span>
              <span className="font-semibold text-white">4</span>
            </div>
            <div className="flex justify-between items-center text-sm">
              <span className="text-zinc-300">Reposts</span>
              <span className="font-semibold text-white">0</span>
            </div>
            <div className="flex justify-between items-center text-sm">
              <span className="text-zinc-300">Saves</span>
              <span className="font-semibold text-white">0</span>
            </div>
            <div className="flex justify-between items-center text-sm">
              <span className="text-zinc-300">Shares</span>
              <span className="font-semibold text-white">0</span>
            </div>
          </div>
        </div>

        {/* Profile Activity Section */}
        <div className="px-4 py-5 border-b border-zinc-800/60">
          <div className="flex items-center space-x-1.5 mb-3">
            <h2 className="text-sm font-semibold text-zinc-200">Profile activity</h2>
            <Info className="w-3.5 h-3.5 text-zinc-400" />
          </div>
          <div className="flex justify-between items-center text-sm">
            <span className="text-zinc-300">Follows</span>
            <span className="font-semibold text-white">0</span>
          </div>
        </div>

        {/* Audience Section */}
        <div className="px-4 py-5">
          <div className="flex items-center space-x-1.5 mb-3">
            <h2 className="text-sm font-semibold text-zinc-200">Audience</h2>
            <Info className="w-3.5 h-3.5 text-zinc-400" />
          </div>

          <div className="flex space-x-2 mb-4">
            {['Gender', 'Country', 'Age'].map((tab) => (
              <button
                key={tab}
                onClick={() => setAudienceTab(tab)}
                className={`px-4 py-1.5 rounded-full text-xs font-medium transition-all ${
                  audienceTab === tab 
                    ? 'bg-zinc-200 text-black font-semibold' 
                    : 'bg-[#262626] text-zinc-300 hover:bg-zinc-700'
                }`}
              >
                {tab}
              </button>
            ))}
          </div>

          {audienceTab === 'Gender' && (
            <div className="space-y-3">
              <div>
                <div className="flex justify-between text-xs mb-1.5">
                  <span className="text-zinc-300">Men</span>
                  <span className="font-semibold text-white">65.6%</span>
                </div>
                <div className="w-full bg-[#262626] h-1.5 rounded-full overflow-hidden">
                  <div className="bg-[#d946ef] h-full rounded-full" style={{ width: '65.6%' }}></div>
                </div>
              </div>
              <div>
                <div className="flex justify-between text-xs mb-1.5">
                  <span className="text-zinc-300">Women</span>
                  <span className="font-semibold text-white">34.4%</span>
                </div>
                <div className="w-full bg-[#262626] h-1.5 rounded-full overflow-hidden">
                  <div className="bg-[#8a2be2] h-full rounded-full" style={{ width: '34.4%' }}></div>
                </div>
              </div>
            </div>
          )}

          {audienceTab === 'Country' && (
            <div className="space-y-3">
              {[
                { country: 'Brazil', percent: '24.5%' },
                { country: 'Indonesia', percent: '17.4%' },
                { country: 'India', percent: '10.9%' },
                { country: 'United States', percent: '10.6%' },
                { country: 'Gabon', percent: '3.8%' }
              ].map((item, idx) => (
                <div key={idx}>
                  <div className="flex justify-between text-xs mb-1.5">
                    <span className="text-zinc-300">{item.country}</span>
                    <span className="font-semibold text-white">{item.percent}</span>
                  </div>
                  <div className="w-full bg-[#262626] h-1.5 rounded-full overflow-hidden">
                    <div className="bg-[#d946ef] h-full rounded-full" style={{ width: item.percent }}></div>
                  </div>
                </div>
              ))}
            </div>
          )}

          {audienceTab === 'Age' && (
            <div className="space-y-2.5">
              {[
                { range: '13-17', percent: '1.1%' },
                { range: '18-24', percent: '12.1%' },
                { range: '25-34', percent: '54.8%' },
                { range: '35-44', percent: '17.9%' },
                { range: '45-54', percent: '9.4%' },
                { range: '55-64', percent: '4.5%' },
                { range: '65+', percent: '0.3%' }
              ].map((item, idx) => (
                <div key={idx}>
                  <div className="flex justify-between text-xs mb-1.5">
                    <span className="text-zinc-300">{item.range}</span>
                    <span className="font-semibold text-white">{item.percent}</span>
                  </div>
                  <div className="w-full bg-[#262626] h-1.5 rounded-full overflow-hidden">
                    <div className="bg-[#d946ef] h-full rounded-full" style={{ width: item.percent }}></div>
                  </div>
                </div>
              ))}
            </div>
          )}

        </div>

      </div>
    </div>
  );
}
