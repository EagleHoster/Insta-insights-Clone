import React, { useState } from 'react';
import { 
  ArrowLeft, 
  MoreVertical, 
  Heart, 
  MessageCircle, 
  Send, 
  Repeat2, 
  Bookmark, 
  Info,
  Play,
  Dice5,
  RotateCw,
  Link as LinkIcon,
  Sliders,
  BarChart2,
  Activity,
  Cpu,
  Layers,
  Users
} from 'lucide-react';
import { 
  ResponsiveContainer, 
  LineChart, 
  Line, 
  XAxis, 
  YAxis, 
  Tooltip, 
  CartesianGrid 
} from 'recharts';

// ==========================================
// 15 PREBUILT SIMULATION PROFILES
// ==========================================
const SIMULATION_PROFILES = {
  viral_rocket: {
    name: '🚀 Viral Rocket (Explosive Growth)',
    desc: 'High push factor, minimal drop-off, aggressive first-hour burst.',
    config: { algorithmPushFactor: 2.8, weekendMultiplier: 1.8, chaosVolatility: 0.8, hookSeverityWeight: 1.5, decayPowerCoefficient: 0.5, midpointResonanceBoost: 3.5, spikeProbabilityThreshold: 0.35, viewsProfile: 'viral_burst', hasBadHook: false, hasDeadAir: false, isBoring: false }
  },
  shadowbanned: {
    name: '👻 Shadowbanned (Flatline Flat)',
    desc: 'Zero algorithm momentum, extreme flatline views, severe algorithmic throttling.',
    config: { algorithmPushFactor: 0.2, weekendMultiplier: 1.0, chaosVolatility: 0.4, hookSeverityWeight: 8.0, decayPowerCoefficient: 1.8, midpointResonanceBoost: 0.2, spikeProbabilityThreshold: 0.02, viewsProfile: 'slow_burn', hasBadHook: true, hasDeadAir: true, isBoring: true }
  },
  rollercoaster_ride: {
    name: '🎢 Rollercoaster Ride (Wild Fluctuations)',
    desc: 'Erratic volatility, unpredictable surges, and high jitter noise.',
    config: { algorithmPushFactor: 1.5, weekendMultiplier: 1.4, chaosVolatility: 2.9, hookSeverityWeight: 5.0, decayPowerCoefficient: 1.2, midpointResonanceBoost: 2.5, spikeProbabilityThreshold: 0.45, viewsProfile: 'rollercoaster', hasBadHook: true, hasDeadAir: false, isBoring: false }
  },
  slow_burn_sleeper: {
    name: '🌙 Slow Burn Sleeper (Delayed Pop)',
    desc: 'Flat early hours followed by a massive secondary algorithm pickup.',
    config: { algorithmPushFactor: 1.1, weekendMultiplier: 2.2, chaosVolatility: 0.9, hookSeverityWeight: 3.0, decayPowerCoefficient: 0.8, midpointResonanceBoost: 4.0, spikeProbabilityThreshold: 0.25, viewsProfile: 'slow_burn', hasBadHook: false, hasDeadAir: false, isBoring: false }
  },
  hook_disaster: {
    name: '❌ Hook Disaster (Immediate Drop)',
    desc: 'Catastrophic first 3-second abandonment rate and steep retention cliff.',
    config: { algorithmPushFactor: 0.8, weekendMultiplier: 1.1, chaosVolatility: 2.0, hookSeverityWeight: 9.5, decayPowerCoefficient: 1.9, midpointResonanceBoost: 0.5, spikeProbabilityThreshold: 0.05, viewsProfile: 'viral_burst', hasBadHook: true, hasDeadAir: true, isBoring: true }
  },
  loop_trap: {
    name: '🔁 Loop Trap (Infinite Retries)',
    desc: 'Flawless retention curve with rising engagement near the final seconds.',
    config: { algorithmPushFactor: 2.0, weekendMultiplier: 1.5, chaosVolatility: 0.5, hookSeverityWeight: 1.0, decayPowerCoefficient: 0.3, midpointResonanceBoost: 2.0, spikeProbabilityThreshold: 0.40, viewsProfile: 'viral_burst', hasBadHook: false, hasDeadAir: false, isBoring: false }
  },
  dead_air_purgatory: {
    name: '💤 Dead Air Purgatory (Mid-Video Slump)',
    desc: 'Pockets of empty silence causing rhythmic drop-offs throughout playback.',
    config: { algorithmPushFactor: 1.0, weekendMultiplier: 1.2, chaosVolatility: 1.7, hookSeverityWeight: 4.0, decayPowerCoefficient: 1.4, midpointResonanceBoost: 0.8, spikeProbabilityThreshold: 0.10, viewsProfile: 'slow_burn', hasBadHook: false, hasDeadAir: true, isBoring: true }
  },
  weekend_warrior: {
    name: '📅 Weekend Warrior (Saturday Surge)',
    desc: 'Massive multiplier spikes mimicking holiday and weekend traffic surges.',
    config: { algorithmPushFactor: 1.6, weekendMultiplier: 2.9, chaosVolatility: 1.2, hookSeverityWeight: 3.5, decayPowerCoefficient: 0.9, midpointResonanceBoost: 2.2, spikeProbabilityThreshold: 0.30, viewsProfile: 'viral_burst', hasBadHook: false, hasDeadAir: false, isBoring: false }
  },
  boring_lecture: {
    name: '📚 Boring Lecture (Linear Decay)',
    desc: 'Steady, unrelenting linear loss of audience interest from start to finish.',
    config: { algorithmPushFactor: 0.7, weekendMultiplier: 1.0, chaosVolatility: 0.6, hookSeverityWeight: 5.5, decayPowerCoefficient: 1.5, midpointResonanceBoost: 1.0, spikeProbabilityThreshold: 0.08, viewsProfile: 'slow_burn', hasBadHook: true, hasDeadAir: false, isBoring: true }
  },
  algorithmic_glitch: {
    name: '⚡ Algorithmic Glitch (Extreme Outlier)',
    desc: 'Unstable math constants, hyper-sensitive noise harmonics, and wild spikes.',
    config: { algorithmPushFactor: 3.0, weekendMultiplier: 2.0, chaosVolatility: 3.0, hookSeverityWeight: 2.0, decayPowerCoefficient: 0.4, midpointResonanceBoost: 5.0, spikeProbabilityThreshold: 0.50, viewsProfile: 'rollercoaster', hasBadHook: false, hasDeadAir: false, isBoring: false }
  },
  balanced_organic: {
    name: '⚖️ Balanced Organic (Standard Baseline)',
    desc: 'Default baseline representation of standard Instagram creator metrics.',
    config: { algorithmPushFactor: 1.2, weekendMultiplier: 1.35, chaosVolatility: 1.5, hookSeverityWeight: 4.0, decayPowerCoefficient: 0.9, midpointResonanceBoost: 1.8, spikeProbabilityThreshold: 0.18, viewsProfile: 'viral_burst', hasBadHook: true, hasDeadAir: true, isBoring: true }
  },
  micro_influencer: {
    name: '👥 Micro Influencer (High Follower Share)',
    desc: 'High follower retention bias, tight loyal community interaction ratios.',
    config: { algorithmPushFactor: 1.0, weekendMultiplier: 1.2, chaosVolatility: 1.0, hookSeverityWeight: 3.0, decayPowerCoefficient: 0.8, midpointResonanceBoost: 2.0, spikeProbabilityThreshold: 0.20, viewsProfile: 'viral_burst', hasBadHook: false, hasDeadAir: false, isBoring: false }
  },
  explore_tab_viral: {
    name: '🧭 Explore Tab Viral (Non-Follower Flood)',
    desc: 'Overwhelming non-follower reach pushed heavily through Explore and Feed.',
    config: { algorithmPushFactor: 2.5, weekendMultiplier: 1.7, chaosVolatility: 1.4, hookSeverityWeight: 2.5, decayPowerCoefficient: 0.6, midpointResonanceBoost: 3.0, spikeProbabilityThreshold: 0.30, viewsProfile: 'viral_burst', hasBadHook: false, hasDeadAir: false, isBoring: false }
  },
  mid_tier_slump: {
    name: '📉 Mid-Tier Slump (Decaying Momentum)',
    desc: 'Strong initial impression count followed by rapid algorithm abandonment.',
    config: { algorithmPushFactor: 1.3, weekendMultiplier: 1.1, chaosVolatility: 1.8, hookSeverityWeight: 4.5, decayPowerCoefficient: 1.6, midpointResonanceBoost: 0.9, spikeProbabilityThreshold: 0.12, viewsProfile: 'rollercoaster', hasBadHook: true, hasDeadAir: true, isBoring: false }
  },
  chaos_storm: {
    name: '🌪️ Chaos Storm (Maximum Stochastic Entropy)',
    desc: 'Maximum possible variance across every single Perlin noise parameter.',
    config: { algorithmPushFactor: 2.0, weekendMultiplier: 2.0, chaosVolatility: 3.0, hookSeverityWeight: 6.0, decayPowerCoefficient: 1.0, midpointResonanceBoost: 2.5, spikeProbabilityThreshold: 0.50, viewsProfile: 'rollercoaster', hasBadHook: true, hasDeadAir: true, isBoring: true }
  }
};

// ==========================================
// CENTRALIZED CONFIGURATION & GENERATOR STORE
// ==========================================
const DASHBOARD_CONFIG = {
  seed: 1357,
  regenSalt: 1,
  videoUrl: '',
  reel: {
    thumbnail: 'https://instagram.fdel27-1.fna.fbcdn.net/v/t51.82787-15/849272165_18204275209373634_3898613549013168554_n.jpg?stp=dst-jpg_e15_p240x240_tt6&_nc_cat=100&_nc_map=urlgen_bucketless&ig_cache_key=NDAwODkxMjg5NTcwNzYyMDczMTE4MjA0Mjc1MjA2MzczNjM0.3-ccb7-5&ccb=7-5&_nc_sid=58cdad&efg=eyJ2ZW5jb2RlX3RhZyI6IkNMSVBTLnhwaWRzLjU0MC5zZHIudmlkZW9fZGVmYXVsdF9jb3Zlcl9mcmFtZS5DMyJ9&_nc_ohc=tRRcY_nBSY4Q7kNvwHzHlDR&_nc_oc=AdolHgR6wCiKVhR4Dsj4a6M_gu2cYMpXdhCZKkn2bgBuvr-TuOPGVlG81me6Z-B9pDQ&_nc_zt=23&_nc_ht=instagram.fdel27-1.fna&_nc_gid=dQI8jCFdzBxs6MlTthISlg&_nc_ss=78a8c&oh=00_AQO_5nljVTOxkqjXyk7LyTfQIoHExTbKIvX7By1tA1_sYQ&oe=6AD99A5A',
    title: 'NO WAY THEY\'RE MAKING A WHOLE MUSIC VIDEO',
    date: 'October 16',
    duration: '0:20',
    likes: null,       
    comments: null,    
    shares: null,      
    reposts: null,     
    saves: null,       
    follows: null      
  },
  videoBehaviors: {
    hasBadHook: true,      
    hasDeadAir: true,      
    isBoring: true,        
    stochasticChance: 0.35, 
    chaosVolatility: 1.5,
    viewsProfile: 'viral_burst',
    algorithmPushFactor: 1.2,    
    audienceFatigueRate: 0.85,   
    hourlyJitterAmplitude: 0.008, 
    peakHourOffset: 8,           
    weekendMultiplier: 1.35,
    hookSeverityWeight: 4.0,
    midpointResonanceBoost: 1.8,
    decayPowerCoefficient: 0.9,
    spikeProbabilityThreshold: 0.18,
    noiseHarmonicFrequency: 0.08,
    audioTrackEnergyCoefficient: 1.0,
    visualCutFrequencyIndex: 1.0
  },
  overview: {
    views: 3101,
    instagramViews: null,
    facebookViews: null,
    watchTime: null,
    interactions: null,
    accountsReachedOverride: null,
    skipRateOverride: null,
    typicalSkipRateOverride: null
  },
  splitRatios: {
    targetFollowersMean: 0.001,  
    variance: 0.0,
    nonFollowerDecaySlope: 0.45,
    algorithmFeedWeight: 0.82
  },
  interactionSplitRatios: {
    targetFollowersMean: 0.0, 
    variance: 0.0
  },
  topSources: {
    'Reels tab': null,
    'Feed': null,
    'Explore': null,
    'Profile': null
  },
  audience: {
    gender: { 'Men': null, 'Women': null },
    countryPool: [
      { name: 'United States', weight: 10.0 },
      { name: 'United Kingdom', weight: 8.0 },
      { name: 'Canada', weight: 7.5 },
      { name: 'Australia', weight: 7.0 },
      { name: 'India', weight: 6.0 },
      { name: 'Germany', weight: 5.0 },
      { name: 'Brazil', weight: 4.5 },
      { name: 'France', weight: 4.5 },
      { name: 'Mexico', weight: 4.0 },
      { name: 'Philippines', weight: 4.0 },
      { name: 'Indonesia', weight: 3.5 },
      { name: 'Spain', weight: 3.5 },
      { name: 'Italy', weight: 3.5 },
      { name: 'Japan', weight: 3.0 },
      { name: 'South Korea', weight: 3.0 },
      { name: 'Pakistan', weight: 3.0 },
      { name: 'Netherlands', weight: 2.8 },
      { name: 'South Africa', weight: 2.8 },
      { name: 'Ireland', weight: 2.5 },
      { name: 'New Zealand', weight: 2.5 },
      { name: 'Turkey', weight: 2.5 },
      { name: 'Argentina', weight: 2.5 },
      { name: 'Nigeria', weight: 2.5 },
      { name: 'Malaysia', weight: 2.5 },
      { name: 'Saudi Arabia', weight: 2.3 },
      { name: 'United Arab Emirates', weight: 2.3 },
      { name: 'Sweden', weight: 2.2 },
      { name: 'Poland', weight: 2.2 },
      { name: 'Egypt', weight: 2.2 },
      { name: 'Thailand', weight: 2.0 },
      { name: 'Vietnam', weight: 2.0 },
      { name: 'Colombia', weight: 2.0 },
      { name: 'Chile', weight: 1.8 },
      { name: 'Portugal', weight: 1.8 },
      { name: 'Belgium', weight: 1.8 },
      { name: 'Switzerland', weight: 1.8 },
      { name: 'Norway', weight: 1.6 },
      { name: 'Denmark', weight: 1.6 },
      { name: 'Austria', weight: 1.6 },
      { name: 'Greece', weight: 1.5 },
      { name: 'Romania', weight: 1.5 },
      { name: 'Czech Republic', weight: 1.5 },
      { name: 'Peru', weight: 1.5 },
      { name: 'Bangladesh', weight: 1.5 },
      { name: 'Sri Lanka', weight: 1.5 },
      { name: 'Morocco', weight: 1.5 },
      { name: 'Ukraine', weight: 1.5 },
      { name: 'Israel', weight: 1.5 },
      { name: 'Kenya', weight: 1.5 }
    ],
    countries: [
      { country: 'United States', percentage: null },
      { country: null, percentage: null },
      { country: null, percentage: null },
      { country: null, percentage: null },
      { country: null, percentage: null }
    ],
    age: {
      '13-17': null, '18-24': null, '25-34': null, '35-44': null, '45-54': null, '55-64': null, '65+': null
    }
  },
  customProfilesStore: {
    slot1: null,
    slot2: null
  }
};

const createSeededRandom = (seed) => {
  let s = seed % 2147483647;
  if (s <= 0) s += 2147483646;
  return () => {
    s = (s * 16807) % 2147483647;
    return (s - 1) / 2147483646;
  };
};

const createSubtractivePerlinNoise1D = (seed) => {
  const rng = createSeededRandom(seed);
  const permutationSize = 256;
  const p = new Array(permutationSize * 2);
  const permutation = [];
  
  for (let i = 0; i < permutationSize; i++) permutation[i] = i;
  for (let i = permutationSize - 1; i > 0; i--) {
    const j = Math.floor(rng() * (i + 1));
    [permutation[i], permutation[j]] = [permutation[j], permutation[i]];
  }
  for (let i = 0; i < permutationSize; i++) {
    p[i] = permutation[i];
    p[permutationSize + i] = permutation[i];
  }

  const fade = (t) => t * t * t * (t * (t * 6 - 15) + 10);
  const lerp = (t, a, b) => a + t * (b - a);
  const grad = (hash, x) => (hash & 1 ? x : -x);

  return (x) => {
    const X = Math.floor(x) & 255;
    x -= Math.floor(x);
    const u = fade(x);
    const a = p[X];
    const b = p[X + 1];
    const raw = lerp(u, grad(p[a], x), grad(p[b], x - 1));
    return Math.abs(raw);
  };
};

// Stable object hashing utility to guarantee universal device cross-compatibility
const hashConfigState = (obj) => {
  const str = JSON.stringify(obj);
  let hash = 0;
  for (let i = 0; i < str.length; i++) {
    const char = str.charCodeAt(i);
    hash = (hash << 5) - hash + char;
    hash |= 0;
  }
  return Math.abs(hash);
};

const parseDurationToSeconds = (durationStr) => {
  if (!durationStr) return 60;
  const parts = durationStr.split(':').map(Number);
  if (parts.length === 2) return parts[0] * 60 + parts[1];
  if (parts.length === 1) return parts[0];
  return 60;
};

const formatSecondsToTimestamp = (sec) => {
  const mins = Math.floor(sec / 60);
  const secs = sec % 60;
  return `${mins}:${secs < 10 ? '0' : ''}${secs}`;
};

const formatCompactNumber = (num) => {
  if (num === null || num === undefined) return '0';
  if (num >= 1000000) {
    return (num / 1000000).toFixed(1).replace(/\.0$/, '') + 'M';
  }
  if (num >= 1000) {
    return (num / 1000).toFixed(1).replace(/\.0$/, '') + 'K';
  }
  return num.toString();
};

const generateWeightedRatio = (mean, variance, seed, behaviors, saltOffset) => {
  const behaviorHash = hashConfigState(behaviors);
  const combinedSeed = seed + behaviorHash + saltOffset;

  if (variance === 0) {
    const followersShare = Math.min(0.5, Math.max(0, mean));
    return {
      followersShare: Number(followersShare.toFixed(3)),
      nonFollowersShare: Number((1 - followersShare).toFixed(3))
    };
  }

  const rng = createSeededRandom(combinedSeed);
  const u1 = Math.max(0.001, rng());
  const u2 = rng();
  const gaussianRandom = Math.sqrt(-2.0 * Math.log(u1)) * Math.cos(2.0 * Math.PI * u2);
  
  const val = mean + gaussianRandom * variance;
  const followersShare = Math.min(0.5, Math.max(0, val));
  const nonFollowersShare = Number((1 - followersShare).toFixed(3));
  
  return {
    followersShare: Number(followersShare.toFixed(3)),
    nonFollowersShare: nonFollowersShare
  };
};

const generateOrganicVolatileRetention = (durationStr, seed, behaviors) => {
  const behaviorHash = hashConfigState(behaviors);
  const totalSeconds = parseDurationToSeconds(durationStr);
  const points = [];

  const badHookActive = behaviors.hasBadHook === true;
  const deadAirActive = behaviors.hasDeadAir === true;
  const boringActive = behaviors.isBoring === true;
  const baseVolatility = behaviors.chaosVolatility;
  const hookSeverity = behaviors.hookSeverityWeight || 4.0;
  const decayPower = behaviors.decayPowerCoefficient || 0.9;
  const spikeChance = behaviors.spikeProbabilityThreshold || 0.18;
  const jitterFreq = behaviors.hourlyJitterAmplitude || 0.008;
  const audioEnergy = behaviors.audioTrackEnergyCoefficient || 1.0;
  const cutFreq = behaviors.visualCutFrequencyIndex || 1.0;
  
  const lengthBonus = Math.max(0, Math.min(1.2, (50 - totalSeconds) / 33.33)); 
  
  let currentVal = 100.0;
  const junctionSec = Math.max(8, Math.floor(totalSeconds * 0.18));

  for (let sec = 0; sec <= totalSeconds; sec++) {
    // Pure indexed hash per second
    const secHash = Math.abs(Math.sin(seed + behaviorHash + sec * 12.9898) * 43758.5453) % 1;
    const secHash2 = Math.abs(Math.cos(seed + behaviorHash + sec * 78.233) * 43758.5453) % 1;

    const randomVariance = 0.9 + (secHash * 0.2); 
    const volatility = (baseVolatility + lengthBonus) * randomVariance * (1 / audioEnergy);

    if (sec === 0) {
      points.push({ time: formatSecondsToTimestamp(0), second: 0, retention: 100.0 });
      continue;
    }

    let dropAmount = 0.0;

    if (sec <= 6) {
      let initialDrop = badHookActive ? hookSeverity : 3.5;
      dropAmount = (initialDrop + secHash * 2.5) * volatility * cutFreq;
    } 
    else if (sec <= junctionSec) {
      const progress = (sec - 3) / (junctionSec - 3);
      let baseSpeed = 1.2;
      if (badHookActive) baseSpeed = hookSeverity * 0.5;
      
      dropAmount = (Math.pow(progress, decayPower) * baseSpeed + 0.3) * volatility * cutFreq;
    } else {
      const remainingSecs = totalSeconds - junctionSec;
      const elapsed = sec - junctionSec;
      const progress = elapsed / remainingSecs;

      const boringMultiplier = boringActive ? 2.0 : 1.0;
      const baseSlope = (Math.pow(progress, decayPower) * 0.4 * boringMultiplier + 0.05);
      const perlinSub = Math.abs(Math.sin((seed + behaviorHash + sec) * jitterFreq)) * 1.1 * volatility;
      
      let randomSpike = 0;
      if (secHash < spikeChance) {
        randomSpike = (secHash2 * 3.9 + 1.0) * volatility;
      }

      if (deadAirActive && secHash < 0.25 && sec % 8 === 0) {
        randomSpike += (secHash2 * 2.5 + 1.5) * volatility;
      }

      dropAmount = baseSlope * volatility + perlinSub + randomSpike;
    }

    currentVal = Math.max(0.5, currentVal - dropAmount);

    points.push({
      time: formatSecondsToTimestamp(sec),
      second: sec,
      retention: Number(currentVal.toFixed(1))
    });
  }

  return points;
};


const getDynamicTimeLabels = (reelDateStr) => {
  const currentYear = new Date().getFullYear();
  const uploadDate = new Date(`${reelDateStr}, ${currentYear} 00:00:00`);
  const now = new Date();

  const diffMs = now - uploadDate;
  const diffHours = Math.floor(diffMs / (1000 * 60 * 60));
  const diffDays = Math.floor(diffMs / (1000 * 60 * 60 * 24));

  let startLabel = reelDateStr;
  if (reelDateStr && reelDateStr.includes(' ')) {
    const [month, day] = reelDateStr.split(' ');
    startLabel = `${month.slice(0, 3)} ${day}`;
  }
  
  if (diffDays < 1) {
    startLabel = '0h';
  }

  let midLabel = '';
  if (diffHours <= 23) {
    midLabel = `${Math.max(1, diffHours)}h`;
  } else {
    midLabel = now.toLocaleDateString('en-US', { month: 'short', day: 'numeric' });
  }

  let endLabel = '';
  if (diffDays >= 1) {
    const doubledTimeMs = diffMs * 2;
    const endDate = new Date(uploadDate.getTime() + doubledTimeMs);
    endLabel = endDate.toLocaleDateString('en-US', { month: 'short', day: 'numeric' });
  } else {
    const doubledHours = Math.min(48, Math.max(2, diffHours * 2));
    endLabel = `${doubledHours}h`;
  }

  return {
    start: startLabel,
    mid: midLabel,
    end: endLabel,
    ticks: [startLabel, midLabel, endLabel]
  };
};

const generateAdvancedViewsOverTime = (targetTotalViews, seed, regenSalt, behaviors, reelDateStr, customCurveOverrides = []) => {
  const behaviorHash = hashConfigState(behaviors);
  
  const volatility = behaviors?.chaosVolatility || 1.0;
  const profile = behaviors?.viewsProfile || 'viral_burst';
  const pushFactor = behaviors?.algorithmPushFactor || 1.0;
  const weekendMult = behaviors?.weekendMultiplier || 1.0;
  const midpointBoost = behaviors?.midpointResonanceBoost || 1.8;
  const peakOffset = behaviors?.peakHourOffset || 8;
  
  const dynamicLabels = getDynamicTimeLabels(reelDateStr);
  const timeLabels = [
    dynamicLabels.start, '1h', '2h', '3h', '4h', '5h', '6h', dynamicLabels.mid, 
    '10h', '12h', '14h', '16h', '18h', '20h', dynamicLabels.end
  ];
  const midIndex = Math.min(timeLabels.length - 1, Math.max(1, peakOffset)); 
  
  let accumulatedViews = 0;
  let lastTypical = 0;

  return timeLabels.map((timeLabel, idx) => {
    // Pure indexed pseudo-random function based on seed + behaviorHash + index position
    const indexHash = Math.abs(Math.sin(seed + regenSalt + behaviorHash + idx * 99.7) * 10000) % 1;
    const indexHash2 = Math.abs(Math.cos(seed + regenSalt + behaviorHash + idx * 55.4) * 10000) % 1;

    const override = customCurveOverrides[idx] || {};
    const manualViews = override.views !== undefined && override.views !== null ? override.views : null;
    const manualTypical = override.typical !== undefined && override.typical !== null ? override.typical : null;

    if (idx === 0) {
      return { time: timeLabel, views: manualViews !== null ? manualViews : 0, typical: manualTypical !== null ? manualTypical : 0 };
    }
    
    if (idx > midIndex) {
      const upwardStep = Math.round(targetTotalViews * (0.03 + indexHash * 0.04) * pushFactor);
      lastTypical = Math.max(lastTypical, Math.min(Math.round(targetTotalViews * 1.1 * weekendMult), lastTypical + upwardStep));
      return { time: timeLabel, views: manualViews, typical: manualTypical !== null ? manualTypical : lastTypical };
    }

    if (idx === midIndex) {
      const upwardStep = Math.round(targetTotalViews * (0.05 + indexHash * 0.05) * pushFactor * midpointBoost * 0.5);
      lastTypical = Math.max(lastTypical, Math.min(Math.round(targetTotalViews * 0.85), lastTypical + upwardStep));
      return { time: timeLabel, views: manualViews !== null ? manualViews : targetTotalViews, typical: manualTypical !== null ? manualTypical : lastTypical };
    }

    const noiseVal = indexHash2;
    const stochasticEvent = indexHash < 0.35 ? indexHash * 0.25 * volatility : 0;
    
    let baseWeight = 0;
    if (profile === 'slow_burn') {
      baseWeight = (0.06 + noiseVal * 0.05 + stochasticEvent) * volatility * pushFactor;
    } else if (profile === 'rollercoaster') {
      const wave = Math.sin(idx * 0.5) * 0.1 + 0.1;
      baseWeight = (Math.max(0.01, wave + noiseVal * 0.05 + stochasticEvent)) * volatility * pushFactor;
    } else {
      const burstWindow = (idx >= 1 && idx <= 6) ? 0.18 : 0.05; 
      baseWeight = (burstWindow + noiseVal * 0.06 + stochasticEvent) * volatility * pushFactor;
    }

    let jump = Math.round(targetTotalViews * baseWeight * 0.5);
    accumulatedViews = Math.min(targetTotalViews - 50, accumulatedViews + Math.max(5, jump));
    
    const positiveJump = Math.max(0, jump); 
    const typicalJump = Math.max(1, Math.round(positiveJump * (0.25 + indexHash2 * 0.25) * weekendMult));
    lastTypical = Math.max(lastTypical + typicalJump, lastTypical);

    return {
      time: timeLabel,
      views: manualViews !== null ? manualViews : accumulatedViews,
      typical: manualTypical !== null ? manualTypical : lastTypical
    };
  });
};


const generateSecondsWiseLikesInteraction = (durationStr, seed, totalLikes, behaviors) => {
  const behaviorHash = hashConfigState(behaviors);
  const combinedSeed = seed + behaviorHash + 999;

  const rng = createSeededRandom(combinedSeed);
  const perlinNoise = createSubtractivePerlinNoise1D(combinedSeed + 55);
  const totalSeconds = parseDurationToSeconds(durationStr);
  const harmonicFreq = behaviors?.noiseHarmonicFrequency || 0.08;
  
  const likeCountsPerSecond = new Array(totalSeconds + 1).fill(0);
  let remainingLikes = totalLikes;

  const weights = new Array(totalSeconds + 1).fill(0);
  const finalSpikeSec = totalSeconds;
  const secondarySpikeSec = Math.floor(totalSeconds * (0.5 + rng() * 0.2));

  for (let sec = 0; sec <= totalSeconds; sec++) {
    const noiseVal = perlinNoise(sec * harmonicFreq);
    let w = noiseVal * 1.5 + 0.2; 

    if (sec <= 3) {
      w += (4 - sec) * 4.5;
    }

    const distToFinal = Math.abs(sec - finalSpikeSec);
    if (distToFinal <= 2) {
      w += (3 - distToFinal) * 6.0;
    }

    const distToMid = Math.abs(sec - secondarySpikeSec);
    if (distToMid <= 2) {
      w += (3 - distToMid) * 3.0;
    }

    weights[sec] = Math.max(0.01, w);
  }

  const totalWeight = weights.reduce((acc, w) => acc + w, 0);

  while (remainingLikes > 0) {
    let r = rng() * totalWeight;
    let cumulative = 0;
    let chosenSec = 0;

    for (let sec = 0; sec <= totalSeconds; sec++) {
      cumulative += weights[sec];
      if (r <= cumulative) {
        chosenSec = sec;
        break;
      }
    }

    likeCountsPerSecond[chosenSec] += 1;
    remainingLikes -= 1;
  }

  return likeCountsPerSecond.map((count, sec) => {
    const percentage = totalLikes > 0 ? Number(((count / totalLikes) * 100).toFixed(1)) : 0.0;
    return {
      time: formatSecondsToTimestamp(sec),
      second: sec,
      val: percentage
    };
  });
};

const processPercentageBreakdown = (obj, seed, behaviors, weights = {}, sortDescending = true, fixedKeysOrder = null, saltOffset = 100) => {
  const behaviorHash = hashConfigState(behaviors);
  const combinedSeed = seed + behaviorHash + saltOffset;

  const rng = createSeededRandom(combinedSeed);
  const keys = fixedKeysOrder || Object.keys(obj);
  const explicitEntries = Object.entries(obj).filter(([_, val]) => val !== null && val !== undefined);
  
  let explicitSum = explicitEntries.reduce((acc, [_, val]) => acc + Number(val), 0);
  const nullKeys = keys.filter(k => obj[k] === null || obj[k] === undefined);

  let result = {};

  if (nullKeys.length === 0) {
    const scale = 100 / explicitSum;
    keys.forEach(k => {
      result[k] = Number((obj[k] * scale).toFixed(1));
    });
  } else {
    let remaining = Math.max(0, 100 - explicitSum);
    const calculatedWeights = {};
    let totalWeight = 0;

    nullKeys.forEach(k => {
      const baseWeight = weights[k] !== undefined ? weights[k] : 1;
      const w = baseWeight * (0.85 + rng() * 0.3);
      calculatedWeights[k] = w;
      totalWeight += w;
    });

    explicitEntries.forEach(([k, val]) => {
      result[k] = Number(val);
    });

    nullKeys.forEach((k, idx) => {
      if (idx === nullKeys.length - 1) {
        const assignedSum = Object.entries(result).reduce((acc, [ky, v]) => ky !== k ? acc + v : acc, 0);
        result[k] = Number(Math.max(0, 100 - assignedSum).toFixed(1));
      } else {
        const val = (calculatedWeights[k] / totalWeight) * remaining;
        result[k] = Number(val.toFixed(1));
      }
    });
  }

  const entriesArray = keys.map(label => ({ label, percent: result[label] }));
  if (sortDescending) {
    entriesArray.sort((a, b) => b.percent - a.percent);
  }
  return entriesArray;
};

const processCountryBreakdownWithLuckyDraw = (countriesSlots, countryPool, seed, behaviors) => {
  const behaviorHash = hashConfigState(behaviors);
  const combinedSeed = seed + behaviorHash + 333;

  const rng = createSeededRandom(combinedSeed);
  const randomTargetSum = 50 + rng() * 15; 

  let assignedCountries = [];
  let explicitSum = 0;

  countriesSlots.forEach(slot => {
    if (slot.country) {
      const explicitPct = slot.percentage !== null && slot.percentage !== undefined ? Number(slot.percentage) : null;
      assignedCountries.push({ name: slot.country, percentage: explicitPct });
      if (explicitPct !== null) explicitSum += explicitPct;
    }
  });

  const slotsNeedingCountry = countriesSlots.filter(s => !s.country);
  const remainingTarget = Math.max(0, randomTargetSum - explicitSum);

  if (slotsNeedingCountry.length > 0 || assignedCountries.some(c => c.percentage === null)) {
    let availablePool = [...countryPool].filter(c => !assignedCountries.some(ac => ac.name === c.name));
    let selectedLuckyCountries = [];

    slotsNeedingCountry.forEach(() => {
      if (availablePool.length === 0) return;
      const totalPoolWeight = availablePool.reduce((acc, c) => acc + c.weight, 0);
      let randVal = rng() * totalPoolWeight;
      let cumulative = 0;
      let winnerIndex = 0;

      for (let i = 0; i < availablePool.length; i++) {
        cumulative += availablePool[i].weight;
        if (randVal <= cumulative) {
          winnerIndex = i;
          break;
        }
      }
      selectedLuckyCountries.push(availablePool.splice(winnerIndex, 1)[0]);
    });

    let toCalculate = [
      ...assignedCountries.filter(c => c.percentage === null).map(c => {
        const poolMatch = countryPool.find(p => p.name === c.name);
        return { name: c.name, baseWeight: poolMatch ? poolMatch.weight : 5.0 };
      }),
      ...selectedLuckyCountries.map(c => ({ name: c.name, baseWeight: c.weight }))
    ];

    if (toCalculate.length > 0) {
      const winnerIndex = Math.floor(rng() * toCalculate.length);
      const scored = toCalculate.map((item, idx) => ({
        name: item.name,
        luckyScore: item.baseWeight * (idx === winnerIndex ? (2.2 + rng() * 1.5) : (0.4 + rng() * 0.7))
      }));

      const totalLuckyScore = scored.reduce((acc, s) => acc + s.luckyScore, 0);
      let calculatedUnassignedSum = 0;

      scored.forEach((s, idx) => {
        const share = idx === scored.length - 1 
          ? Math.max(0, remainingTarget - calculatedUnassignedSum)
          : Number(((s.luckyScore / totalLuckyScore) * remainingTarget).toFixed(1));
        
        calculatedUnassignedSum += share;

        const existing = assignedCountries.find(ac => ac.name === s.name);
        if (existing) existing.percentage = share;
        else assignedCountries.push({ name: s.name, percentage: share });
      });
    }
  }

  let finalResult = {};
  assignedCountries.forEach(ac => {
    finalResult[ac.name] = Number((ac.percentage || 0).toFixed(1));
  });

  return Object.entries(finalResult)
    .map(([label, percent]) => ({ label, percent }))
    .sort((a, b) => b.percent - a.percent);
};

const getComparisonText = (val, typical) => {
  if (typical === 0 || typical === undefined || val === null || val === undefined) return null;
  const diff = Math.round(((val - typical) / typical) * 100);
  if (diff === 0) return 'Same as typical';
  if (diff > 0) return `${diff}% higher than typical`;
  return `${Math.abs(diff)}% lower than typical`;
};

const generateSplitDatasets = (processedViews, ratioF) => {
  const followersData = [];
  const nonFollowersData = [];

  processedViews.forEach((item) => {
    const totalViews = item.views;
    const totalTypical = item.typical;

    if (totalViews === null || totalViews === undefined) {
      followersData.push({ time: item.time, views: null, typical: Math.round(totalTypical * ratioF), comparison: null });
      nonFollowersData.push({ time: item.time, views: null, typical: Math.round(totalTypical * (1 - ratioF)), comparison: null });
      return;
    }

    const fViews = Math.round(totalViews * ratioF);
    const fTypical = Math.round(totalTypical * ratioF);
    followersData.push({ time: item.time, views: fViews, typical: fTypical, comparison: getComparisonText(fViews, fTypical) });

    const nfViews = totalViews - fViews;
    const nfTypical = totalTypical - fTypical;
    nonFollowersData.push({ time: item.time, views: nfViews, typical: nfTypical, comparison: getComparisonText(nfViews, nfTypical) });
  });

  return { followersData, nonFollowersData };
};

const InstagramDonutChart = ({ followerRatio, centerLabel, centerValue }) => {
  const radius = 47;
  const strokeWidth = 6;
  const circumference = 2 * Math.PI * radius;
  
  let followersPercent = Math.min(100, Math.max(0, followerRatio * 100));
  followersPercent = followersPercent < 1.9 ? 0 : followersPercent;
  const nonFollowersPercent = 100 - followersPercent;

  const capPadding = followersPercent ? strokeWidth * 1.2 : 0; 

  const followersArc = Math.max(0, (circumference * (followersPercent / 100)) - capPadding);
  const nonFollowersArc = Math.max(0, (circumference * (nonFollowersPercent / 100)) - capPadding);
  
  const followersOffset = -strokeWidth / 2;
  const nonFollowersOffset = -(followersArc + capPadding + strokeWidth / 2);

  return (
    <div className="relative w-44 h-44 my-1 flex items-center justify-center">
      <svg className="w-full h-full transform -rotate-90" viewBox="0 0 100 100">
        {nonFollowersPercent > 0 && (
          <circle
            cx="50"
            cy="50"
            r={radius}
            fill="transparent"
            stroke="#7638FA"
            strokeWidth={strokeWidth}
            strokeDasharray={`${nonFollowersArc} ${circumference - nonFollowersArc}`}
            strokeDashoffset={nonFollowersOffset}
            strokeLinecap="round"
          />
        )}
        {followersPercent > 0 && (
          <circle
            cx="50"
            cy="50"
            r={radius}
            fill="transparent"
            stroke="#DC38D1"
            strokeWidth={strokeWidth}
            strokeDasharray={`${followersArc} ${circumference - followersArc}`}
            strokeDashoffset={followersOffset}
            strokeLinecap="round"
          />
        )}
      </svg>
      <div className="absolute inset-0 flex flex-col items-center justify-center text-center">
        <span className="text-[10px] font-normal text-[#8e8e93] tracking-wide">{centerLabel}</span>
        <span className="text-[25px] font-extrabold text-white tracking-tight mt-0.5 mb-3">
          {Number(centerValue) ? Number(centerValue).toLocaleString() : (centerValue || '0')}
        </span>
      </div>
    </div>
  );
};

export default function ReelInsightsDashboard() {
  const [viewFilter, setViewFilter] = useState('All');
  const [audienceTab, setAudienceTab] = useState('Gender');
  const [showConfigPanel, setShowConfigPanel] = useState(false);
  const [configTab, setConfigTab] = useState('linkInput');
  const [isLoading, setIsLoading] = useState(false);
  
  const [config, setConfig] = useState(DASHBOARD_CONFIG);
  const [inputVideoUrl, setInputVideoUrl] = useState('');
  const [customCurveOverrides, setCustomCurveOverrides] = useState({});

  const fileInputRef = React.useRef(null);
  
  const handleThumbnailUpload = (e) => {
    const file = e.target.files[0];
    if (!file) return;
  
    const reader = new FileReader();
    reader.onload = (uploadEvent) => {
      const base64Image = uploadEvent.target.result;
      setConfig(prev => ({
        ...prev,
        reel: {
          ...prev.reel,
          thumbnail: base64Image
        }
      }));
    };
    reader.readAsDataURL(file);
  };

  const [viewsIndex, setViewsIndex] = useState(undefined);
  const [retentionIndex, setRetentionIndex] = useState(undefined);
  const [likesIndex, setLikesIndex] = useState(undefined);

  const applyProfile = (profileKey) => {
    const profile = SIMULATION_PROFILES[profileKey];
    if (!profile) return;
    const updatedBehaviors = { ...config.videoBehaviors, ...profile.config };
    setConfig(prev => ({ ...prev, videoBehaviors: updatedBehaviors }));
  };

  const handleFetchFromBackend = async (url) => {
    if (!url) return;
    setIsLoading(true);

    try {
      const response = await fetch('/api/fetch-reel', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ videoUrl: url })
      });
      if (!response.ok) throw new Error('Failed to fetch');
      const data = await response.json();

      setConfig(prev => ({
        ...prev,
        videoUrl: url,
        overview: {
          ...prev.overview,
          views: data.views || 0,
          instagramViews: data.views ? Math.floor(data.views * 0.99) : prev.overview.instagramViews,
          facebookViews: data.views ? Math.ceil(data.views * 0.01) : prev.overview.facebookViews
        },
        reel: {
          ...prev.reel,
          thumbnail: data.thumbnail || prev.reel.thumbnail,
          title: data.caption ? data.caption.toUpperCase() : prev.reel.title,
          likes: data.likes ?? prev.reel.likes,
          comments: data.comments ?? prev.reel.comments
        }
      }));
    } catch (err) {
      console.error(err);
      alert('Make sure your Node backend server is running and connected!');
    } finally {
      setIsLoading(false);
    }
  };

  const behaviorHash = hashConfigState(config.videoBehaviors);
  const baseSeededRng = createSeededRandom(config.seed + behaviorHash);
  const totalViews = config.overview.views || 0;
  
  const calculateDynamicWatchTime = (totalViews, retentionData, durationStr) => {
    const totalSecs = parseDurationToSeconds(durationStr);
    const avgRetention = retentionData.reduce((acc, p) => acc + p.retention, 0) / (retentionData.length || 1);
    const totalWatchSecs = Math.round(totalViews * (totalSecs * (avgRetention / 100)));
  
    const days = Math.floor(totalWatchSecs / 86400);
    const hours = Math.floor((totalWatchSecs % 86400) / 3600);
    const mins = Math.floor((totalWatchSecs % 3600) / 60);
    const secs = totalWatchSecs % 60;
  
    return `${days > 0 ? `${days}d ` : ''}${hours}h ${mins}m ${secs}s`;
  };

  const calcLikes = config.reel.likes !== null ? config.reel.likes : Math.max(1, Math.round(totalViews * (0.007 + baseSeededRng() * 0.006))); 
  const calcComments = config.reel.comments !== null ? config.reel.comments : Math.max(0, Math.round(totalViews * (0.0002 + baseSeededRng() * 0.0004))); 
  const calcShares = config.reel.shares !== null ? config.reel.shares : Math.max(0, Math.round(totalViews * (0.0006 + baseSeededRng() * 0.0008))); 
  const calcReposts = config.reel.reposts !== null ? config.reel.reposts : Math.max(0, Math.round(totalViews * (0.0003 + baseSeededRng() * 0.0004))); 
  const calcSaves = config.reel.saves !== null ? config.reel.saves : Math.max(0, Math.round(totalViews * (0.0006 + baseSeededRng() * 0.0008))); 
  const calcFollows = config.reel.follows !== null ? config.reel.follows : Math.max(0, Math.round(totalViews * (0.0001 + baseSeededRng() * 0.0003))); 
  
  const totalInteractions = config.overview.interactions !== null 
    ? config.overview.interactions 
    : (calcLikes + calcComments + calcShares + calcReposts + calcSaves);

  const ageWeights = { '13-17': 0.15, '18-24': 1.81, '25-34': 3.6, '35-44': 2.5, '45-54': 0.8, '55-64': 0.3, '65+': 0.05 };
  const genderWeights = { 'Men': 3.2, 'Women': 1.0 };

  const genderBreakdown = processPercentageBreakdown(config.audience.gender, config.seed, config.videoBehaviors, genderWeights, true, null, 111);
  const countryBreakdown = processCountryBreakdownWithLuckyDraw(config.audience.countries, config.audience.countryPool, config.seed, config.videoBehaviors);
  const ageBreakdown = processPercentageBreakdown(
    config.audience.age, 
    config.seed, 
    config.videoBehaviors, 
    ageWeights, 
    false, 
    ['13-17', '18-24', '25-34', '35-44', '45-54', '55-64', '65+'],
    222
  );
  
  const viewsSplit = generateWeightedRatio(config.splitRatios.targetFollowersMean, config.splitRatios.variance, config.seed, config.videoBehaviors, 77);
  const interactionSplit = generateWeightedRatio(config.interactionSplitRatios.targetFollowersMean, config.interactionSplitRatios.variance, config.seed, config.videoBehaviors, 88);
  
  const topSourcesWeights = { 'Reels tab': 65.0, 'Feed': 16.0, 'Explore': 8.0, 'Profile': 0.05 };
  const topSourcesBreakdown = processPercentageBreakdown(config.topSources, config.seed, config.videoBehaviors, topSourcesWeights, true, null, 444);

  const secondBySecondRetentionData = generateOrganicVolatileRetention(config.reel.duration, config.seed, config.videoBehaviors);
  const secondsWiseLikesData = generateSecondsWiseLikesInteraction(config.reel.duration, config.seed, calcLikes, config.videoBehaviors);
  const dynamicLikesYMax = Math.ceil(Math.max(...secondsWiseLikesData.map(d => d.val), 15) / 10) * 10;

  const computedViewsOverTime = generateAdvancedViewsOverTime(
    totalViews, 
    config.seed, 
    config.regenSalt, // <--- Pass salt here
    config.videoBehaviors, 
    config.reel.date, 
    customCurveOverrides
  );

  const totalViewsOverTimeData = computedViewsOverTime.map(item => ({ ...item, comparison: getComparisonText(item.views, item.typical) }));
  const { followersData, nonFollowersData } = generateSplitDatasets(computedViewsOverTime, config.splitRatios.followersShare);
  const currentViewsData = viewFilter === 'Followers' ? followersData : viewFilter === 'Non-followers' ? nonFollowersData : totalViewsOverTimeData;

  const dynamicTicks = getDynamicTimeLabels(config.reel.date).ticks;

  const handleBehaviorChange = (key, val) => {
    const updatedBehaviors = { ...config.videoBehaviors, [key]: val };
    setConfig(prev => ({ ...prev, videoBehaviors: updatedBehaviors }));
  };

  const handleSplitRatioChange = (key, val) => {
    const updatedRatios = { ...config.splitRatios, [key]: val };
    setConfig(prev => ({ ...prev, splitRatios: updatedRatios }));
  };

  const handleReelDetailChange = (field, value) => {
    setConfig(prev => ({
      ...prev,
      reel: {
        ...prev.reel,
        [field]: value === '' ? null : value
      }
    }));
  };

  const handleOverviewChange = (field, value) => {
    const numericVal = value === '' ? null : (Number(value) || 0);
    setConfig(prev => {
      const newOverview = { ...prev.overview, [field]: numericVal };
      if (field === 'views' && numericVal !== null) {
        newOverview.instagramViews = Math.floor(numericVal * 0.99);
        newOverview.facebookViews = Math.ceil(numericVal * 0.01);
      }
      return { ...prev, overview: newOverview };
    });
  };

  const handleAudienceGenderChange = (genderKey, value) => {
    const num = value === '' ? null : Number(value);
    setConfig(prev => ({
      ...prev,
      audience: {
        ...prev.audience,
        gender: {
          ...prev.audience.gender,
          [genderKey]: num
        }
      }
    }));
  };

  const handleAudienceAgeChange = (ageKey, value) => {
    const num = value === '' ? null : Number(value);
    setConfig(prev => ({
      ...prev,
      audience: {
        ...prev.audience,
        age: {
          ...prev.audience.age,
          [ageKey]: num
        }
      }
    }));
  };

  const handleTopSourceChange = (sourceKey, value) => {
    const num = value === '' ? null : Number(value);
    setConfig(prev => ({
      ...prev,
      topSources: {
        ...prev.topSources,
        [sourceKey]: num
      }
    }));
  };

  const handleCountrySlotChange = (index, field, value) => {
    const updatedCountries = [...config.audience.countries];
    if (field === 'country') {
      updatedCountries[index] = { ...updatedCountries[index], country: value === '' ? null : value };
    } else if (field === 'percentage') {
      updatedCountries[index] = { ...updatedCountries[index], percentage: value === '' ? null : Number(value) };
    }
    setConfig(prev => ({
      ...prev,
      audience: {
        ...prev.audience,
        countries: updatedCountries
      }
    }));
  };

  const handleCountryPoolWeightChange = (countryName, newWeight) => {
    const updatedPool = config.audience.countryPool.map(c => c.name === countryName ? { ...c, weight: Number(newWeight) || 0 } : c);
    setConfig(prev => ({
      ...prev,
      audience: {
        ...prev.audience,
        countryPool: updatedPool
      }
    }));
  };

  const handleViewsPointChange = (index, field, value) => {
    const updatedOverrides = { ...customCurveOverrides, [index]: { ...(customCurveOverrides[index] || {}), [field]: value === '' ? null : (Number(value) || 0) } };
    setCustomCurveOverrides(updatedOverrides);
  };

  const saveCustomProfileSlot = (slotKey) => {
    const snapshot = {
      videoBehaviors: { ...config.videoBehaviors },
      splitRatios: { ...config.splitRatios }
    };
    setConfig(prev => ({
      ...prev,
      customProfilesStore: {
        ...prev.customProfilesStore,
        [slotKey]: snapshot
      }
    }));
    alert(`Successfully saved current config to ${slotKey.toUpperCase()}!`);
  };

  const loadCustomProfileSlot = (slotKey) => {
    const snapshot = config.customProfilesStore[slotKey];
    if (!snapshot) {
      alert(`No saved configuration found in ${slotKey.toUpperCase()} yet!`);
      return;
    }
    setConfig(prev => ({
      ...prev,
      videoBehaviors: { ...snapshot.videoBehaviors },
      splitRatios: { ...snapshot.splitRatios }
    }));
    alert(`Loaded ${slotKey.toUpperCase()} configuration successfully!`);
  };

  const randomizeViewsCurve = () => {
    setConfig(prev => ({ 
      ...prev, 
      regenSalt: (prev.regenSalt || 1) + 1 
    }));
  };


  const randomizeSeed = () => {
    const randomSeedVal = Math.floor(Math.random() * 999999) + 1;
    setConfig(prev => ({ ...prev, seed: randomSeedVal }));
  };

  return (
    <div className="fixed inset-0 w-screen h-screen overflow-hidden bg-[#0C1014] text-white font-sans flex flex-col items-center select-none antialiased [-webkit-font-smoothing:antialiased]" style={{ overscrollBehavior: 'none' }}>
      <div className="w-full max-w-[430px] bg-[#0C1014] h-full flex flex-col border-x border-zinc-900 shadow-2xl relative overflow-hidden" style={{ overscrollBehavior: 'none' }}>
        
        {/* NON-SCROLLING FIXED HEADER BAR */}
        <div className="flex-shrink-0 bg-[#0C1014] border-b border-zinc-900/80 z-30 relative">
          <div className="flex items-center justify-between px-3.5 py-2.5">
            <div className="flex items-center space-x-3.5">
              <button className="text-white hover:text-zinc-300 transition-colors">
                <ArrowLeft className="w-5 h-5 stroke-[2]" />
              </button>
              <h1 className="text-[16px] font-bold tracking-tight text-white">Reel insights</h1>
            </div>
            
            <button 
              onClick={() => setShowConfigPanel(!showConfigPanel)}
              className="text-white hover:text-zinc-300 transition-colors p-1.5 rounded-full hover:bg-zinc-800 cursor-pointer"
              title="Toggle Parameter Editor"
            >
              <MoreVertical className="w-4.5 h-4.5 stroke-[2]" />
            </button>
          </div>

          {/* Expanded Config Panel with 7 Granular Control Tabs */}
          {showConfigPanel && (
            <div className="absolute right-2 top-12 w-96 bg-zinc-900 border border-zinc-800 p-3 rounded-xl shadow-2xl text-[12px] z-40 space-y-3">
              
              <div className="flex items-center justify-between bg-zinc-800/80 hover:bg-zinc-800 p-2 rounded-lg cursor-pointer transition-colors border border-zinc-700/50"
                onClick={() => window.location.reload()}
              >
                <div className="flex items-center space-x-2 text-white">
                  <RotateCw className="w-3.5 h-3.5 text-purple-400" />
                  <span className="font-medium text-xs">Reload Insights Data</span>
                </div>
                <span className="text-[10px] text-zinc-400 font-mono">Refresh</span>
              </div>

              {/* Tab Navigation Header (7 Tabs) */}
              <div className="flex justify-between items-center border-b border-zinc-800 pb-2">
                <div className="grid grid-cols-7 gap-0.5 w-full mr-2">
                  <button 
                    onClick={() => setConfigTab('linkInput')} 
                    className={`px-0.5 py-1 rounded font-semibold text-[8px] flex flex-col items-center justify-center ${configTab === 'linkInput' ? 'bg-purple-600 text-white' : 'text-zinc-400 hover:text-white bg-zinc-800/60'}`}
                  >
                    <LinkIcon className="w-2.5 h-2.5 mb-0.5" />
                    <span>Link</span>
                  </button>
                  <button 
                    onClick={() => setConfigTab('profiles')} 
                    className={`px-0.5 py-1 rounded font-semibold text-[8px] flex flex-col items-center justify-center ${configTab === 'profiles' ? 'bg-purple-600 text-white' : 'text-zinc-400 hover:text-white bg-zinc-800/60'}`}
                  >
                    <Layers className="w-2.5 h-2.5 mb-0.5" />
                    <span>Presets</span>
                  </button>
                  <button 
                    onClick={() => setConfigTab('metrics')} 
                    className={`px-0.5 py-1 rounded font-semibold text-[8px] flex flex-col items-center justify-center ${configTab === 'metrics' ? 'bg-purple-600 text-white' : 'text-zinc-400 hover:text-white bg-zinc-800/60'}`}
                  >
                    <BarChart2 className="w-2.5 h-2.5 mb-0.5" />
                    <span>Metrics</span>
                  </button>
                  <button 
                    onClick={() => setConfigTab('behaviors')} 
                    className={`px-0.5 py-1 rounded font-semibold text-[8px] flex flex-col items-center justify-center ${configTab === 'behaviors' ? 'bg-purple-600 text-white' : 'text-zinc-400 hover:text-white bg-zinc-800/60'}`}
                  >
                    <Sliders className="w-2.5 h-2.5 mb-0.5" />
                    <span>Flow</span>
                  </button>
                  <button 
                    onClick={() => setConfigTab('math')} 
                    className={`px-0.5 py-1 rounded font-semibold text-[8px] flex flex-col items-center justify-center ${configTab === 'math' ? 'bg-purple-600 text-white' : 'text-zinc-400 hover:text-white bg-zinc-800/60'}`}
                  >
                    <Cpu className="w-2.5 h-2.5 mb-0.5" />
                    <span>Math</span>
                  </button>
                  <button 
                    onClick={() => setConfigTab('audienceEditor')} 
                    className={`px-0.5 py-1 rounded font-semibold text-[8px] flex flex-col items-center justify-center ${configTab === 'audienceEditor' ? 'bg-purple-600 text-white' : 'text-zinc-400 hover:text-white bg-zinc-800/60'}`}
                  >
                    <Users className="w-2.5 h-2.5 mb-0.5" />
                    <span>Audience</span>
                  </button>
                  <button 
                    onClick={() => setConfigTab('viewsEditor')} 
                    className={`px-0.5 py-1 rounded font-semibold text-[8px] flex flex-col items-center justify-center ${configTab === 'viewsEditor' ? 'bg-purple-600 text-white' : 'text-zinc-400 hover:text-white bg-zinc-800/60'}`}
                  >
                    <Activity className="w-2.5 h-2.5 mb-0.5" />
                    <span>Curve</span>
                  </button>
                </div>
                <button onClick={() => setShowConfigPanel(false)} className="text-zinc-400 hover:text-white font-bold text-sm px-1">✕</button>
              </div>

              {/* TAB 1: INSTALOADER LINK INPUT */}
              {configTab === 'linkInput' && (
                <div className="space-y-2.5 max-h-68 overflow-y-auto pr-1">
                  <div className="space-y-1.5 bg-zinc-800/50 p-2.5 rounded-lg border border-zinc-700/40">
                    <label className="text-[10px] text-zinc-400 font-bold uppercase tracking-wider block">Instagram Reel URL</label>
                    <textarea 
                      rows={3}
                      placeholder="https://www.instagram.com/reel/..." 
                      value={inputVideoUrl}
                      onChange={(e) => setInputVideoUrl(e.target.value)}
                      className="w-full bg-zinc-900 border border-zinc-700 rounded p-2 text-white text-[11px] font-mono focus:outline-none focus:border-purple-500 resize-none"
                    />
                    <button 
                      onClick={() => handleFetchFromBackend(inputVideoUrl)}
                      className="w-full bg-purple-600 hover:bg-purple-500 text-white py-1.5 rounded text-[11px] font-semibold transition-colors mt-1"
                    >
                      Fetch Reel Data
                    </button>
                    </div>
                    {/* Hidden File Input */}
                    <input 
                      type="file" 
                      ref={fileInputRef} 
                      onChange={handleThumbnailUpload} 
                      accept="image/*" 
                      className="hidden" 
                    />
                    
                    {/* Upload Trigger Button */}
                    <div className="space-y-1.5 bg-zinc-800/50 p-2.5 rounded-lg border border-zinc-700/40 mt-2">
                      <label className="text-[10px] text-zinc-400 font-bold uppercase tracking-wider block">Custom Thumbnail Image</label>
                      <button 
                        onClick={() => fileInputRef.current.click()}
                        className="w-full bg-zinc-800 hover:bg-zinc-700 text-white py-1.5 rounded text-[11px] font-semibold transition-colors border border-zinc-600 flex items-center justify-center space-x-1.5"
                      >
                        <span>📂 Choose Image from File Manager</span>
                      </button>
                  </div>
                </div>
              )}

              {/* TAB 2: PREBUILT SIMULATION PROFILES & SLOTS */}
              {configTab === 'profiles' && (
                <div className="space-y-3 max-h-68 overflow-y-auto pr-1">
                  <div className="space-y-1 bg-zinc-800/40 p-2 rounded border border-zinc-800">
                    <span className="text-[10px] font-bold text-purple-400 uppercase tracking-wider block">Custom Profile Snapshots</span>
                    <div className="grid grid-cols-2 gap-2 mt-1">
                      <div>
                        <button onClick={() => saveCustomProfileSlot('slot1')} className="w-full bg-zinc-800 hover:bg-zinc-700 text-white py-1 rounded text-[10px] border border-zinc-700">Save Slot 1</button>
                        <button onClick={() => loadCustomProfileSlot('slot1')} className="w-full bg-purple-600/80 hover:bg-purple-600 text-white py-1 rounded text-[10px] mt-1">Load Slot 1</button>
                      </div>
                      <div>
                        <button onClick={() => saveCustomProfileSlot('slot2')} className="w-full bg-zinc-800 hover:bg-zinc-700 text-white py-1 rounded text-[10px] border border-zinc-700">Save Slot 2</button>
                        <button onClick={() => loadCustomProfileSlot('slot2')} className="w-full bg-purple-600/80 hover:bg-purple-600 text-white py-1 rounded text-[10px] mt-1">Load Slot 2</button>
                      </div>
                    </div>
                  </div>

                  <div>
                    <span className="text-[10px] font-bold text-purple-400 uppercase tracking-wider block mb-1">15 Prebuilt Profiles</span>
                    <div className="grid grid-cols-1 gap-1.5">
                      {Object.entries(SIMULATION_PROFILES).map(([key, prof]) => (
                        <div 
                          key={key}
                          onClick={() => applyProfile(key)}
                          className="bg-zinc-800/60 hover:bg-zinc-800 border border-zinc-700/50 hover:border-purple-500/50 p-2 rounded-lg cursor-pointer transition-all"
                        >
                          <div className="font-semibold text-white text-[11px]">{prof.name}</div>
                          <div className="text-[9.5px] text-zinc-400 mt-0.5">{prof.desc}</div>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              )}

              {/* TAB 3: MANUAL METRICS & DETAILS */}
              {configTab === 'metrics' && (
                <div className="space-y-3 max-h-68 overflow-y-auto pr-1">
                  <div>
                    <span className="text-[10px] font-bold text-purple-400 uppercase tracking-wider block mb-1.5">Reel Metadata Properties</span>
                    <div className="space-y-2 bg-zinc-800/40 p-2 rounded border border-zinc-800">
                      <div>
                        <label className="text-[10px] text-zinc-400 block mb-0.5">Title / Caption</label>
                        <input 
                          type="text" 
                          value={config.reel.title} 
                          onChange={(e) => handleReelDetailChange('title', e.target.value)}
                          className="w-full bg-zinc-900 border border-zinc-700 rounded px-2 py-1 text-white text-[11px]"
                        />
                      </div>
                      <div className="grid grid-cols-2 gap-2">
                        <div>
                          <label className="text-[10px] text-zinc-400 block mb-0.5">Publish Date</label>
                          <input 
                            type="text" 
                            value={config.reel.date} 
                            onChange={(e) => handleReelDetailChange('date', e.target.value)}
                            className="w-full bg-zinc-900 border border-zinc-700 rounded px-2 py-1 text-white text-[11px]"
                          />
                        </div>
                        <div>
                          <label className="text-[10px] text-zinc-400 block mb-0.5">Duration (m:s)</label>
                          <input 
                            type="text" 
                            value={config.reel.duration} 
                            onChange={(e) => handleReelDetailChange('duration', e.target.value)}
                            className="w-full bg-zinc-900 border border-zinc-700 rounded px-2 py-1 text-white text-[11px] text-center font-mono"
                          />
                        </div>
                      </div>
                    </div>
                  </div>

                  <div>
                    <span className="text-[10px] font-bold text-purple-400 uppercase tracking-wider block mb-1.5">Live Engagement Counters & Aggregates (Blank = Auto)</span>
                    <div className="grid grid-cols-2 gap-2 bg-zinc-800/40 p-2 rounded border border-zinc-800">
                      <div>
                        <label className="text-[10px] text-zinc-400 block mb-0.5">Views</label>
                        <input 
                          type="number" 
                          value={config.overview.views ?? ''} 
                          onChange={(e) => handleOverviewChange('views', e.target.value)}
                          className="w-full bg-zinc-900 border border-zinc-700 rounded px-2 py-1 text-white text-[11px] font-mono"
                        />
                      </div>
                      <div>
                        <label className="text-[10px] text-zinc-400 block mb-0.5">Likes</label>
                        <input 
                          type="number" 
                          value={config.reel.likes ?? ''} 
                          onChange={(e) => handleReelDetailChange('likes', e.target.value === '' ? null : Number(e.target.value))}
                          className="w-full bg-zinc-900 border border-zinc-700 rounded px-2 py-1 text-white text-[11px] font-mono"
                        />
                      </div>
                      <div>
                        <label className="text-[10px] text-zinc-400 block mb-0.5">Comments</label>
                        <input 
                          type="number" 
                          value={config.reel.comments ?? ''} 
                          onChange={(e) => handleReelDetailChange('comments', e.target.value === '' ? null : Number(e.target.value))}
                          className="w-full bg-zinc-900 border border-zinc-700 rounded px-2 py-1 text-white text-[11px] font-mono"
                        />
                      </div>
                      <div>
                        <label className="text-[10px] text-zinc-400 block mb-0.5">Shares</label>
                        <input 
                          type="number" 
                          value={config.reel.shares ?? ''} 
                          onChange={(e) => handleReelDetailChange('shares', e.target.value === '' ? null : Number(e.target.value))}
                          className="w-full bg-zinc-900 border border-zinc-700 rounded px-2 py-1 text-white text-[11px] font-mono"
                        />
                      </div>
                      <div>
                        <label className="text-[10px] text-zinc-400 block mb-0.5">Reposts</label>
                        <input 
                          type="number" 
                          value={config.reel.reposts ?? ''} 
                          onChange={(e) => handleReelDetailChange('reposts', e.target.value === '' ? null : Number(e.target.value))}
                          className="w-full bg-zinc-900 border border-zinc-700 rounded px-2 py-1 text-white text-[11px] font-mono"
                        />
                      </div>
                      <div>
                        <label className="text-[10px] text-zinc-400 block mb-0.5">Saves</label>
                        <input 
                          type="number" 
                          value={config.reel.saves ?? ''} 
                          onChange={(e) => handleReelDetailChange('saves', e.target.value === '' ? null : Number(e.target.value))}
                          className="w-full bg-zinc-900 border border-zinc-700 rounded px-2 py-1 text-white text-[11px] font-mono"
                        />
                      </div>
                      <div>
                        <label className="text-[10px] text-zinc-400 block mb-0.5">Profile Follows</label>
                        <input 
                          type="number" 
                          value={config.reel.follows ?? ''} 
                          onChange={(e) => handleReelDetailChange('follows', e.target.value === '' ? null : Number(e.target.value))}
                          className="w-full bg-zinc-900 border border-zinc-700 rounded px-2 py-1 text-white text-[11px] font-mono"
                        />
                      </div>
                      <div>
                        <label className="text-[10px] text-zinc-400 block mb-0.5">Accounts Reached</label>
                        <input 
                          type="number" 
                          value={config.overview.accountsReachedOverride ?? ''} 
                          onChange={(e) => setConfig(prev => ({ ...prev, overview: { ...prev.overview, accountsReachedOverride: e.target.value === '' ? null : Number(e.target.value) } }))}
                          className="w-full bg-zinc-900 border border-zinc-700 rounded px-2 py-1 text-white text-[11px] font-mono"
                        />
                      </div>
                    </div>
                  </div>
                </div>
              )}

              {/* TAB 4: ALGORITHM BEHAVIORS */}
              {configTab === 'behaviors' && (
                <div className="space-y-3 max-h-68 overflow-y-auto pr-1">
                  <div>
                    <span className="text-[10px] font-bold text-purple-400 uppercase tracking-wider block mb-1.5">Seed & Profile Behaviors</span>
                    <div className="space-y-2 bg-zinc-800/40 p-2 rounded border border-zinc-800">
                      <div className="flex items-center justify-between">
                        <span className="text-[11px] text-zinc-300">Random Seed</span>
                        <div className="flex items-center space-x-1.5">
                          <input 
                            type="number" 
                            value={config.seed} 
                            onChange={(e) => {
                              const newSeed = Number(e.target.value) || 1;
                              setConfig(prev => ({ ...prev, seed: newSeed }));
                            }}
                            className="w-16 bg-zinc-900 border border-zinc-700 rounded px-1.5 py-1 text-white text-center font-mono text-xs"
                          />
                          <button onClick={randomizeSeed} className="bg-purple-600 hover:bg-purple-500 text-white p-1 rounded" title="Randomize Seed & Views">
                            <Dice5 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </div>

                      <div className="flex items-center justify-between">
                        <span className="text-[11px] text-zinc-300">Views Growth Curve</span>
                        <select 
                          value={config.videoBehaviors.viewsProfile}
                          onChange={(e) => handleBehaviorChange('viewsProfile', e.target.value)}
                          className="bg-zinc-900 border border-zinc-700 rounded px-2 py-1 text-white text-xs font-mono"
                        >
                          <option value="viral_burst">Viral Burst</option>
                          <option value="slow_burn">Slow Burn</option>
                          <option value="rollercoaster">Rollercoaster</option>
                        </select>
                      </div>
                    </div>
                  </div>

                  <div>
                    <span className="text-[10px] font-bold text-purple-400 uppercase tracking-wider block mb-1.5">Content Volatility & Flow Coefficients</span>
                    <div className="space-y-2 bg-zinc-800/40 p-2 rounded border border-zinc-800">
                      <div className="flex items-center justify-between">
                        <span className="text-[11px] text-zinc-300">Chaos Volatility</span>
                        <input 
                          type="number" step="0.1" min="0.2" max="3.0"
                          value={config.videoBehaviors.chaosVolatility} 
                          onChange={(e) => handleBehaviorChange('chaosVolatility', Number(e.target.value))}
                          className="w-16 bg-zinc-900 border border-zinc-700 rounded px-2 py-1 text-white text-center font-mono"
                        />
                      </div>

                      <div className="flex items-center justify-between">
                        <span className="text-[11px] text-zinc-300">Stochastic Probability</span>
                        <input 
                          type="number" step="0.05" min="0.0" max="1.0"
                          value={config.videoBehaviors.stochasticChance} 
                          onChange={(e) => handleBehaviorChange('stochasticChance', Number(e.target.value))}
                          className="w-16 bg-zinc-900 border border-zinc-700 rounded px-2 py-1 text-white text-center font-mono"
                        />
                      </div>

                      <div className="flex items-center justify-between">
                        <span className="text-[11px] text-zinc-300">Audio Track Energy</span>
                        <input 
                          type="number" step="0.1" min="0.5" max="3.0"
                          value={config.videoBehaviors.audioTrackEnergyCoefficient} 
                          onChange={(e) => handleBehaviorChange('audioTrackEnergyCoefficient', Number(e.target.value))}
                          className="w-16 bg-zinc-900 border border-zinc-700 rounded px-2 py-1 text-white text-center font-mono"
                        />
                      </div>

                      <div className="flex items-center justify-between">
                        <span className="text-[11px] text-zinc-300">Visual Cut Frequency</span>
                        <input 
                          type="number" step="0.1" min="0.5" max="3.0"
                          value={config.videoBehaviors.visualCutFrequencyIndex} 
                          onChange={(e) => handleBehaviorChange('visualCutFrequencyIndex', Number(e.target.value))}
                          className="w-16 bg-zinc-900 border border-zinc-700 rounded px-2 py-1 text-white text-center font-mono"
                        />
                      </div>

                      <div className="flex items-center justify-between">
                        <span className="text-[11px] text-zinc-300">Bad Hook Penalty</span>
                        <input 
                          type="checkbox"
                          checked={config.videoBehaviors.hasBadHook}
                          onChange={(e) => handleBehaviorChange('hasBadHook', e.target.checked)}
                          className="w-4 h-4 accent-purple-600"
                        />
                      </div>

                      <div className="flex items-center justify-between">
                        <span className="text-[11px] text-zinc-300">Dead Air Drop-off</span>
                        <input 
                          type="checkbox"
                          checked={config.videoBehaviors.hasDeadAir}
                          onChange={(e) => handleBehaviorChange('hasDeadAir', e.target.checked)}
                          className="w-4 h-4 accent-purple-600"
                        />
                      </div>

                      <div className="flex items-center justify-between">
                        <span className="text-[11px] text-zinc-300">Boring Content Decay</span>
                        <input 
                          type="checkbox"
                          checked={config.videoBehaviors.isBoring}
                          onChange={(e) => handleBehaviorChange('isBoring', e.target.checked)}
                          className="w-4 h-4 accent-purple-600"
                        />
                      </div>
                    </div>
                  </div>
                </div>
              )}

              {/* TAB 5: ADVANCED MATH & FUNCTION CONSTANTS */}
              {configTab === 'math' && (
                <div className="space-y-3 max-h-68 overflow-y-auto pr-1">
                  <div>
                    <span className="text-[10px] font-bold text-purple-400 uppercase tracking-wider block mb-1.5">Distribution Ratios & Variance</span>
                    <div className="space-y-2 bg-zinc-800/40 p-2 rounded border border-zinc-800">
                      <div className="flex items-center justify-between">
                        <span className="text-[11px] text-zinc-300">Follower Share Mean</span>
                        <input 
                          type="number" step="0.005" min="0.0" max="0.5"
                          value={config.splitRatios.targetFollowersMean} 
                          onChange={(e) => handleSplitRatioChange('targetFollowersMean', Number(e.target.value))}
                          className="w-20 bg-zinc-900 border border-zinc-700 rounded px-2 py-1 text-white text-center font-mono"
                        />
                      </div>
                      <div className="flex items-center justify-between">
                        <span className="text-[11px] text-zinc-300">Distribution Variance</span>
                        <input 
                          type="number" step="0.01" min="0.0" max="0.5"
                          value={config.splitRatios.variance} 
                          onChange={(e) => handleSplitRatioChange('variance', Number(e.target.value))}
                          className="w-20 bg-zinc-900 border border-zinc-700 rounded px-2 py-1 text-white text-center font-mono"
                        />
                      </div>
                    </div>
                  </div>

                  <div>
                    <span className="text-[10px] font-bold text-purple-400 uppercase tracking-wider block mb-1.5">Algorithm & Momentum Multipliers</span>
                    <div className="space-y-2 bg-zinc-800/40 p-2 rounded border border-zinc-800">
                      <div className="flex items-center justify-between">
                        <span className="text-[11px] text-zinc-300">Algorithm Push Factor</span>
                        <input 
                          type="number" step="0.1" min="0.1" max="5.0"
                          value={config.videoBehaviors.algorithmPushFactor} 
                          onChange={(e) => handleBehaviorChange('algorithmPushFactor', Number(e.target.value))}
                          className="w-20 bg-zinc-900 border border-zinc-700 rounded px-2 py-1 text-white text-center font-mono"
                        />
                      </div>
                      <div className="flex items-center justify-between">
                        <span className="text-[11px] text-zinc-300">Weekend Multiplier</span>
                        <input 
                          type="number" step="0.05" min="1.0" max="3.0"
                          value={config.videoBehaviors.weekendMultiplier} 
                          onChange={(e) => handleBehaviorChange('weekendMultiplier', Number(e.target.value))}
                          className="w-20 bg-zinc-900 border border-zinc-700 rounded px-2 py-1 text-white text-center font-mono"
                        />
                      </div>
                      <div className="flex items-center justify-between">
                        <span className="text-[11px] text-zinc-300">Midpoint Resonance Boost</span>
                        <input 
                          type="number" step="0.1" min="0.1" max="5.0"
                          value={config.videoBehaviors.midpointResonanceBoost} 
                          onChange={(e) => handleBehaviorChange('midpointResonanceBoost', Number(e.target.value))}
                          className="w-20 bg-zinc-900 border border-zinc-700 rounded px-2 py-1 text-white text-center font-mono"
                        />
                      </div>
                      <div className="flex items-center justify-between">
                        <span className="text-[11px] text-zinc-300">Peak Hour Offset</span>
                        <input 
                          type="number" step="1" min="1" max="14"
                          value={config.videoBehaviors.peakHourOffset} 
                          onChange={(e) => handleBehaviorChange('peakHourOffset', Number(e.target.value))}
                          className="w-20 bg-zinc-900 border border-zinc-700 rounded px-2 py-1 text-white text-center font-mono"
                        />
                      </div>
                    </div>
                  </div>

                  <div>
                    <span className="text-[10px] font-bold text-purple-400 uppercase tracking-wider block mb-1.5">Perlin Noise & Decay Constants</span>
                    <div className="space-y-2 bg-zinc-800/40 p-2 rounded border border-zinc-800">
                      <div className="flex items-center justify-between">
                        <span className="text-[11px] text-zinc-300">Hook Severity Weight</span>
                        <input 
                          type="number" step="0.5" min="1.0" max="10.0"
                          value={config.videoBehaviors.hookSeverityWeight} 
                          onChange={(e) => handleBehaviorChange('hookSeverityWeight', Number(e.target.value))}
                          className="w-20 bg-zinc-900 border border-zinc-700 rounded px-2 py-1 text-white text-center font-mono"
                        />
                      </div>
                      <div className="flex items-center justify-between">
                        <span className="text-[11px] text-zinc-300">Decay Power Coefficient</span>
                        <input 
                          type="number" step="0.05" min="0.1" max="2.0"
                          value={config.videoBehaviors.decayPowerCoefficient} 
                          onChange={(e) => handleBehaviorChange('decayPowerCoefficient', Number(e.target.value))}
                          className="w-20 bg-zinc-900 border border-zinc-700 rounded px-2 py-1 text-white text-center font-mono"
                        />
                      </div>
                      <div className="flex items-center justify-between">
                        <span className="text-[11px] text-zinc-300">Spike Probability Threshold</span>
                        <input 
                          type="number" step="0.02" min="0.0" max="0.5"
                          value={config.videoBehaviors.spikeProbabilityThreshold} 
                          onChange={(e) => handleBehaviorChange('spikeProbabilityThreshold', Number(e.target.value))}
                          className="w-20 bg-zinc-900 border border-zinc-700 rounded px-2 py-1 text-white text-center font-mono"
                        />
                      </div>
                      <div className="flex items-center justify-between">
                        <span className="text-[11px] text-zinc-300">Noise Harmonic Frequency</span>
                        <input 
                          type="number" step="0.01" min="0.01" max="0.3"
                          value={config.videoBehaviors.noiseHarmonicFrequency} 
                          onChange={(e) => handleBehaviorChange('noiseHarmonicFrequency', Number(e.target.value))}
                          className="w-20 bg-zinc-900 border border-zinc-700 rounded px-2 py-1 text-white text-center font-mono"
                        />
                      </div>
                    </div>
                  </div>
                </div>
              )}

              {/* TAB 6: AUDIENCE & DEMOGRAPHICS OVERRIDE */}
              {configTab === 'audienceEditor' && (
                <div className="space-y-3 max-h-68 overflow-y-auto pr-1">
                  <div>
                    <span className="text-[10px] font-bold text-purple-400 uppercase tracking-wider block mb-1.5">Gender Breakdown Overrides (%)</span>
                    <div className="grid grid-cols-2 gap-2 bg-zinc-800/40 p-2 rounded border border-zinc-800">
                      <div>
                        <label className="text-[10px] text-zinc-400 block mb-0.5">Men %</label>
                        <input 
                          type="number" step="0.1"
                          value={config.audience.gender['Men'] ?? ''} 
                          onChange={(e) => handleAudienceGenderChange('Men', e.target.value)}
                          className="w-full bg-zinc-900 border border-zinc-700 rounded px-2 py-1 text-white text-xs font-mono"
                        />
                      </div>
                      <div>
                        <label className="text-[10px] text-zinc-400 block mb-0.5">Women %</label>
                        <input 
                          type="number" step="0.1"
                          value={config.audience.gender['Women'] ?? ''} 
                          onChange={(e) => handleAudienceGenderChange('Women', e.target.value)}
                          className="w-full bg-zinc-900 border border-zinc-700 rounded px-2 py-1 text-white text-xs font-mono"
                        />
                      </div>
                    </div>
                  </div>

                  <div>
                    <span className="text-[10px] font-bold text-purple-400 uppercase tracking-wider block mb-1.5">Age Brackets Overrides (%)</span>
                    <div className="grid grid-cols-2 gap-2 bg-zinc-800/40 p-2 rounded border border-zinc-800">
                      {Object.keys(config.audience.age).map((ageKey) => (
                        <div key={ageKey}>
                          <label className="text-[10px] text-zinc-400 block mb-0.5">{ageKey}</label>
                          <input 
                            type="number" step="0.1"
                            value={config.audience.age[ageKey] ?? ''} 
                            onChange={(e) => handleAudienceAgeChange(ageKey, e.target.value)}
                            className="w-full bg-zinc-900 border border-zinc-700 rounded px-2 py-1 text-white text-xs font-mono"
                          />
                        </div>
                      ))}
                    </div>
                  </div>

                  <div>
                    <span className="text-[10px] font-bold text-purple-400 uppercase tracking-wider block mb-1.5">Top Sources Overrides (%)</span>
                    <div className="space-y-1.5 bg-zinc-800/40 p-2 rounded border border-zinc-800">
                      {Object.keys(config.topSources).map((sourceKey) => (
                        <div key={sourceKey} className="flex items-center justify-between">
                          <span className="text-[11px] text-zinc-300">{sourceKey}</span>
                          <input 
                            type="number" step="0.1"
                            value={config.topSources[sourceKey] ?? ''} 
                            onChange={(e) => handleTopSourceChange(sourceKey, e.target.value)}
                            className="w-20 bg-zinc-900 border border-zinc-700 rounded px-2 py-1 text-white text-xs font-mono text-center"
                          />
                        </div>
                      ))}
                    </div>
                  </div>

                  <div>
                    <span className="text-[10px] font-bold text-purple-400 uppercase tracking-wider block mb-1.5">Country Slots Allocation & Percentages</span>
                    <div className="space-y-2 bg-zinc-800/40 p-2 rounded border border-zinc-800">
                      {config.audience.countries.map((slot, idx) => (
                        <div key={idx} className="grid grid-cols-3 gap-1.5 items-center bg-zinc-900/60 p-1.5 rounded">
                          <span className="text-[10px] text-zinc-400 font-mono">Slot {idx + 1}</span>
                          <select 
                            value={slot.country || ''}
                            onChange={(e) => handleCountrySlotChange(idx, 'country', e.target.value)}
                            className="bg-zinc-800 border border-zinc-700 rounded px-1 py-0.5 text-white text-[10px]"
                          >
                            <option value="">(Lucky Draw)</option>
                            {config.audience.countryPool.map(c => (
                              <option key={c.name} value={c.name}>{c.name}</option>
                            ))}
                          </select>
                          <input 
                            type="number" step="0.1"
                            placeholder="Pct %"
                            value={slot.percentage ?? ''}
                            onChange={(e) => handleCountrySlotChange(idx, 'percentage', e.target.value)}
                            className="bg-zinc-800 border border-zinc-700 rounded px-1 py-0.5 text-white text-[10px] font-mono text-center"
                          />
                        </div>
                      ))}
                    </div>
                  </div>

                  <div>
                    <span className="text-[10px] font-bold text-purple-400 uppercase tracking-wider block mb-1.5">Country Pool Draw Weights Matrix</span>
                    <div className="space-y-1.5 max-h-40 overflow-y-auto bg-zinc-800/40 p-2 rounded border border-zinc-800">
                      {config.audience.countryPool.map((c) => (
                        <div key={c.name} className="flex items-center justify-between text-[11px]">
                          <span className="text-zinc-300">{c.name}</span>
                          <input 
                            type="number" step="0.5" min="0" max="50"
                            value={c.weight}
                            onChange={(e) => handleCountryPoolWeightChange(c.name, e.target.value)}
                            className="w-16 bg-zinc-900 border border-zinc-700 rounded px-1.5 py-0.5 text-white font-mono text-center text-xs"
                          />
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              )}

              {/* TAB 7: MANUAL VIEWS CURVE EDITOR */}
              {configTab === 'viewsEditor' && (
                <div className="space-y-2.5 max-h-68 overflow-y-auto pr-1">
                  <div className="flex justify-between items-center mb-1">
                    <span className="text-[10px] text-zinc-400">Manual checkpoint views editor (15 Checkpoints):</span>
                    <button onClick={randomizeViewsCurve} className="text-[10px] bg-purple-600 hover:bg-purple-500 text-white px-2 py-0.5 rounded">Regenerate Jagged</button>
                  </div>
                  {computedViewsOverTime.map((pt, idx) => (
                    <div key={idx} className="grid grid-cols-3 gap-1.5 items-center bg-zinc-800/60 p-1.5 rounded">
                      <span className="font-mono text-zinc-300 font-bold text-center">{pt.time}</span>
                      <div>
                        <span className="text-[9px] text-zinc-400 block">Views</span>
                        <input 
                          type="number" 
                          value={pt.views !== null && pt.views !== undefined ? pt.views : ''} 
                          onChange={(e) => handleViewsPointChange(idx, 'views', e.target.value)}
                          className="w-full bg-zinc-900 border border-zinc-700 rounded px-1 py-0.5 text-white text-xs font-mono text-center"
                        />
                      </div>
                      <div>
                        <span className="text-[9px] text-zinc-400 block">Typical</span>
                        <input 
                          type="number" 
                          value={pt.typical !== null && pt.typical !== undefined ? pt.typical : ''} 
                          onChange={(e) => handleViewsPointChange(idx, 'typical', e.target.value)}
                          className="w-full bg-zinc-900 border border-zinc-700 rounded px-1 py-0.5 text-white text-xs font-mono text-center"
                        />
                      </div>
                    </div>
                  ))}
                </div>
              )}

            </div>
          )}
        </div>

        {/* SCROLLABLE DASHBOARD BODY WITH LOCAL LOADER SPINNER */}
        <div className="flex-1 overflow-y-auto no-scrollbar relative pb-15" style={{ overscrollBehavior: 'none', WebkitOverflowScrolling: 'touch' }}>
          
          {isLoading && (
            <div className="absolute inset-0 bg-[#0C1014]/90 backdrop-blur-sm z-50 flex items-center justify-center">
              <div className="w-9 h-9 border-2 border-zinc-600 border-t-white rounded-full animate-spin"></div>
            </div>
          )}

          {/* Video Thumbnail & Details */}
          <div className="px-4 pt-5 pb-4 border-b border-zinc-800/80">
            <div className="flex flex-col items-center">
              <div className="w-[131px] h-[231px] rounded-lg overflow-hidden bg-zinc-800 shadow-xl relative border border-white/10">
                <img src={config.reel.thumbnail} alt="Reel thumbnail" className="w-full h-full object-cover" />
                <div className="absolute inset-0 flex items-center justify-center bg-black/20">
                </div>
              </div>
              
              <p className="text-[10px] font-rome text-white text-center mt-4.5 px-2 line-clamp-1 tracking-tight">
                {config.reel.title}...
              </p>
              <p className="text-[10px] font-normal text-[#8e8e93] mt-0.5">
                {config.reel.date} · Duration {config.reel.duration}
              </p>
            </div>

            <div className="grid grid-cols-5 gap-2 mt-4 px-4 text-center">
              <div className="flex flex-col items-center space-y-0.5"><Heart className="w-4.5 h-4.5 text-white fill-white" /><span className="text-[11px] font-semibold text-white">{formatCompactNumber(calcLikes)}</span></div>
              <div className="flex flex-col items-center space-y-0.5"><MessageCircle className="w-4.5 h-4.5 text-white fill-white -scale-x-100" /><span className="text-[11px] font-semibold text-white">{formatCompactNumber(calcComments)}</span></div>
              <div className="flex flex-col items-center space-y-0.5"><Send className="w-4.5 h-4.5 text-white fill-white" /><span className="text-[11px] font-semibold text-white">{formatCompactNumber(calcShares)}</span></div>
              <div className="flex flex-col items-center space-y-0.5"><Repeat2 className="w-4.5 h-4.5 text-white stroke-[2]" /><span className="text-[11px] font-semibold text-white">{formatCompactNumber(calcReposts)}</span></div>
              <div className="flex flex-col items-center space-y-0.5"><Bookmark className="w-4.5 h-4.5 text-white fill-white" /><span className="text-[11px] font-semibold text-white">{formatCompactNumber(calcSaves)}</span></div>
            </div>
          </div>

          {/* Overview Section */}
          <div className="px-4 py-3.5 border-b border-zinc-800/80">
            <div className="flex items-center space-x-1.5 mb-5">
              <h2 className="text-[14px] font-rome text-white tracking-tight">Overview</h2>
              <Info className="w-4 h-4 text-white stroke-[2]" />
            </div>
            <div className="space-y-5">
              <div>
                <div className="flex justify-between items-center text-[12px]">
                  <span className="font-normal text-white">Views</span>
                  <span className="font-bold text-white">{(config.overview.views || 0).toLocaleString()}</span>
                </div>
                {config.overview.instagramViews !== null && (
                  <div className="flex justify-between items-center text-[9px] text-[#A2AAB4] mt-0.5">
                    <span>Instagram</span>
                    <span>{config.overview.instagramViews.toLocaleString()}</span>
                  </div>
                )}
                {config.overview.facebookViews !== null && (
                  <div className="flex justify-between items-center text-[9px] text-[#A2AAB4] mt-0.5">
                    <span>Facebook</span>
                    <span>{config.overview.facebookViews.toLocaleString()}</span>
                  </div>
                )}
              </div>

              <div className="flex justify-between items-center text-[10px]">
                <span className="font-normal text-white text-[11px]">Watch time</span>
                <span className="font-normal text-white">{config.overview.watchTime || calculateDynamicWatchTime(config.overview.views || 0, secondBySecondRetentionData, config.reel.duration)}</span>
              </div>
              <div className="flex justify-between items-center text-[10px]">
                <span className="font-normal text-white text-[11px]">Interactions</span>
                <span className="font-normal text-white">{totalInteractions.toLocaleString()}</span>
              </div>
              <div className="flex justify-between items-center text-[10px]">
                <span className="font-normal text-white text-[11px]">Profile activity</span>
                <span className="font-normal text-white">{calcFollows.toLocaleString()}</span>
              </div>
            </div>
          </div>

          {/* Views & Donut Chart Section */}
          <div className="px-4 py-4 border-b border-zinc-800/80 flex flex-col items-center">
            <div className="w-full flex items-center justify-start space-x-1.5 mb-1.5">
              <h2 className="text-[14px] font-rome text-white tracking-tight">Views</h2>
              <Info className="w-4 h-4 text-white stroke-[2]" />
            </div>

            <InstagramDonutChart 
              followerRatio={viewsSplit.followersShare} 
              centerLabel="Views" 
              centerValue={(config.overview.views || 0).toLocaleString()} 
            />

            <div className="w-full space-y-2 mt-2 px-2">
              <div className="flex items-center justify-between text-[11px]">
                <div className="flex items-center space-x-2">
                  <div className="w-2 h-2 rounded-full bg-[#DC38D1]"></div>
                  <span className="font-normal text-white">Followers</span>
                </div>
                <span className="text-white font-normal">{(viewsSplit.followersShare * 100).toFixed(1)}%</span>
              </div>
              <div className="flex items-center justify-between text-[11px]">
                <div className="flex items-center space-x-2">
                  <div className="w-2 h-2 rounded-full bg-[#7638FA]"></div>
                  <span className="font-normal text-white">Non-followers</span>
                </div>
                <span className="text-white font-normal">{(viewsSplit.nonFollowersShare * 100).toFixed(1)}%</span>
              </div>
            </div>
          </div>

          {/* Views Over Time Section */}
          <div className="px-3 py-4 border-b border-zinc-800/80">
            <h2 className="text-[14px] font-rome text-white mb-5 tracking-tight">Views over time</h2>
            
            <div className="flex space-x-1.5 mb-3">
              {['All', 'Followers', 'Non-followers'].map((tab) => (
                <button
                  key={tab}
                  onClick={() => setViewFilter(tab)}
                  className={`px-3.5 h-7 flex items-center justify-center rounded-full text-[9px] font-medium leading-none border transition-all duration-200 text-white font-rome ${
                    viewFilter === tab 
                      ? 'bg-[#2B3036] border-[#2B3036]' 
                      : 'border-neutral-700 hover:bg-neutral-800'
                  }`}
                >
                  {tab}
                </button>
              ))}
            </div>

            <div className="h-56 w-full mt-2 relative" onTouchEnd={() => setViewsIndex(undefined)} onTouchCancel={() => setViewsIndex(undefined)}>
              <ResponsiveContainer width="100%" height="100%">
                <LineChart 
                  data={currentViewsData} 
                  margin={{ top: 28, right: 10, left: -5, bottom: 0 }}
                  activeIndex={viewsIndex}
                  onMouseMove={(state) => { if (state && state.activeTooltipIndex !== undefined) setViewsIndex(state.activeTooltipIndex); }}
                  onTouchMove={(state) => { if (state && state.activeTooltipIndex !== undefined) setViewsIndex(state.activeTooltipIndex); }}
                  onMouseLeave={() => setViewsIndex(undefined)}
                >
                  <CartesianGrid strokeDasharray="3 3" stroke="#26262a" vertical={false} />
                  <XAxis dataKey="time" stroke="#9199A1" fontSize={9} tickLine={false} axisLine={false} ticks={dynamicTicks} tick={(props) => { const { x, y, payload, index } = props; return ( <text x={x} y={y + 10} fill="#9199A1" fontSize={9} textAnchor="middle" dx={index === 0 ? 15 : 0} > {payload.value} </text> ); }} />
                  <YAxis 
                    stroke="#8C939C" 
                    fontSize={8} 
                    tickLine={false} 
                    axisLine={false} 
                    domain={[
                      0, 
                      Math.max(...currentViewsData.map(d => Math.max(d.views*1.4 || 0, d.typical || 0)), 100)
                    ]}
                    ticks={[
                      0, 
                      Math.round(Math.max(...currentViewsData.map(d => Math.max(d.views*1.4 || 0, d.typical || 0)), 100) / 2), 
                      Math.max(...currentViewsData.map(d => Math.max(d.views*1.4 || 0, d.typical || 0)), 100)
                    ]}
                    tickFormatter={(val) => formatCompactNumber(val)} 
                    width={42} 
                  />

                  <Tooltip 
                    isAnimationActive={false}
                    cursor={{ stroke: '#ffffff', strokeWidth: 1, strokeDasharray: 'none' }}
                    position={{ y: 0 }}
                    active={viewsIndex !== undefined}
                    content={({ active, payload }) => {
                      if (active && payload && payload.length) {
                        const data = payload[0].payload;
                        if (data.views === null || data.views === undefined) return null;
                        return (
                          <div className="transform -translate-x-1/2 pointer-events-none">
                            <div className="bg-[#1e1e22] text-white px-3 py-1 rounded-md text-[11px] shadow-2xl border border-white/10 flex flex-col items-center whitespace-nowrap">
                              <span className="font-semibold text-[11px]">{formatCompactNumber(data.views)} views</span>
                              {data.comparison && <span className="text-[#8e8e93] text-[9px]">{data.comparison}</span>}
                            </div>
                          </div>
                        );
                      }
                      return null;
                    }} 
                  />
                  <Line type="linear" dataKey="views" stroke="#DC38D1" strokeWidth={4} dot={false} activeDot={viewsIndex !== undefined ? { r: 4, fill: '#DC38D1', stroke: '#fff', strokeWidth: 2 } : false} />
                  <Line type="linear" dataKey="typical" stroke="#8e8e93" strokeWidth={2} strokeDasharray="4 4" dot={false} activeDot={false} />
                </LineChart>
              </ResponsiveContainer>
            </div>

            <div className="flex items-center justify-center space-x-5 mt-2.5 text-[10px] text-[#8e8e93] font-normal">
              <div className="flex items-center space-x-1.5"><div className="w-2 h-2 rounded-full bg-[#d946ef]"></div><span>This reel</span></div>
              <div className="flex items-center space-x-1.5"><div className="w-2 h-2 rounded-full bg-[#8e8e93]"></div><span>Your typical reel views</span></div>
            </div>
          </div>

          {/* Top Sources of Views Section */}
          <div className="px-4 py-4 border-b border-zinc-800/80">
            <h2 className="text-[14px] font-rome text-white mt-1 mb-7 tracking-tight">Top sources of views</h2>
            <div className="space-y-3">
              {topSourcesBreakdown.map((item, idx) => (
                <div key={idx}>
                  <div className="flex justify-between text-[11px] mb-1">
                    <span className="font-normal text-white">{item.label}</span>
                    <span className="font-normal text-white">{item.percent}%</span>
                  </div>
                  <div className="w-full bg-[#26262a] h-2 rounded-full overflow-hidden">
                    <div className="bg-[#DC38D1] h-full rounded-full" style={{ width: `${item.percent}%` }}></div>
                  </div>
                </div>
              ))}
              <div className="flex justify-between items-center text-[11px] pt-1">
                <span className="font-normal text-white">Accounts reached</span>
                <span className="font-normal text-white">{(config.overview.accountsReachedOverride !== null ? config.overview.accountsReachedOverride : Math.floor((config.overview.views || 0) * 0.892)).toLocaleString()}</span>
              </div>
            </div>
          </div>

          {/* Retention Section */}
          <div className="px-4 py-4 border-b border-zinc-800/80">
            <div className="flex items-center space-x-1.5 mb-2.5">
              <h2 className="text-[14px] font-rome text-white tracking-tight">Retention</h2>
              <Info className="w-4 h-4 text-white stroke-[2]" />
            </div>

            <div className="flex justify-center my-2.5">
              <div className="w-[95px] h-[165px] rounded-lg overflow-hidden bg-zinc-800 shadow-md border border-white/10 relative">
                <img src={config.reel.thumbnail} alt="Retention frame" className="w-full h-full object-cover" />
                <div className="absolute inset-0 flex items-center justify-center bg-black/20">
                  <div className="w-6 h-6 rounded-full bg-black/70 flex items-center justify-center backdrop-blur-sm">
                    <Play className="w-3 h-3 text-white fill-white ml-0.5" />
                  </div>
                </div>
              </div>
            </div>

            <div className="h-44 w-full mt-2 relative" onTouchEnd={() => setRetentionIndex(undefined)} onTouchCancel={() => setRetentionIndex(undefined)}>
              <ResponsiveContainer width="100%" height="100%">
                <LineChart 
                  data={secondBySecondRetentionData} 
                  margin={{ top: 28, right: 10, left: -30, bottom: 0 }}
                  activeIndex={retentionIndex}
                  onMouseMove={(state) => { if (state && state.activeTooltipIndex !== undefined) setRetentionIndex(state.activeTooltipIndex); }}
                  onTouchMove={(state) => { if (state && state.activeTooltipIndex !== undefined) setRetentionIndex(state.activeTooltipIndex); }}
                  onMouseLeave={() => setRetentionIndex(undefined)}
                >
                  <CartesianGrid strokeDasharray="3 3" stroke="#26262a" vertical={false} />
                  <XAxis dataKey="time" stroke="#9199A1" fontSize={9} tickLine={false} axisLine={false} ticks={['0:00', config.reel.duration]} tick={(props) => { const { x, y, payload, index } = props; return ( <text x={x} y={y + 10} fill="#9199A1" fontSize={9} textAnchor="middle" dx={index === 0 ? 12 : 0} > {payload.value} </text> ); }} />
                  <YAxis stroke="#9199A1" fontSize={9} tickLine={false} axisLine={false} ticks={[0, 50, 100]} tickFormatter={(value) => `${value}%`}/>
                  <Tooltip 
                    isAnimationActive={false}
                    cursor={{ stroke: '#ffffff', strokeWidth: 1, strokeDasharray: 'none' }}
                    position={{ y: 0 }}
                    active={retentionIndex !== undefined}
                    content={({ active, payload }) => {
                      if (active && payload && payload.length) {
                        const data = payload[0].payload;
                        return (
                          <div className="transform -translate-x-1/2 pointer-events-none">
                            <div className="bg-[#1e1e22] text-white px-2.5 py-1 rounded-md text-[11px] shadow-2xl border border-white/10 flex flex-col items-center whitespace-nowrap">
                              <span className="font-semibold text-[11px]">{data.retention}%</span>
                              <span className="text-[#8e8e93] text-[9px]">{data.time}</span>
                            </div>
                          </div>
                        );
                      }
                      return null;
                    }} 
                  />
                  <Line type="monotone" dataKey="retention" stroke="#DC38D1" strokeWidth={4} dot={false} activeDot={retentionIndex !== undefined ? { r: 4, fill: '#d946ef', stroke: '#fff', strokeWidth: 2 } : false} />
                </LineChart>
              </ResponsiveContainer>
            </div>

            <div className="space-y-2 mt-3 pt-2 border-t border-zinc-900">
              <div className="flex justify-between text-[11px]"><span className="font-normal text-white">This reel's skip rate</span><span className="font-normal text-white">{config.overview.skipRateOverride !== null ? `${config.overview.skipRateOverride}%` : '36.2%'}</span></div>
              <div className="flex justify-between text-[11px]"><span className="font-normal text-white">Your typical skip rate</span><span className="font-normal text-white">{config.overview.typicalSkipRateOverride !== null ? `${config.overview.typicalSkipRateOverride}%` : '33.7%'}</span></div>
            </div>
          </div>

          {/* Interactions & Donut Chart Section */}
          <div className="px-4 py-4 border-b border-zinc-800/80 flex flex-col items-center">
            <div className="w-full flex items-center justify-start space-x-1.5 mb-1.5">
              <h2 className="text-[14px] font-rome text-white tracking-tight">Interactions</h2>
              <Info className="w-4 h-4 text-white stroke-[2]" />
            </div>

            <InstagramDonutChart 
              followerRatio={interactionSplit.followersShare} 
              centerLabel="Interactions" 
              centerValue={totalInteractions.toString()} 
            />

            <div className="w-full space-y-2 mt-2 px-2">
              <div className="flex items-center justify-between text-[11px]">
                <div className="flex items-center space-x-2">
                  <div className="w-2 h-2 rounded-full bg-[#DC38D1]"></div>
                  <span className="font-normal text-white">Followers</span>
                </div>
                <span className="text-white font-normal">{(interactionSplit.followersShare * 100).toFixed(1)}%</span>
              </div>
              <div className="flex items-center justify-between text-[11px]">
                <div className="flex items-center space-x-2">
                  <div className="w-2 h-2 rounded-full bg-[#7638FA]"></div>
                  <span className="font-normal text-white">Non-followers</span>
                </div>
                <span className="text-white font-normal">{(interactionSplit.nonFollowersShare * 100).toFixed(1)}%</span>
              </div>
            </div>
          </div>

          {/* When People Liked Your Reel Section */}
          <div className="px-4 py-4 border-b border-zinc-800/80">
            <h2 className="text-[14px] font-rome text-white mb-2.5 tracking-tight">When people liked your reel</h2>

            <div className="flex justify-center my-2.5">
              <div className="w-[95px] h-[165px] rounded-lg overflow-hidden bg-zinc-800 shadow-md border border-white/10 relative">
                <img src={config.reel.thumbnail} alt="Likes frame" className="w-full h-full object-cover" />
                <div className="absolute inset-0 flex items-center justify-center bg-black/20">
                  <div className="w-6 h-6 rounded-full bg-black/70 flex items-center justify-center backdrop-blur-sm">
                    <Play className="w-3 h-3 text-white fill-white ml-0.5" />
                  </div>
                </div>
              </div>
            </div>

            <div className="h-44 w-full mt-2 relative" onTouchEnd={() => setLikesIndex(undefined)} onTouchCancel={() => setLikesIndex(undefined)}>
              <ResponsiveContainer width="100%" height="100%">
                <LineChart 
                  data={secondsWiseLikesData} 
                  margin={{ top: 28, right: 10, left: -30, bottom: 0 }}
                  activeIndex={likesIndex}
                  onMouseMove={(state) => { if (state && state.activeTooltipIndex !== undefined) setLikesIndex(state.activeTooltipIndex); }}
                  onTouchMove={(state) => { if (state && state.activeTooltipIndex !== undefined) setLikesIndex(state.activeTooltipIndex); }}
                  onMouseLeave={() => setLikesIndex(undefined)}
                >
                  <CartesianGrid strokeDasharray="3 3" stroke="#26262a" vertical={false} />
                  <XAxis dataKey="time" stroke="#9199A1" fontSize={9} tickLine={false} axisLine={false} ticks={['0:00', config.reel.duration]} tick={(props) => { const { x, y, payload, index } = props; return ( <text x={x} y={y + 10} fill="#9199A1" fontSize={9} textAnchor="middle" dx={index === 0 ? 12 : 0} > {payload.value} </text> ); }} />
                  <YAxis 
                    stroke="#9199A1" 
                    fontSize={9} 
                    tickLine={false} 
                    axisLine={false} 
                    domain={[0, dynamicLikesYMax]} 
                    ticks={[0, (dynamicLikesYMax / 2), dynamicLikesYMax]}
                    tickFormatter={(value) => `${value}% `}
                  />
                  <Tooltip 
                    isAnimationActive={false}
                    cursor={{ stroke: '#ffffff', strokeWidth: 1, strokeDasharray: 'none' }}
                    position={{ y: 0 }}
                    active={likesIndex !== undefined}
                    content={({ active, payload }) => {
                      if (active && payload && payload.length) {
                        const data = payload[0].payload;
                        return (
                          <div className="transform -translate-x-1/2 pointer-events-none">
                            <div className="bg-[#1e1e22] text-white px-2.5 py-1 rounded-md text-[11px] shadow-2xl border border-white/10 flex flex-col items-center whitespace-nowrap">
                              <span className="font-semibold text-[11px]">{data.val}%</span>
                              <span className="text-[#8e8e93] text-[9px]">{data.time}</span>
                            </div>
                          </div>
                        );
                      }
                      return null;
                    }} 
                  />
                  <Line type="linear" dataKey="val" stroke="#DC38D1" strokeWidth={4} dot={false} activeDot={likesIndex !== undefined ? { r: 4, fill: '#d946ef', stroke: '#fff', strokeWidth: 2 } : false} />
                </LineChart>
              </ResponsiveContainer>
            </div>

            <div className="space-y-3 mt-3 pt-2.5 border-t border-zinc-900">
              <div className="flex justify-between items-center text-[12px]"><span className="font-normal text-white">Likes</span><span className="font-normal text-white">{calcLikes.toLocaleString()}</span></div>
              <div className="flex justify-between items-center text-[12px]"><span className="font-normal text-white">Comments</span><span className="font-normal text-white">{calcComments.toLocaleString()}</span></div>
              <div className="flex justify-between items-center text-[12px]"><span className="font-normal text-white">Reposts</span><span className="font-normal text-white">{calcReposts.toLocaleString()}</span></div>
              <div className="flex justify-between items-center text-[12px]"><span className="font-normal text-white">Saves</span><span className="font-normal text-white">{calcSaves.toLocaleString()}</span></div>
              <div className="flex justify-between items-center text-[12px]"><span className="font-normal text-white">Shares</span><span className="font-normal text-white">{calcShares.toLocaleString()}</span></div>
            </div>
          </div>

          {/* Profile Activity Section */}
          <div className="px-4 py-4 border-b border-zinc-800/80">
            <div className="flex items-center space-x-1.5 mb-2.5">
              <h2 className="text-[14px] font-rome text-white tracking-tight">Profile activity</h2>
              <Info className="w-4 h-4 text-white stroke-[2]" />
            </div>
            <div className="flex justify-between items-center text-[12px]"><span className="font-normal text-white">Follows</span><span className="font-normal text-white">{calcFollows}</span></div>
          </div>

          {/* Audience Section */}
          <div className="px-4 py-4">
            <div className="flex items-center space-x-1.5 mb-2.5">
              <h2 className="text-[14px] font-rome text-white tracking-tight">Audience</h2>
              <Info className="w-4 h-4 text-white stroke-[2]" />
            </div>

            <div className="flex space-x-1.5 mb-5">
              {['Gender', 'Country', 'Age'].map((tab) => (
                <button
                  key={tab}
                  onClick={() => setAudienceTab(tab)}
                  className={`px-3.5 h-7 flex items-center justify-center rounded-full text-[9px] font-medium leading-none border transition-all duration-200 text-white font-rome ${
                    audienceTab === tab 
                      ? 'bg-[#2B3036] border-[#2B3036]' 
                      : 'border-neutral-700 hover:bg-neutral-800'
                  }`}
                >
                  {tab}
                </button>
              ))}
            </div>

            {audienceTab === 'Gender' && (
              <div className="space-y-3">
                {genderBreakdown.map((item, idx) => (
                  <div key={idx}>
                    <div className="flex justify-between text-[11px] mb-1"><span className="font-normal text-white">{item.label}</span><span className="percent">{item.percent}%</span></div>
                    <div className="w-full bg-[#26262a] h-2 rounded-full overflow-hidden">
                      <div 
                        className={`h-full rounded-full ${item.label === 'Women' ? 'bg-[#7638FA]' : 'bg-[#DC38D1]'}`} 
                        style={{ width: `${item.percent}%` }}
                      ></div>
                    </div>
                  </div>
                ))}
              </div>
            )}

            {audienceTab === 'Country' && (
              <div className="space-y-3">
                {countryBreakdown.map((item, idx) => (
                  <div key={idx}>
                    <div className="flex justify-between text-[9.5px] mb-1"><span className="font-normal text-white">{item.label}</span><span className="font-rome text-white">{item.percent}%</span></div>
                    <div className="w-full bg-[#26262a] h-2 rounded-full overflow-hidden"><div className="bg-[#DC38D1] h-full rounded-full" style={{ width: `${item.percent}%` }}></div></div>
                  </div>
                ))}
              </div>
            )}

            {audienceTab === 'Age' && (
              <div className="space-y-2.5">
                {ageBreakdown.map((item, idx) => (
                  <div key={idx}>
                    <div className="flex justify-between text-[9.5px] mb-1"><span className="font-normal text-white">{item.label}</span><span className="font-rome text-white">{item.percent}%</span></div>
                    <div className="w-full bg-[#26262a] h-2 rounded-full overflow-hidden"><div className="bg-[#DC38D1] h-full rounded-full" style={{ width: `${item.percent}%` }}></div></div>
                  </div>
                ))}
              </div>
            )}

          </div>

        </div>

      </div>
    </div>
  );
}
