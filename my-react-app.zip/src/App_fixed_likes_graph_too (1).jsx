import React, { useState } from 'react';
import { 
  ArrowLeft, 
  MoreVertical, 
  Heart, 
  MessageCircle, 
  Send, 
  Repeat2, 
  Bookmark, 
  Info,
  Play,
  Dice5
} from 'lucide-react';
import { 
  ResponsiveContainer, 
  LineChart, 
  Line, 
  XAxis, 
  YAxis, 
  Tooltip, 
  CartesianGrid 
} from 'recharts';

// ==========================================
// CENTRALIZED CONFIGURATION & GENERATOR STORE
// ==========================================
const DASHBOARD_CONFIG = {
  seed: 1337,
  reel: {
    thumbnail: 'https://images.unsplash.com/photo-1514525253161-7a46d19cd819?q=80&w=400&auto=format&fit=crop',
    title: 'Brantley Gilbert celebrated the release of his 8th studio album "SINS OF...',
    date: 'October 15',
    duration: '1:38',
    likes: null,       
    comments: null,    
    shares: null,      
    reposts: null,     
    saves: null,       
    follows: null      
  },
  // Strict Parameter Flags & Stochastic Chance Weights
  videoBehaviors: {
    hasBadHook: false,      // Explicit boolean flag (true = forces bad hook drop, false = strictly no bad hook effect)
    hasDeadAir: false,      // Explicit boolean flag (true = forces dead air dips, false = no dead air)
    isBoring: false,        // Explicit boolean flag (true = accelerates slope, false = normal slope)
    stochasticChance: 0.35, // Weighted chance probability (0.0 to 1.0) when evaluated stochastically
    chaosVolatility: 1.0    // Global random multiplier for subtractive noise/spikes
  },
  overview: {
    views: 51399,
    watchTime: '2h 2m 37s',
    interactions: null 
  },
  splitRatios: {
    followersShare: 0.07,     
    nonFollowersShare: 0.93   
  },
  viewsOverTime: [
    { time: '0h', views: 0, typical: 0 },
    { time: '2h', views: 320, typical: 400 },
    { time: '4h', views: 790, typical: 650 },
    { time: '6h', views: 1450, typical: 900 },
    { time: '8h', views: 1680, typical: 1100 },
    { time: '11h', views: 3794, typical: 1400 },
    { time: '13h', views: 3950, typical: 1500 },
    { time: '15h', views: 4200, typical: 1800 },
    { time: '18h', views: null, typical: null },
    { time: '20h', views: null, typical: null },
    { time: '22h', views: null, typical: null }
  ],
  topSources: {
    'Reels tab': null,
    'Feed': null,
    'Explore': null,
    'Profile': null
  },
  audience: {
    gender: {
      'Men': null,
      'Women': null
    },
    countryPool: [
      { name: 'United States', weight: 12.0 },
      { name: 'United Kingdom', weight: 7.5 },
      { name: 'Canada', weight: 7.0 },
      { name: 'Australia', weight: 6.5 },
      { name: 'India', weight: 5.5 },
      { name: 'Germany', weight: 4.5 },
      { name: 'Brazil', weight: 4.0 },
      { name: 'France', weight: 3.5 },
      { name: 'Mexico', weight: 3.2 },
      { name: 'Philippines', weight: 3.0 },
      { name: 'Indonesia', weight: 2.2 },
      { name: 'Vietnam', weight: 1.8 },
      { name: 'Pakistan', weight: 1.5 },
      { name: 'Egypt', weight: 1.2 },
      { name: 'Nigeria', weight: 1.0 },
      { name: 'Gabon', weight: 0.4 }
    ],
    countries: [
      { country: 'United States', percentage: null },
      { country: null, percentage: null },
      { country: null, percentage: null },
      { country: null, percentage: null },
      { country: null, percentage: null }
    ],
    age: {
      '13-17': null,
      '18-24': null,
      '25-34': null,
      '35-44': null,
      '45-54': null,
      '55-64': null,
      '65+': null
    }
  }
};

const createSeededRandom = (seed) => {
  let s = seed % 2147483647;
  if (s <= 0) s += 2147483646;
  return () => {
    s = (s * 16807) % 2147483647;
    return (s - 1) / 2147483646;
  };
};

const createSubtractivePerlinNoise1D = (seed) => {
  const rng = createSeededRandom(seed);
  const permutationSize = 256;
  const p = new Array(permutationSize * 2);
  const permutation = [];
  
  for (let i = 0; i < permutationSize; i++) permutation[i] = i;
  for (let i = permutationSize - 1; i > 0; i--) {
    const j = Math.floor(rng() * (i + 1));
    [permutation[i], permutation[j]] = [permutation[j], permutation[i]];
  }
  for (let i = 0; i < permutationSize; i++) {
    p[i] = permutation[i];
    p[permutationSize + i] = permutation[i];
  }

  const fade = (t) => t * t * t * (t * (t * 6 - 15) + 10);
  const lerp = (t, a, b) => a + t * (b - a);
  const grad = (hash, x) => (hash & 1 ? x : -x);

  return (x) => {
    const X = Math.floor(x) & 255;
    x -= Math.floor(x);
    const u = fade(x);
    const a = p[X];
    const b = p[X + 1];
    const raw = lerp(u, grad(p[a], x), grad(p[b], x - 1));
    return Math.abs(raw);
  };
};

const parseDurationToSeconds = (durationStr) => {
  if (!durationStr) return 60;
  const parts = durationStr.split(':').map(Number);
  if (parts.length === 2) return parts[0] * 60 + parts[1];
  if (parts.length === 1) return parts[0];
  return 60;
};

const formatSecondsToTimestamp = (sec) => {
  const mins = Math.floor(sec / 60);
  const secs = sec % 60;
  return `${mins}:${secs < 10 ? '0' : ''}${secs}`;
};

// Your Custom Volatile Organic Retention Generator
const generateOrganicVolatileRetention = (durationStr, seed, behaviors) => {
  const rng = createSeededRandom(seed);
  const perlinSubtractive = createSubtractivePerlinNoise1D(seed);
  const totalSeconds = parseDurationToSeconds(durationStr);
  const points = [];

  const badHookActive = behaviors.hasBadHook === true || (behaviors.hasBadHook !== false && rng() < behaviors.stochasticChance);
  const deadAirActive = behaviors.hasDeadAir === true || (behaviors.hasDeadAir !== false && rng() < behaviors.stochasticChance);
  const boringActive = behaviors.isBoring === true || (behaviors.isBoring !== false && rng() < behaviors.stochasticChance);
  const volatility = behaviors.chaosVolatility;

  let currentVal = 100.0;
  const junctionSec = Math.max(8, Math.floor(totalSeconds * 0.18));

  for (let sec = 0; sec <= totalSeconds; sec++) {
    if (sec === 0) {
      points.push({ time: formatSecondsToTimestamp(0), second: 0, retention: 100.0 });
      continue;
    }

    let dropAmount = 0.0;

    if (sec <= 8) {
      let initialDrop = badHookActive ? 4.0 : 3.5;
      dropAmount = (initialDrop + rng() * 2.5) * volatility;
    } 
    else if (sec <= junctionSec) {
      const progress = (sec - 3) / (junctionSec - 3);
      let baseSpeed = 1.2;
      if (badHookActive) baseSpeed = 1.8;
      
      dropAmount = (Math.pow(progress, 0.8) * baseSpeed + 0.3) * volatility;
    } else {
      const remainingSecs = totalSeconds - junctionSec;
      const elapsed = sec - junctionSec;
      const progress = elapsed / remainingSecs;

      const boringMultiplier = boringActive ? 2.0 : 1.0;
      const baseSlope = (Math.pow(progress, 0.9) * 0.4 * boringMultiplier + 0.05);
      const perlinSub = perlinSubtractive(sec * 0.008) * 1.1 * volatility;
      
      let randomSpike = 0;
      if (rng() < 0.18) {
        randomSpike = (rng() * 3.9 + 1.0) * volatility;
      }

      if (deadAirActive && rng() < 0.25 && sec % 8 === 0) {
        randomSpike += (rng() * 2.5 + 1.5) * volatility;
      }

      dropAmount = baseSlope * volatility + perlinSub + randomSpike;
    }

    currentVal = Math.max(0.5, currentVal - dropAmount);

    points.push({
      time: formatSecondsToTimestamp(sec),
      second: sec,
      retention: Number(currentVal.toFixed(1))
    });
  }

  return points;
};

// Real Instagram-authentic Perlin & Weight-driven Likes Distribution Generator
const generateSecondsWiseLikesInteraction = (durationStr, seed, totalLikes) => {
  const rng = createSeededRandom(seed + 99);
  const perlinNoise = createSubtractivePerlinNoise1D(seed + 55);
  const totalSeconds = parseDurationToSeconds(durationStr);
  
  const likeCountsPerSecond = new Array(totalSeconds + 1).fill(0);
  let remainingLikes = totalLikes;

  const weights = new Array(totalSeconds + 1).fill(0);
  const finalSpikeSec = totalSeconds;
  const secondarySpikeSec = Math.floor(totalSeconds * (0.5 + rng() * 0.2)); // Middle spike

  for (let sec = 0; sec <= totalSeconds; sec++) {
    // Base organic Perlin noise hum
    const noiseVal = perlinNoise(sec * 0.08);
    let w = noiseVal * 1.5 + 0.2; 

    // 1. Heavy early hook bias at the very beginning (0s to 3s)
    if (sec <= 3) {
      w += (4 - sec) * 4.5;
    }

    // 2. Ending spike gravity well
    const distToFinal = Math.abs(sec - finalSpikeSec);
    if (distToFinal <= 2) {
      w += (3 - distToFinal) * 6.0;
    }

    // 3. Optional secondary mid spike
    const distToMid = Math.abs(sec - secondarySpikeSec);
    if (distToMid <= 2) {
      w += (3 - distToMid) * 3.0;
    }

    weights[sec] = Math.max(0.01, w);
  }

  const totalWeight = weights.reduce((acc, w) => acc + w, 0);

  // Distribute individual likes based on weights
  while (remainingLikes > 0) {
    let r = rng() * totalWeight;
    let cumulative = 0;
    let chosenSec = 0;

    for (let sec = 0; sec <= totalSeconds; sec++) {
      cumulative += weights[sec];
      if (r <= cumulative) {
        chosenSec = sec;
        break;
      }
    }

    likeCountsPerSecond[chosenSec] += 1;
    remainingLikes -= 1;
  }

  // Convert individual counts into precise percentages summing organically
  return likeCountsPerSecond.map((count, sec) => {
    const percentage = totalLikes > 0 ? Number(((count / totalLikes) * 100).toFixed(1)) : 0.0;
    return {
      time: formatSecondsToTimestamp(sec),
      second: sec,
      val: percentage
    };
  });
};


const processPercentageBreakdown = (obj, seed, weights = {}, sortDescending = true) => {
  const rng = createSeededRandom(seed);
  const keys = Object.keys(obj);
  const explicitEntries = Object.entries(obj).filter(([_, val]) => val !== null && val !== undefined);
  
  let explicitSum = explicitEntries.reduce((acc, [_, val]) => acc + Number(val), 0);
  const nullKeys = keys.filter(k => obj[k] === null || obj[k] === undefined);

  let result = {};

  if (nullKeys.length === 0) {
    const scale = 100 / explicitSum;
    keys.forEach(k => {
      result[k] = Number((obj[k] * scale).toFixed(1));
    });
  } else {
    let remaining = Math.max(0, 100 - explicitSum);
    const calculatedWeights = {};
    let totalWeight = 0;

    nullKeys.forEach(k => {
      const baseWeight = weights[k] !== undefined ? weights[k] : 1;
      const w = baseWeight * (0.85 + rng() * 0.3);
      calculatedWeights[k] = w;
      totalWeight += w;
    });

    explicitEntries.forEach(([k, val]) => {
      result[k] = Number(val);
    });

    nullKeys.forEach((k, idx) => {
      if (idx === nullKeys.length - 1) {
        const assignedSum = Object.entries(result).reduce((acc, [ky, v]) => ky !== k ? acc + v : acc, 0);
        result[k] = Number(Math.max(0, 100 - assignedSum).toFixed(1));
      } else {
        const val = (calculatedWeights[k] / totalWeight) * remaining;
        result[k] = Number(val.toFixed(1));
      }
    });
  }

  const entriesArray = Object.entries(result).map(([label, percent]) => ({ label, percent }));
  if (sortDescending) {
    entriesArray.sort((a, b) => b.percent - a.percent);
  }
  return entriesArray;
};

const processCountryBreakdownWithLuckyDraw = (countriesSlots, countryPool, seed) => {
  const rng = createSeededRandom(seed);
  const randomTargetSum = 50 + rng() * 15; 

  let assignedCountries = [];
  let explicitSum = 0;

  countriesSlots.forEach(slot => {
    if (slot.country) {
      const explicitPct = slot.percentage !== null && slot.percentage !== undefined ? Number(slot.percentage) : null;
      assignedCountries.push({ name: slot.country, percentage: explicitPct });
      if (explicitPct !== null) explicitSum += explicitPct;
    }
  });

  const slotsNeedingCountry = countriesSlots.filter(s => !s.country);
  const remainingTarget = Math.max(0, randomTargetSum - explicitSum);

  if (slotsNeedingCountry.length > 0 || assignedCountries.some(c => c.percentage === null)) {
    let availablePool = [...countryPool].filter(c => !assignedCountries.some(ac => ac.name === c.name));
    let selectedLuckyCountries = [];

    slotsNeedingCountry.forEach(() => {
      if (availablePool.length === 0) return;
      const totalPoolWeight = availablePool.reduce((acc, c) => acc + c.weight, 0);
      let randVal = rng() * totalPoolWeight;
      let cumulative = 0;
      let winnerIndex = 0;

      for (let i = 0; i < availablePool.length; i++) {
        cumulative += availablePool[i].weight;
        if (randVal <= cumulative) {
          winnerIndex = i;
          break;
        }
      }
      selectedLuckyCountries.push(availablePool.splice(winnerIndex, 1)[0]);
    });

    let toCalculate = [
      ...assignedCountries.filter(c => c.percentage === null).map(c => {
        const poolMatch = countryPool.find(p => p.name === c.name);
        return { name: c.name, baseWeight: poolMatch ? poolMatch.weight : 5.0 };
      }),
      ...selectedLuckyCountries.map(c => ({ name: c.name, baseWeight: c.weight }))
    ];

    if (toCalculate.length > 0) {
      const winnerIndex = Math.floor(rng() * toCalculate.length);
      const scored = toCalculate.map((item, idx) => ({
        name: item.name,
        luckyScore: item.baseWeight * (idx === winnerIndex ? (2.2 + rng() * 1.5) : (0.4 + rng() * 0.7))
      }));

      const totalLuckyScore = scored.reduce((acc, s) => acc + s.luckyScore, 0);
      let calculatedUnassignedSum = 0;

      scored.forEach((s, idx) => {
        const share = idx === scored.length - 1 
          ? Math.max(0, remainingTarget - calculatedUnassignedSum)
          : Number(((s.luckyScore / totalLuckyScore) * remainingTarget).toFixed(1));
        
        calculatedUnassignedSum += share;

        const existing = assignedCountries.find(ac => ac.name === s.name);
        if (existing) existing.percentage = share;
        else assignedCountries.push({ name: s.name, percentage: share });
      });
    }
  }

  let finalResult = {};
  assignedCountries.forEach(ac => {
    finalResult[ac.name] = Number((ac.percentage || 0).toFixed(1));
  });

  return Object.entries(finalResult)
    .map(([label, percent]) => ({ label, percent }))
    .sort((a, b) => b.percent - a.percent);
};

const getComparisonText = (val, typical) => {
  if (typical === 0 || typical === undefined || val === null || val === undefined) return null;
  const diff = Math.round(((val - typical) / typical) * 100);
  if (diff === 0) return 'Same as typical';
  if (diff > 0) return `${diff}% higher than typical`;
  return `${Math.abs(diff)}% lower than typical`;
};

const nullifyViewsAfterMiddle = (viewsData, seed) => {
  const rng = createSeededRandom(seed);
  const midIndex = Math.floor(viewsData.length / 2);
  
  return viewsData.map((item, idx) => {
    let viewsVal = item.views;
    let typicalVal = item.typical;

    if (idx > midIndex) {
      viewsVal = null;
    } else if (viewsVal === null || viewsVal === undefined) {
      viewsVal = Math.round(idx * 450 + rng() * 100);
    }

    if (typicalVal === null || typicalVal === undefined) {
      typicalVal = Math.round(idx * 300 + rng() * 80);
    }

    return { ...item, views: viewsVal, typical: typicalVal };
  });
};

const generateSplitDatasets = (processedViews, ratioF, seed) => {
  const rng = createSeededRandom(seed);
  const followersData = [];
  const nonFollowersData = [];

  processedViews.forEach((item, index) => {
    const totalViews = item.views;
    const totalTypical = item.typical;

    if (totalViews === null || totalViews === undefined) {
      followersData.push({ time: item.time, views: null, typical: Math.round(totalTypical * ratioF), comparison: null });
      nonFollowersData.push({ time: item.time, views: null, typical: Math.round(totalTypical * (1 - ratioF)), comparison: null });
      return;
    }

    if (index === 0 || index === processedViews.length - 1) {
      const fViews = Math.round(totalViews * ratioF);
      const fTypical = Math.round(totalTypical * ratioF);
      followersData.push({ time: item.time, views: fViews, typical: fTypical, comparison: getComparisonText(fViews, fTypical) });
      nonFollowersData.push({ time: item.time, views: totalViews - fViews, typical: totalTypical - fTypical, comparison: getComparisonText(totalViews - fViews, totalTypical - fTypical) });
    } else {
      const prevF = followersData[index - 1]?.views || Math.round(totalViews * ratioF);
      const targetF = Math.round(totalViews * ratioF);
      const variance = (rng() - 0.45) * 45;
      const fViews = Math.max(prevF, Math.round(targetF + variance));
      
      const prevFTyp = followersData[index - 1]?.typical || Math.round(totalViews * ratioF);
      const targetFTyp = Math.round(totalViews * ratioF);
      const fTypical = Math.max(prevFTyp, Math.round(targetFTyp + variance * 0.5));

      followersData.push({ time: item.time, views: fViews, typical: fTypical, comparison: getComparisonText(fViews, fTypical) });

      const nfViews = totalViews - fViews;
      const nfTypical = totalTypical - fTypical;
      nonFollowersData.push({ time: item.time, views: nfViews, typical: nfTypical, comparison: getComparisonText(nfViews, nfTypical) });
    }
  });

  return { followersData, nonFollowersData };
};

export default function ReelInsightsDashboard() {
  const [viewFilter, setViewFilter] = useState('All');
  const [audienceTab, setAudienceTab] = useState('Gender');
  const [showConfigPanel, setShowConfigPanel] = useState(false);
  
  const [config, setConfig] = useState(DASHBOARD_CONFIG);

  const [viewsIndex, setViewsIndex] = useState(undefined);
  const [retentionIndex, setRetentionIndex] = useState(undefined);
  const [likesIndex, setLikesIndex] = useState(undefined);

  const rng = createSeededRandom(config.seed);
  const totalViews = config.overview.views;

  const totalLikes = config.reel.likes !== null ? config.reel.likes : Math.max(1, Math.round(totalViews * (0.007 + rng() * 0.006))); 
  const totalComments = config.reel.comments !== null ? config.reel.comments : Math.max(0, Math.round(totalViews * (0.0002 + rng() * 0.0004))); 
  const totalShares = config.reel.shares !== null ? config.reel.shares : Math.max(0, Math.round(totalViews * (0.0006 + rng() * 0.0008))); 
  const totalReposts = config.reel.reposts !== null ? config.reel.reposts : Math.max(0, Math.round(totalViews * (0.0003 + rng() * 0.0004))); 
  const totalSaves = config.reel.saves !== null ? config.reel.saves : Math.max(0, Math.round(totalViews * (0.0006 + rng() * 0.0008))); 
  const totalFollows = config.reel.follows !== null ? config.reel.follows : Math.max(0, Math.round(totalViews * (0.0001 + rng() * 0.0003))); 
  
  const totalInteractions = config.overview.interactions !== null 
    ? config.overview.interactions 
    : (totalLikes + totalComments + totalShares + totalReposts + totalSaves);

  const ageWeights = { '13-17': 0.15, '18-24': 2.5, '25-34': 3.5, '35-44': 2.0, '45-54': 0.8, '55-64': 0.3, '65+': 0.05 };
  const genderWeights = { 'Men': 3.0, 'Women': 1.0 };

  const genderBreakdown = processPercentageBreakdown(config.audience.gender, config.seed + 1, genderWeights, true);
  const countryBreakdown = processCountryBreakdownWithLuckyDraw(config.audience.countries, config.audience.countryPool, config.seed + 2);
  const ageBreakdown = processPercentageBreakdown(config.audience.age, config.seed + 3, ageWeights, false);

  const topSourcesWeights = { 'Reels tab': 60.0, 'Feed': 30.0, 'Explore': 8.0, 'Profile': 0.05 };
  const topSourcesBreakdown = processPercentageBreakdown(config.topSources, config.seed + 4, topSourcesWeights, true);

  // Retention and Synchronized Seconds-Wise Likes Data with Early Hook Spike & Intermediate Peaks
  const secondBySecondRetentionData = generateOrganicVolatileRetention(config.reel.duration, config.seed + 5, config.videoBehaviors);
  const secondsWiseLikesData = generateSecondsWiseLikesInteraction(config.reel.duration, config.seed + 6, totalLikes);

  // Dynamic Y-axis calculation for Likes graph
  const maxLikeVal = Math.max(...secondsWiseLikesData.map(d => d.val), 15);
  const dynamicLikesYMax = Math.ceil(maxLikeVal / 10) * 10;

  const processedRawViews = nullifyViewsAfterMiddle(config.viewsOverTime, config.seed);
  const totalViewsOverTimeData = processedRawViews.map(item => ({ ...item, comparison: getComparisonText(item.views, item.typical) }));

  const { followersData, nonFollowersData } = generateSplitDatasets(processedRawViews, config.splitRatios.followersShare, config.seed);

  const getCurrentViewsData = () => {
    if (viewFilter === 'Followers') return followersData;
    if (viewFilter === 'Non-followers') return nonFollowersData;
    return totalViewsOverTimeData;
  };

  const currentViewsData = getCurrentViewsData();

  const handleBehaviorChange = (key, val) => {
    setConfig(prev => ({
      ...prev,
      videoBehaviors: {
        ...prev.videoBehaviors,
        [key]: val
      }
    }));
  };

  const handleChanceChange = (val) => {
    setConfig(prev => ({
      ...prev,
      videoBehaviors: {
        ...prev.videoBehaviors,
        stochasticChance: Number(val)
      }
    }));
  };

  const handleVolatilityChange = (val) => {
    setConfig(prev => ({
      ...prev,
      videoBehaviors: {
        ...prev.videoBehaviors,
        chaosVolatility: Number(val)
      }
    }));
  };

  const randomizeSeed = () => {
    const randomSeedVal = Math.floor(Math.random() * 999999) + 1;
    setConfig(prev => ({ ...prev, seed: randomSeedVal }));
  };

  return (
    <div className="min-h-screen bg-[#0d0e11] text-white font-sans flex flex-col items-center pb-12 select-none antialiased [-webkit-font-smoothing:antialiased]">
      
      {/* Main Container */}
      <div className="w-full max-w-[430px] bg-[#0d0e11] min-h-screen flex flex-col border-x border-zinc-900 shadow-2xl relative">
        
        {/* Sticky Header Wrapper (Header + Floating Editor stay glued together) */}
        <div className="sticky top-0 z-30 bg-[#0d0e11]/98 backdrop-blur border-b border-zinc-900/60">
          <div className="flex items-center justify-between px-3.5 py-2.5">
            <div className="flex items-center space-x-3.5">
              <button className="text-white hover:text-zinc-300 transition-colors">
                <ArrowLeft className="w-5 h-5 stroke-[2]" />
              </button>
              <h1 className="text-[16px] font-bold tracking-tight text-white">Reel insights</h1>
            </div>
            
            {/* 3-dots button toggles the parameter editor panel */}
            <button 
              onClick={() => setShowConfigPanel(!showConfigPanel)}
              className="text-white hover:text-zinc-300 transition-colors p-1 rounded-full hover:bg-zinc-800 cursor-pointer"
              title="Toggle Parameter Editor"
            >
              <MoreVertical className="w-4.5 h-4.5 stroke-[2]" />
            </button>
          </div>

          {/* Strict Parameter Editor Panel (Anchored directly inside sticky header wrapper) */}
          {showConfigPanel && (
            <div className="absolute right-3.5 top-12 w-72 bg-zinc-900 border border-zinc-800 p-4 rounded-xl shadow-2xl text-[12px] z-40 space-y-3">
              <div className="flex justify-between items-center border-b border-zinc-800 pb-2">
                <h3 className="font-bold text-white text-[13px]">Strict Subtractive Parameters</h3>
                <button 
                  onClick={() => setShowConfigPanel(false)}
                  className="text-zinc-400 hover:text-white text-xs font-bold"
                >
                  ✕
                </button>
              </div>

              <div className="flex items-center justify-between">
                <span className="text-[11px] text-zinc-300">Random Seed</span>
                <div className="flex items-center space-x-1.5">
                  <input 
                    type="number" 
                    value={config.seed} 
                    onChange={(e) => {
                      const newSeed = Number(e.target.value) || 1;
                      setConfig(prev => ({ ...prev, seed: newSeed }));
                    }}
                    className="w-16 bg-zinc-800 border border-zinc-700 rounded px-1.5 py-1 text-white text-center font-mono text-xs"
                  />
                  <button 
                    onClick={randomizeSeed}
                    className="bg-purple-600 hover:bg-purple-500 text-white p-1 rounded flex items-center justify-center transition-colors cursor-pointer"
                    title="Randomize Seed"
                  >
                    <Dice5 className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>

              <div className="flex items-center justify-between">
                <span className="text-[11px] text-zinc-300">Stochastic Chance (0 - 1)</span>
                <input 
                  type="number" 
                  step="0.05" 
                  min="0" 
                  max="1"
                  value={config.videoBehaviors.stochasticChance} 
                  onChange={(e) => handleChanceChange(e.target.value)}
                  className="w-20 bg-zinc-800 border border-zinc-700 rounded px-2 py-1 text-white text-center font-mono"
                />
              </div>

              <div className="flex items-center justify-between">
                <span className="text-[11px] text-zinc-300">Chaos Volatility</span>
                <input 
                  type="number" 
                  step="0.1" 
                  min="0.2" 
                  max="3.0"
                  value={config.videoBehaviors.chaosVolatility} 
                  onChange={(e) => handleVolatilityChange(e.target.value)}
                  className="w-20 bg-zinc-800 border border-zinc-700 rounded px-2 py-1 text-white text-center font-mono"
                />
              </div>

              <div className="pt-2 border-t border-zinc-800 space-y-2.5">
                <div className="flex items-center justify-between">
                  <span className="text-[11px] text-zinc-300">hasBadHook</span>
                  <select 
                    value={String(config.videoBehaviors.hasBadHook)}
                    onChange={(e) => {
                      const val = e.target.value === 'null' ? null : e.target.value === 'true';
                      handleBehaviorChange('hasBadHook', val);
                    }}
                    className="bg-zinc-800 border border-zinc-700 rounded px-2 py-1 text-white text-xs font-mono"
                  >
                    <option value="true">true (Forced)</option>
                    <option value="false">false (Disabled)</option>
                    <option value="null">stochastic (Chance)</option>
                  </select>
                </div>

                <div className="flex items-center justify-between">
                  <span className="text-[11px] text-zinc-300">hasDeadAir</span>
                  <select 
                    value={String(config.videoBehaviors.hasDeadAir)}
                    onChange={(e) => {
                      const val = e.target.value === 'null' ? null : e.target.value === 'true';
                      handleBehaviorChange('hasDeadAir', val);
                    }}
                    className="bg-zinc-800 border border-zinc-700 rounded px-2 py-1 text-white text-xs font-mono"
                  >
                    <option value="true">true (Forced)</option>
                    <option value="false">false (Disabled)</option>
                    <option value="null">stochastic (Chance)</option>
                  </select>
                </div>

                <div className="flex items-center justify-between">
                  <span className="text-[11px] text-zinc-300">isBoring</span>
                  <select 
                    value={String(config.videoBehaviors.isBoring)}
                    onChange={(e) => {
                      const val = e.target.value === 'null' ? null : e.target.value === 'true';
                      handleBehaviorChange('isBoring', val);
                    }}
                    className="bg-zinc-800 border border-zinc-700 rounded px-2 py-1 text-white text-xs font-mono"
                  >
                    <option value="true">true (Forced)</option>
                    <option value="false">false (Disabled)</option>
                    <option value="null">stochastic (Chance)</option>
                  </select>
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Video Thumbnail & Details */}
        <div className="px-4 pt-3 pb-4 border-b border-zinc-800/80">
          <div className="flex flex-col items-center">
            <div className="w-[105px] h-[185px] rounded-lg overflow-hidden bg-zinc-800 shadow-xl relative border border-white/10">
              <img src={config.reel.thumbnail} alt="Reel thumbnail" className="w-full h-full object-cover" />
              <div className="absolute inset-0 flex items-center justify-center bg-black/20">
                <div className="w-7 h-7 rounded-full bg-black/70 flex items-center justify-center backdrop-blur-sm">
                  <Play className="w-3.5 h-3.5 text-white fill-white ml-0.5" />
                </div>
              </div>
            </div>
            
            <p className="text-[11px] font-semibold text-white text-center mt-2.5 px-2 line-clamp-1 tracking-tight">
              {config.reel.title}
            </p>
            <p className="text-[10px] font-normal text-[#8e8e93] mt-0.5">
              {config.reel.date} · Duration {config.reel.duration}
            </p>
          </div>

          <div className="grid grid-cols-5 gap-2 mt-4 px-4 text-center">
            <div className="flex flex-col items-center space-y-0.5"><Heart className="w-4.5 h-4.5 text-white fill-white" /><span className="text-[11px] font-semibold text-white">{totalLikes}</span></div>
            <div className="flex flex-col items-center space-y-0.5"><MessageCircle className="w-4.5 h-4.5 text-white fill-white -scale-x-100" /><span className="text-[11px] font-semibold text-white">{totalComments}</span></div>
            <div className="flex flex-col items-center space-y-0.5"><Send className="w-4.5 h-4.5 text-white fill-white" /><span className="text-[11px] font-semibold text-white">{totalShares}</span></div>
            <div className="flex flex-col items-center space-y-0.5"><Repeat2 className="w-4.5 h-4.5 text-white stroke-[2]" /><span className="text-[11px] font-semibold text-white">{totalReposts}</span></div>
            <div className="flex flex-col items-center space-y-0.5"><Bookmark className="w-4.5 h-4.5 text-white fill-white" /><span className="text-[11px] font-semibold text-white">{totalSaves}</span></div>
          </div>
        </div>

        {/* Overview Section */}
        <div className="px-4 py-3.5 border-b border-zinc-800/80">
          <div className="flex items-center space-x-1.5 mb-3">
            <h2 className="text-[13px] font-semibold text-white tracking-tight">Overview</h2>
            <Info className="w-3.5 h-3.5 text-[#8e8e93] stroke-[2]" />
          </div>
          <div className="space-y-3">
            <div className="flex justify-between items-center text-[12px]"><span className="font-normal text-white">Views</span><span className="font-normal text-white">{config.overview.views.toLocaleString()}</span></div>
            <div className="flex justify-between items-center text-[12px]"><span className="font-normal text-white">Watch time</span><span className="font-normal text-white">{config.overview.watchTime}</span></div>
            <div className="flex justify-between items-center text-[12px]"><span className="font-normal text-white">Interactions</span><span className="font-normal text-white">{totalInteractions}</span></div>
            <div className="flex justify-between items-center text-[12px]"><span className="font-normal text-white">Profile activity</span><span className="font-normal text-white">{totalFollows}</span></div>
          </div>
        </div>

        {/* Views & Donut Chart Section */}
        <div className="px-4 py-4 border-b border-zinc-800/80 flex flex-col items-center">
          <div className="w-full flex items-center justify-start space-x-1.5 mb-1.5">
            <h2 className="text-[13px] font-semibold text-white tracking-tight">Views</h2>
            <Info className="w-3.5 h-3.5 text-[#8e8e93] stroke-[2]" />
          </div>

          <div className="relative w-40 h-40 my-1.5 flex items-center justify-center">
            <svg className="w-full h-full transform -rotate-90" viewBox="0 0 100 100">
              <circle cx="50" cy="50" r="40" fill="transparent" stroke="#8a2be2" strokeWidth="8" strokeDasharray="251.2" strokeDashoffset="0" strokeLinecap="round" />
            </svg>
            <div className="absolute inset-0 flex flex-col items-center justify-center text-center">
              <span className="text-[10px] font-normal text-[#8e8e93] tracking-wide">Views</span>
              <span className="text-xl font-extrabold text-white tracking-tight mt-0.5">{config.overview.views.toLocaleString()}</span>
            </div>
          </div>

          <div className="w-full space-y-2 mt-2 px-2">
            <div className="flex items-center justify-between text-[11px]">
              <div className="flex items-center space-x-2"><div className="w-2 h-2 rounded-full bg-[#d946ef]"></div><span className="font-normal text-white">Followers</span></div>
              <span className="text-white font-normal">{(config.splitRatios.followersShare * 100).toFixed(1)}%</span>
            </div>
            <div className="flex items-center justify-between text-[11px]">
              <div className="flex items-center space-x-2"><div className="w-2 h-2 rounded-full bg-[#8a2be2]"></div><span className="font-normal text-white">Non-followers</span></div>
              <span className="text-white font-normal">{(config.splitRatios.nonFollowersShare * 100).toFixed(1)}%</span>
            </div>
          </div>
        </div>

        {/* Views Over Time Section */}
        <div className="px-4 py-4 border-b border-zinc-800/80">
          <h2 className="text-[13px] font-semibold text-white mb-2.5 tracking-tight">Views over time</h2>
          
          <div className="flex space-x-1.5 mb-3">
            {['All', 'Followers', 'Non-followers'].map((tab) => (
              <button
                key={tab}
                onClick={() => setViewFilter(tab)}
                className={`px-3 py-1 rounded-full text-[11px] transition-all ${viewFilter === tab ? 'bg-white text-black font-semibold' : 'bg-[#26262a] text-white font-normal hover:bg-zinc-700'}`}
              >
                {tab}
              </button>
            ))}
          </div>

          <div className="h-56 w-full mt-2 relative" onTouchEnd={() => setViewsIndex(undefined)} onTouchCancel={() => setViewsIndex(undefined)}>
            <ResponsiveContainer width="100%" height="100%">
              <LineChart 
                data={currentViewsData} 
                margin={{ top: 28, right: 10, left: -30, bottom: 0 }}
                activeIndex={viewsIndex}
                onMouseMove={(state) => { if (state && state.activeTooltipIndex !== undefined) setViewsIndex(state.activeTooltipIndex); }}
                onTouchMove={(state) => { if (state && state.activeTooltipIndex !== undefined) setViewsIndex(state.activeTooltipIndex); }}
                onMouseLeave={() => setViewsIndex(undefined)}
              >
                <CartesianGrid strokeDasharray="3 3" stroke="#26262a" vertical={false} />
                <XAxis dataKey="time" stroke="#8e8e93" fontSize={10} tickLine={false} axisLine={false} ticks={['0h', '11h', '22h']} />
                <YAxis stroke="#8e8e93" fontSize={10} tickLine={false} axisLine={false} />
                <Tooltip 
                  isAnimationActive={false}
                  cursor={{ stroke: '#ffffff', strokeWidth: 1, strokeDasharray: 'none' }}
                  position={{ y: 0 }}
                  active={viewsIndex !== undefined}
                  content={({ active, payload }) => {
                    if (active && payload && payload.length) {
                      const data = payload[0].payload;
                      if (data.views === null || data.views === undefined) return null;
                      return (
                        <div className="transform -translate-x-1/2 pointer-events-none">
                          <div className="bg-[#1e1e22] text-white px-3 py-1 rounded-md text-[11px] shadow-2xl border border-white/10 flex flex-col items-center whitespace-nowrap">
                            <span className="font-semibold text-[11px]">{data.views} views</span>
                            {data.comparison && <span className="text-[#8e8e93] text-[9px]">{data.comparison}</span>}
                          </div>
                        </div>
                      );
                    }
                    return null;
                  }} 
                />
                <Line type="monotone" dataKey="views" stroke="#d946ef" strokeWidth={2.5} dot={false} activeDot={viewsIndex !== undefined ? { r: 4, fill: '#d946ef', stroke: '#fff', strokeWidth: 2 } : false} />
                <Line type="monotone" dataKey="typical" stroke="#8e8e93" strokeWidth={2} strokeDasharray="4 4" dot={false} activeDot={false} />
              </LineChart>
            </ResponsiveContainer>
          </div>

          <div className="flex items-center justify-center space-x-5 mt-2.5 text-[10px] text-[#8e8e93] font-normal">
            <div className="flex items-center space-x-1.5"><div className="w-2 h-2 rounded-full bg-[#d946ef]"></div><span>This reel</span></div>
            <div className="flex items-center space-x-1.5"><div className="w-2 h-2 rounded-full bg-[#8e8e93]"></div><span>Your typical reel views</span></div>
          </div>
        </div>

        {/* Top Sources of Views Section */}
        <div className="px-4 py-4 border-b border-zinc-800/80">
          <h2 className="text-[13px] font-semibold text-white mb-3 tracking-tight">Top sources of views</h2>
          <div className="space-y-3">
            {topSourcesBreakdown.map((item, idx) => (
              <div key={idx}>
                <div className="flex justify-between text-[11px] mb-1">
                  <span className="font-normal text-white">{item.label}</span>
                  <span className="font-normal text-white">{item.percent}%</span>
                </div>
                <div className="w-full bg-[#26262a] h-1.5 rounded-full overflow-hidden">
                  <div className="bg-[#d946ef] h-full rounded-full" style={{ width: `${item.percent}%` }}></div>
                </div>
              </div>
            ))}
            <div className="flex justify-between items-center text-[11px] pt-1">
              <span className="font-normal text-white">Viewers</span>
              <span className="font-normal text-white">1,168</span>
            </div>
          </div>
        </div>

        {/* Retention Section */}
        <div className="px-4 py-4 border-b border-zinc-800/80">
          <div className="flex items-center space-x-1.5 mb-2.5">
            <h2 className="text-[13px] font-semibold text-white tracking-tight">Retention</h2>
            <Info className="w-3.5 h-3.5 text-[#8e8e93] stroke-[2]" />
          </div>

          <div className="flex justify-center my-2.5">
            <div className="w-[95px] h-[165px] rounded-lg overflow-hidden bg-zinc-800 shadow-md border border-white/10 relative">
              <img src={config.reel.thumbnail} alt="Retention frame" className="w-full h-full object-cover" />
              <div className="absolute inset-0 flex items-center justify-center bg-black/20">
                <div className="w-6 h-6 rounded-full bg-black/70 flex items-center justify-center backdrop-blur-sm">
                  <Play className="w-3 h-3 text-white fill-white ml-0.5" />
                </div>
              </div>
            </div>
          </div>

          <div className="h-44 w-full mt-2 relative" onTouchEnd={() => setRetentionIndex(undefined)} onTouchCancel={() => setRetentionIndex(undefined)}>
            <ResponsiveContainer width="100%" height="100%">
              <LineChart 
                data={secondBySecondRetentionData} 
                margin={{ top: 28, right: 10, left: -30, bottom: 0 }}
                activeIndex={retentionIndex}
                onMouseMove={(state) => { if (state && state.activeTooltipIndex !== undefined) setRetentionIndex(state.activeTooltipIndex); }}
                onTouchMove={(state) => { if (state && state.activeTooltipIndex !== undefined) setRetentionIndex(state.activeTooltipIndex); }}
                onMouseLeave={() => setRetentionIndex(undefined)}
              >
                <CartesianGrid strokeDasharray="3 3" stroke="#26262a" vertical={false} />
                <XAxis dataKey="time" stroke="#8e8e93" fontSize={10} tickLine={false} axisLine={false} ticks={['0:00', config.reel.duration]} />
                <YAxis stroke="#8e8e93" fontSize={10} tickLine={false} axisLine={false} ticks={[0, 50, 100]} />
                <Tooltip 
                  isAnimationActive={false}
                  cursor={{ stroke: '#ffffff', strokeWidth: 1, strokeDasharray: 'none' }}
                  position={{ y: 0 }}
                  active={retentionIndex !== undefined}
                  content={({ active, payload }) => {
                    if (active && payload && payload.length) {
                      const data = payload[0].payload;
                      return (
                        <div className="transform -translate-x-1/2 pointer-events-none">
                          <div className="bg-[#1e1e22] text-white px-2.5 py-1 rounded-md text-[11px] shadow-2xl border border-white/10 flex flex-col items-center whitespace-nowrap">
                            <span className="font-semibold text-[11px]">{data.retention}%</span>
                            <span className="text-[#8e8e93] text-[9px]">{data.time}</span>
                          </div>
                        </div>
                      );
                    }
                    return null;
                  }} 
                />
                <Line type="monotone" dataKey="retention" stroke="#d946ef" strokeWidth={2} dot={false} activeDot={retentionIndex !== undefined ? { r: 4, fill: '#d946ef', stroke: '#fff', strokeWidth: 2 } : false} />
              </LineChart>
            </ResponsiveContainer>
          </div>

          <div className="space-y-2 mt-3 pt-2 border-t border-zinc-900">
            <div className="flex justify-between text-[11px]"><span className="font-normal text-white">This reel's skip rate</span><span className="font-normal text-white">4.0%</span></div>
            <div className="flex justify-between text-[11px]"><span className="font-normal text-white">Your typical skip rate</span><span className="font-normal text-white">0.7%</span></div>
          </div>
        </div>

        {/* Interactions & Donut Chart Section */}
        <div className="px-4 py-4 border-b border-zinc-800/80 flex flex-col items-center">
          <div className="w-full flex items-center justify-start space-x-1.5 mb-1.5">
            <h2 className="text-[13px] font-semibold text-white tracking-tight">Interactions</h2>
            <Info className="w-3.5 h-3.5 text-[#8e8e93] stroke-[2]" />
          </div>

          <div className="relative w-40 h-40 my-1.5 flex items-center justify-center">
            <svg className="w-full h-full transform -rotate-90" viewBox="0 0 100 100">
              <circle cx="50" cy="50" r="40" fill="transparent" stroke="#8a2be2" strokeWidth="8" strokeDasharray="251.2" strokeDashoffset="0" strokeLinecap="round" />
            </svg>
            <div className="absolute inset-0 flex flex-col items-center justify-center text-center">
              <span className="text-[10px] font-normal text-[#8e8e93] tracking-wide">Interactions</span>
              <span className="text-xl font-extrabold text-white tracking-tight mt-0.5">{totalInteractions}</span>
            </div>
          </div>

          <div className="w-full space-y-2 mt-2 px-2">
            <div className="flex items-center justify-between text-[11px]">
              <div className="flex items-center space-x-2"><div className="w-2 h-2 rounded-full bg-[#d946ef]"></div><span className="font-normal text-white">Followers</span></div>
              <span className="text-white font-normal">0.0%</span>
            </div>
            <div className="flex items-center justify-between text-[11px]">
              <div className="flex items-center space-x-2"><div className="w-2 h-2 rounded-full bg-[#8a2be2]"></div><span className="font-normal text-white">Non-followers</span></div>
              <span className="text-white font-normal">100.0%</span>
            </div>
          </div>
        </div>

        {/* When People Liked Your Reel Section (With Early Hook Spike + Secondary Peaks + Final Viral Spike) */}
        <div className="px-4 py-4 border-b border-zinc-800/80">
          <h2 className="text-[13px] font-semibold text-white mb-2.5 tracking-tight">When people liked your reel</h2>

          <div className="flex justify-center my-2.5">
            <div className="w-[95px] h-[165px] rounded-lg overflow-hidden bg-zinc-800 shadow-md border border-white/10 relative">
              <img src={config.reel.thumbnail} alt="Likes frame" className="w-full h-full object-cover" />
              <div className="absolute inset-0 flex items-center justify-center bg-black/20">
                <div className="w-6 h-6 rounded-full bg-black/70 flex items-center justify-center backdrop-blur-sm">
                  <Play className="w-3 h-3 text-white fill-white ml-0.5" />
                </div>
              </div>
            </div>
          </div>

          <div className="h-44 w-full mt-2 relative" onTouchEnd={() => setLikesIndex(undefined)} onTouchCancel={() => setLikesIndex(undefined)}>
            <ResponsiveContainer width="100%" height="100%">
              <LineChart 
                data={secondsWiseLikesData} 
                margin={{ top: 28, right: 10, left: -30, bottom: 0 }}
                activeIndex={likesIndex}
                onMouseMove={(state) => { if (state && state.activeTooltipIndex !== undefined) setLikesIndex(state.activeTooltipIndex); }}
                onTouchMove={(state) => { if (state && state.activeTooltipIndex !== undefined) setLikesIndex(state.activeTooltipIndex); }}
                onMouseLeave={() => setLikesIndex(undefined)}
              >
                <CartesianGrid strokeDasharray="3 3" stroke="#26262a" vertical={false} />
                <XAxis dataKey="time" stroke="#8e8e93" fontSize={10} tickLine={false} axisLine={false} ticks={['0:00', config.reel.duration]} />
                <YAxis 
                  stroke="#8e8e93" 
                  fontSize={10} 
                  tickLine={false} 
                  axisLine={false} 
                  domain={[0, dynamicLikesYMax]} 
                  ticks={[0, dynamicLikesYMax / 2, dynamicLikesYMax]} 
                />
                <Tooltip 
                  isAnimationActive={false}
                  cursor={{ stroke: '#ffffff', strokeWidth: 1, strokeDasharray: 'none' }}
                  position={{ y: 0 }}
                  active={likesIndex !== undefined}
                  content={({ active, payload }) => {
                    if (active && payload && payload.length) {
                      const data = payload[0].payload;
                      return (
                        <div className="transform -translate-x-1/2 pointer-events-none">
                          <div className="bg-[#1e1e22] text-white px-2.5 py-1 rounded-md text-[11px] shadow-2xl border border-white/10 flex flex-col items-center whitespace-nowrap">
                            <span className="font-semibold text-[11px]">{data.val}%</span>
                            <span className="text-[#8e8e93] text-[9px]">{data.time}</span>
                          </div>
                        </div>
                      );
                    }
                    return null;
                  }} 
                />
                <Line type="linear" dataKey="val" stroke="#d946ef" strokeWidth={2} dot={false} activeDot={likesIndex !== undefined ? { r: 4, fill: '#d946ef', stroke: '#fff', strokeWidth: 2 } : false} />
              </LineChart>
            </ResponsiveContainer>
          </div>

          <div className="space-y-3 mt-3 pt-2.5 border-t border-zinc-900">
            <div className="flex justify-between items-center text-[12px]"><span className="font-normal text-white">Likes</span><span className="font-normal text-white">{totalLikes}</span></div>
            <div className="flex justify-between items-center text-[12px]"><span className="font-normal text-white">Comments</span><span className="font-normal text-white">{totalComments}</span></div>
            <div className="flex justify-between items-center text-[12px]"><span className="font-normal text-white">Reposts</span><span className="font-normal text-white">{totalReposts}</span></div>
            <div className="flex justify-between items-center text-[12px]"><span className="font-normal text-white">Saves</span><span className="font-normal text-white">{totalSaves}</span></div>
            <div className="flex justify-between items-center text-[12px]"><span className="font-normal text-white">Shares</span><span className="font-normal text-white">{totalShares}</span></div>
          </div>
        </div>

        {/* Profile Activity Section */}
        <div className="px-4 py-4 border-b border-zinc-800/80">
          <div className="flex items-center space-x-1.5 mb-2.5">
            <h2 className="text-[13px] font-semibold text-white tracking-tight">Profile activity</h2>
            <Info className="w-3.5 h-3.5 text-[#8e8e93] stroke-[2]" />
          </div>
          <div className="flex justify-between items-center text-[12px]"><span className="font-normal text-white">Follows</span><span className="font-normal text-white">{totalFollows}</span></div>
        </div>

        {/* Audience Section */}
        <div className="px-4 py-4">
          <div className="flex items-center space-x-1.5 mb-2.5">
            <h2 className="text-[13px] font-semibold text-white tracking-tight">Audience</h2>
            <Info className="w-3.5 h-3.5 text-[#8e8e93] stroke-[2]" />
          </div>

          <div className="flex space-x-1.5 mb-3">
            {['Gender', 'Country', 'Age'].map((tab) => (
              <button
                key={tab}
                onClick={() => setAudienceTab(tab)}
                className={`px-3 py-1 rounded-full text-[11px] transition-all ${audienceTab === tab ? 'bg-white text-black font-semibold' : 'bg-[#26262a] text-white font-normal hover:bg-zinc-700'}`}
              >
                {tab}
              </button>
            ))}
          </div>

          {audienceTab === 'Gender' && (
            <div className="space-y-3">
              {genderBreakdown.map((item, idx) => (
                <div key={idx}>
                  <div className="flex justify-between text-[11px] mb-1"><span className="font-normal text-white">{item.label}</span><span className="font-normal text-white">{item.percent}%</span></div>
                  <div className="w-full bg-[#26262a] h-1.5 rounded-full overflow-hidden"><div className="bg-[#d946ef] h-full rounded-full" style={{ width: `${item.percent}%` }}></div></div>
                </div>
              ))}
            </div>
          )}

          {audienceTab === 'Country' && (
            <div className="space-y-3">
              {countryBreakdown.map((item, idx) => (
                <div key={idx}>
                  <div className="flex justify-between text-[11px] mb-1"><span className="font-normal text-white">{item.label}</span><span className="font-normal text-white">{item.percent}%</span></div>
                  <div className="w-full bg-[#26262a] h-1.5 rounded-full overflow-hidden"><div className="bg-[#d946ef] h-full rounded-full" style={{ width: `${item.percent}%` }}></div></div>
                </div>
              ))}
            </div>
          )}

          {audienceTab === 'Age' && (
            <div className="space-y-2.5">
              {ageBreakdown.map((item, idx) => (
                <div key={idx}>
                  <div className="flex justify-between text-[11px] mb-1"><span className="font-normal text-white">{item.label}</span><span className="font-normal text-white">{item.percent}%</span></div>
                  <div className="w-full bg-[#26262a] h-1.5 rounded-full overflow-hidden"><div className="bg-[#d946ef] h-full rounded-full" style={{ width: `${item.percent}%` }}></div></div>
                </div>
              ))}
            </div>
          )}

        </div>

      </div>
    </div>
  );
}
