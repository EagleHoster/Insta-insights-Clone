import React, { useState } from 'react';
import { 
  ArrowLeft, 
  MoreVertical, 
  Heart, 
  MessageCircle, 
  Send, 
  Repeat2, 
  Bookmark, 
  Info,
  Play,
  Dice5
} from 'lucide-react';
import { 
  ResponsiveContainer, 
  LineChart, 
  Line, 
  XAxis, 
  YAxis, 
  Tooltip, 
  CartesianGrid 
} from 'recharts';

// ==========================================
// CENTRALIZED CONFIGURATION & GENERATOR STORE
// ==========================================
const DASHBOARD_CONFIG = {
  seed: 1337,
  regenSalt: 1,
  reel: {
    thumbnail: 'https://images.unsplash.com/photo-1514525253161-7a46d19cd819?q=80&w=400&auto=format&fit=crop',
    title: 'Brantley Gilbert celebrated the release of his 8th studio album "SINS OF...',
    date: 'October 12',
    duration: '1:38',
    likes: null,       
    comments: null,    
    shares: null,      
    reposts: null,     
    saves: null,       
    follows: null      
  },
  videoBehaviors: {
    hasBadHook: false,      
    hasDeadAir: false,      
    isBoring: false,        
    stochasticChance: 0.35, 
    chaosVolatility: 1.0,
    viewsProfile: 'viral_burst',
    algorithmPushFactor: 1.2,    
    audienceFatigueRate: 0.85,   
    hourlyJitterAmplitude: 0.18, 
    peakHourOffset: 8,           
    weekendMultiplier: 1.35      
  },
  overview: {
    views: 6007,
    instagramViews: 5991,
    facebookViews: 16,
    watchTime: '1d 18h 46m 25s',
    interactions: null 
  },
  splitRatios: {
    targetFollowersMean: 0.06,  // ~6% followers center
    variance: 0.015             // fluctuation range
  },
  interactionSplitRatios: {
    targetFollowersMean: 0.023, // ~2.3% followers center
    variance: 0.008
  },
  viewsOverTime: [], 
  topSources: {
    'Reels tab': null,
    'Feed': null,
    'Explore': null,
    'Profile': null
  },
  audience: {
    gender: { 'Men': null, 'Women': null },
    countryPool: [
      { name: 'United States', weight: 12.0 },
      { name: 'United Kingdom', weight: 7.5 },
      { name: 'Canada', weight: 7.0 },
      { name: 'Australia', weight: 6.5 },
      { name: 'India', weight: 5.5 },
      { name: 'Germany', weight: 4.5 },
      { name: 'Brazil', weight: 4.0 },
      { name: 'France', weight: 3.5 },
      { name: 'Mexico', weight: 3.2 },
      { name: 'Philippines', weight: 3.0 },
      { name: 'Indonesia', weight: 2.2 },
      { name: 'Vietnam', weight: 1.8 },
      { name: 'Pakistan', weight: 1.5 },
      { name: 'Egypt', weight: 1.2 },
      { name: 'Nigeria', weight: 1.0 },
      { name: 'Gabon', weight: 0.4 }
    ],
    countries: [
      { country: 'United States', percentage: null },
      { country: null, percentage: null },
      { country: null, percentage: null },
      { country: null, percentage: null },
      { country: null, percentage: null }
    ],
    age: {
      '13-17': null, '18-24': null, '25-34': null, '35-44': null, '45-54': null, '55-64': null, '65+': null
    }
  }
};

const createSeededRandom = (seed) => {
  let s = seed % 2147483647;
  if (s <= 0) s += 2147483646;
  return () => {
    s = (s * 16807) % 2147483647;
    return (s - 1) / 2147483646;
  };
};

const createSubtractivePerlinNoise1D = (seed) => {
  const rng = createSeededRandom(seed);
  const permutationSize = 256;
  const p = new Array(permutationSize * 2);
  const permutation = [];
  
  for (let i = 0; i < permutationSize; i++) permutation[i] = i;
  for (let i = permutationSize - 1; i > 0; i--) {
    const j = Math.floor(rng() * (i + 1));
    [permutation[i], permutation[j]] = [permutation[j], permutation[i]];
  }
  for (let i = 0; i < permutationSize; i++) {
    p[i] = permutation[i];
    p[permutationSize + i] = permutation[i];
  }

  const fade = (t) => t * t * t * (t * (t * 6 - 15) + 10);
  const lerp = (t, a, b) => a + t * (b - a);
  const grad = (hash, x) => (hash & 1 ? x : -x);

  return (x) => {
    const X = Math.floor(x) & 255;
    x -= Math.floor(x);
    const u = fade(x);
    const a = p[X];
    const b = p[X + 1];
    const raw = lerp(u, grad(p[a], x), grad(p[b], x - 1));
    return Math.abs(raw);
  };
};

const parseDurationToSeconds = (durationStr) => {
  if (!durationStr) return 60;
  const parts = durationStr.split(':').map(Number);
  if (parts.length === 2) return parts[0] * 60 + parts[1];
  if (parts.length === 1) return parts[0];
  return 60;
};

const formatSecondsToTimestamp = (sec) => {
  const mins = Math.floor(sec / 60);
  const secs = sec % 60;
  return `${mins}:${secs < 10 ? '0' : ''}${secs}`;
};

const generateWeightedRatio = (mean, variance, seed, saltOffset) => {
  const rng = createSeededRandom(seed + saltOffset);
  // Box-Muller transform or simple clamped random distribution around the mean
  const u1 = Math.max(0.001, rng());
  const u2 = rng();
  const gaussianRandom = Math.sqrt(-2.0 * Math.log(u1)) * Math.cos(2.0 * Math.PI * u2);
  
  // Apply variance and clamp between 0.01 (1%) and 0.99 (99%)
  const val = mean + gaussianRandom * variance;
  const followersShare = Math.min(0.5, Math.max(0.005, val));
  const nonFollowersShare = Number((1 - followersShare).toFixed(3));
  
  return {
    followersShare: Number(followersShare.toFixed(3)),
    nonFollowersShare: nonFollowersShare
  };
};



// Organic Volatile Retention Generator
const generateOrganicVolatileRetention = (durationStr, seed, behaviors) => {
  const rng = createSeededRandom(seed);
  const perlinSubtractive = createSubtractivePerlinNoise1D(seed);
  const totalSeconds = parseDurationToSeconds(durationStr);
  const points = [];

  const badHookActive = behaviors.hasBadHook === true || (behaviors.hasBadHook !== false && rng() < behaviors.stochasticChance);
  const deadAirActive = behaviors.hasDeadAir === true || (behaviors.hasDeadAir !== false && rng() < behaviors.stochasticChance);
  const boringActive = behaviors.isBoring === true || (behaviors.isBoring !== false && rng() < behaviors.stochasticChance);
  const volatility = behaviors.chaosVolatility;

  let currentVal = 100.0;
  const junctionSec = Math.max(8, Math.floor(totalSeconds * 0.18));

  for (let sec = 0; sec <= totalSeconds; sec++) {
    if (sec === 0) {
      points.push({ time: formatSecondsToTimestamp(0), second: 0, retention: 100.0 });
      continue;
    }

    let dropAmount = 0.0;

    if (sec <= 8) {
      let initialDrop = badHookActive ? 4.0 : 3.5;
      dropAmount = (initialDrop + rng() * 2.5) * volatility;
    } 
    else if (sec <= junctionSec) {
      const progress = (sec - 3) / (junctionSec - 3);
      let baseSpeed = 1.2;
      if (badHookActive) baseSpeed = 1.8;
      
      dropAmount = (Math.pow(progress, 0.8) * baseSpeed + 0.3) * volatility;
    } else {
      const remainingSecs = totalSeconds - junctionSec;
      const elapsed = sec - junctionSec;
      const progress = elapsed / remainingSecs;

      const boringMultiplier = boringActive ? 2.0 : 1.0;
      const baseSlope = (Math.pow(progress, 0.9) * 0.4 * boringMultiplier + 0.05);
      const perlinSub = perlinSubtractive(sec * 0.008) * 1.1 * volatility;
      
      let randomSpike = 0;
      if (rng() < 0.18) {
        randomSpike = (rng() * 3.9 + 1.0) * volatility;
      }

      if (deadAirActive && rng() < 0.25 && sec % 8 === 0) {
        randomSpike += (rng() * 2.5 + 1.5) * volatility;
      }

      dropAmount = baseSlope * volatility + perlinSub + randomSpike;
    }

    currentVal = Math.max(0.5, currentVal - dropAmount);

    points.push({
      time: formatSecondsToTimestamp(sec),
      second: sec,
      retention: Number(currentVal.toFixed(1))
    });
  }

  return points;
};

// Dynamic Time Labels Helper
const getDynamicTimeLabels = (reelDateStr) => {
  const currentYear = new Date().getFullYear();
  const uploadDate = new Date(`${reelDateStr}, ${currentYear} 00:00:00`);
  const now = new Date();

  const diffMs = now - uploadDate;
  const diffHours = Math.floor(diffMs / (1000 * 60 * 60));
  const diffDays = Math.floor(diffMs / (1000 * 60 * 60 * 24));

  let startLabel = reelDateStr;
  if (reelDateStr && reelDateStr.includes(' ')) {
    const [month, day] = reelDateStr.split(' ');
    startLabel = `${month.slice(0, 3)} ${day}`;
  }
  
  if (diffDays < 1) {
    startLabel = '0h';
  }

  let midLabel = '';
  if (diffHours <= 23) {
    midLabel = `${Math.max(1, diffHours)}h`;
  } else {
    midLabel = now.toLocaleDateString('en-US', { month: 'short', day: 'numeric' });
  }

  let endLabel = '';
  if (diffDays >= 1) {
    const doubledTimeMs = diffMs * 2;
    const endDate = new Date(uploadDate.getTime() + doubledTimeMs);
    endLabel = endDate.toLocaleDateString('en-US', { month: 'short', day: 'numeric' });
  } else {
    const doubledHours = Math.min(48, Math.max(2, diffHours * 2));
    endLabel = `${doubledHours}h`;
  }

  return {
    start: startLabel,
    mid: midLabel,
    end: endLabel,
    ticks: [startLabel, midLabel, endLabel]
  };
};

const generateAdvancedViewsOverTime = (targetTotalViews, seed, regenSalt, behaviors, reelDateStr) => {
  const rng = createSeededRandom(seed + regenSalt * 123);
  const perlin = createSubtractivePerlinNoise1D(seed + regenSalt * 456);
  const volatility = behaviors?.chaosVolatility || 1.0;
  const profile = behaviors?.viewsProfile || 'viral_burst';
  
  const dynamicLabels = getDynamicTimeLabels(reelDateStr);
  const timeLabels = [dynamicLabels.start, '2h', '4h', '6h', '8h', dynamicLabels.mid, '13h', '15h', '18h', '20h', dynamicLabels.end];
  const midIndex = 5;
  
  let accumulatedViews = 0;
  let lastTypical = 0; // Tracks the previous typical value to ensure it never goes down

  return timeLabels.map((timeLabel, idx) => {
    if (idx === 0) return { time: timeLabel, views: 0, typical: 0 };
    
    if (idx > midIndex) {
      // Ensure typical views only go up or stay flat (monotonic increase)
      const upwardStep = Math.round(targetTotalViews * (0.03 + rng() * 0.04));
      lastTypical = Math.min(Math.round(targetTotalViews * 1.1), lastTypical + upwardStep);
      return { 
        time: timeLabel, 
        views: null, 
        typical: lastTypical 
      };
    }

    if (idx === midIndex) {
      const upwardStep = Math.round(targetTotalViews * (0.05 + rng() * 0.05));
      lastTypical = Math.min(Math.round(targetTotalViews * 0.85), lastTypical + upwardStep);
      return { 
        time: timeLabel, 
        views: targetTotalViews, 
        typical: lastTypical 
      };
    }

    const noiseVal = perlin(idx * 0.4 + regenSalt);
    const stochasticEvent = rng() < 0.35 ? rng() * 0.25 * volatility : 0;
    
    let baseWeight = 0;
    if (profile === 'slow_burn') {
      baseWeight = (0.12 + noiseVal * 0.08 + stochasticEvent) * volatility;
    } else if (profile === 'rollercoaster') {
      const wave = Math.sin(idx * 0.7) * 0.15 + 0.15;
      baseWeight = (Math.max(0.02, wave + noiseVal * 0.1 + stochasticEvent)) * volatility;
    } else {
      const burstWindow = (idx >= 2 && idx <= 4) ? 0.35 : 0.1;
      baseWeight = (burstWindow + noiseVal * 0.12 + stochasticEvent) * volatility;
    }

    let jump = Math.round(targetTotalViews * baseWeight * 0.65);
    accumulatedViews = Math.min(targetTotalViews - 50, accumulatedViews + Math.max(10, jump));
    
    // Ensure typical views for earlier indices also only step upward from the last value
    const typicalJump = Math.round(jump * (0.4 + rng() * 0.4));
    lastTypical = Math.min(accumulatedViews, lastTypical + typicalJump);

    return {
      time: timeLabel,
      views: accumulatedViews,
      typical: lastTypical
    };
  });
};


const generateSecondsWiseLikesInteraction = (durationStr, seed, totalLikes) => {
  const rng = createSeededRandom(seed + 99);
  const perlinNoise = createSubtractivePerlinNoise1D(seed + 55);
  const totalSeconds = parseDurationToSeconds(durationStr);
  
  const likeCountsPerSecond = new Array(totalSeconds + 1).fill(0);
  let remainingLikes = totalLikes;

  const weights = new Array(totalSeconds + 1).fill(0);
  const finalSpikeSec = totalSeconds;
  const secondarySpikeSec = Math.floor(totalSeconds * (0.5 + rng() * 0.2));

  for (let sec = 0; sec <= totalSeconds; sec++) {
    const noiseVal = perlinNoise(sec * 0.08);
    let w = noiseVal * 1.5 + 0.2; 

    if (sec <= 3) {
      w += (4 - sec) * 4.5;
    }

    const distToFinal = Math.abs(sec - finalSpikeSec);
    if (distToFinal <= 2) {
      w += (3 - distToFinal) * 6.0;
    }

    const distToMid = Math.abs(sec - secondarySpikeSec);
    if (distToMid <= 2) {
      w += (3 - distToMid) * 3.0;
    }

    weights[sec] = Math.max(0.01, w);
  }

  const totalWeight = weights.reduce((acc, w) => acc + w, 0);

  while (remainingLikes > 0) {
    let r = rng() * totalWeight;
    let cumulative = 0;
    let chosenSec = 0;

    for (let sec = 0; sec <= totalSeconds; sec++) {
      cumulative += weights[sec];
      if (r <= cumulative) {
        chosenSec = sec;
        break;
      }
    }

    likeCountsPerSecond[chosenSec] += 1;
    remainingLikes -= 1;
  }

  return likeCountsPerSecond.map((count, sec) => {
    const percentage = totalLikes > 0 ? Number(((count / totalLikes) * 100).toFixed(1)) : 0.0;
    return {
      time: formatSecondsToTimestamp(sec),
      second: sec,
      val: percentage
    };
  });
};

const processPercentageBreakdown = (obj, seed, weights = {}, sortDescending = true) => {
  const rng = createSeededRandom(seed);
  const keys = Object.keys(obj);
  const explicitEntries = Object.entries(obj).filter(([_, val]) => val !== null && val !== undefined);
  
  let explicitSum = explicitEntries.reduce((acc, [_, val]) => acc + Number(val), 0);
  const nullKeys = keys.filter(k => obj[k] === null || obj[k] === undefined);

  let result = {};

  if (nullKeys.length === 0) {
    const scale = 100 / explicitSum;
    keys.forEach(k => {
      result[k] = Number((obj[k] * scale).toFixed(1));
    });
  } else {
    let remaining = Math.max(0, 100 - explicitSum);
    const calculatedWeights = {};
    let totalWeight = 0;

    nullKeys.forEach(k => {
      const baseWeight = weights[k] !== undefined ? weights[k] : 1;
      const w = baseWeight * (0.85 + rng() * 0.3);
      calculatedWeights[k] = w;
      totalWeight += w;
    });

    explicitEntries.forEach(([k, val]) => {
      result[k] = Number(val);
    });

    nullKeys.forEach((k, idx) => {
      if (idx === nullKeys.length - 1) {
        const assignedSum = Object.entries(result).reduce((acc, [ky, v]) => ky !== k ? acc + v : acc, 0);
        result[k] = Number(Math.max(0, 100 - assignedSum).toFixed(1));
      } else {
        const val = (calculatedWeights[k] / totalWeight) * remaining;
        result[k] = Number(val.toFixed(1));
      }
    });
  }

  const entriesArray = Object.entries(result).map(([label, percent]) => ({ label, percent }));
  if (sortDescending) {
    entriesArray.sort((a, b) => b.percent - a.percent);
  }
  return entriesArray;
};

const processCountryBreakdownWithLuckyDraw = (countriesSlots, countryPool, seed) => {
  const rng = createSeededRandom(seed);
  const randomTargetSum = 50 + rng() * 15; 

  let assignedCountries = [];
  let explicitSum = 0;

  countriesSlots.forEach(slot => {
    if (slot.country) {
      const explicitPct = slot.percentage !== null && slot.percentage !== undefined ? Number(slot.percentage) : null;
      assignedCountries.push({ name: slot.country, percentage: explicitPct });
      if (explicitPct !== null) explicitSum += explicitPct;
    }
  });

  const slotsNeedingCountry = countriesSlots.filter(s => !s.country);
  const remainingTarget = Math.max(0, randomTargetSum - explicitSum);

  if (slotsNeedingCountry.length > 0 || assignedCountries.some(c => c.percentage === null)) {
    let availablePool = [...countryPool].filter(c => !assignedCountries.some(ac => ac.name === c.name));
    let selectedLuckyCountries = [];

    slotsNeedingCountry.forEach(() => {
      if (availablePool.length === 0) return;
      const totalPoolWeight = availablePool.reduce((acc, c) => acc + c.weight, 0);
      let randVal = rng() * totalPoolWeight;
      let cumulative = 0;
      let winnerIndex = 0;

      for (let i = 0; i < availablePool.length; i++) {
        cumulative += availablePool[i].weight;
        if (randVal <= cumulative) {
          winnerIndex = i;
          break;
        }
      }
      selectedLuckyCountries.push(availablePool.splice(winnerIndex, 1)[0]);
    });

    let toCalculate = [
      ...assignedCountries.filter(c => c.percentage === null).map(c => {
        const poolMatch = countryPool.find(p => p.name === c.name);
        return { name: c.name, baseWeight: poolMatch ? poolMatch.weight : 5.0 };
      }),
      ...selectedLuckyCountries.map(c => ({ name: c.name, baseWeight: c.weight }))
    ];

    if (toCalculate.length > 0) {
      const winnerIndex = Math.floor(rng() * toCalculate.length);
      const scored = toCalculate.map((item, idx) => ({
        name: item.name,
        luckyScore: item.baseWeight * (idx === winnerIndex ? (2.2 + rng() * 1.5) : (0.4 + rng() * 0.7))
      }));

      const totalLuckyScore = scored.reduce((acc, s) => acc + s.luckyScore, 0);
      let calculatedUnassignedSum = 0;

      scored.forEach((s, idx) => {
        const share = idx === scored.length - 1 
          ? Math.max(0, remainingTarget - calculatedUnassignedSum)
          : Number(((s.luckyScore / totalLuckyScore) * remainingTarget).toFixed(1));
        
        calculatedUnassignedSum += share;

        const existing = assignedCountries.find(ac => ac.name === s.name);
        if (existing) existing.percentage = share;
        else assignedCountries.push({ name: s.name, percentage: share });
      });
    }
  }

  let finalResult = {};
  assignedCountries.forEach(ac => {
    finalResult[ac.name] = Number((ac.percentage || 0).toFixed(1));
  });

  return Object.entries(finalResult)
    .map(([label, percent]) => ({ label, percent }))
    .sort((a, b) => b.percent - a.percent);
};

const getComparisonText = (val, typical) => {
  if (typical === 0 || typical === undefined || val === null || val === undefined) return null;
  const diff = Math.round(((val - typical) / typical) * 100);
  if (diff === 0) return 'Same as typical';
  if (diff > 0) return `${diff}% higher than typical`;
  return `${Math.abs(diff)}% lower than typical`;
};

const generateSplitDatasets = (processedViews, ratioF) => {
  const followersData = [];
  const nonFollowersData = [];

  processedViews.forEach((item) => {
    const totalViews = item.views;
    const totalTypical = item.typical;

    if (totalViews === null || totalViews === undefined) {
      followersData.push({ time: item.time, views: null, typical: Math.round(totalTypical * ratioF), comparison: null });
      nonFollowersData.push({ time: item.time, views: null, typical: Math.round(totalTypical * (1 - ratioF)), comparison: null });
      return;
    }

    const fViews = Math.round(totalViews * ratioF);
    const fTypical = Math.round(totalTypical * ratioF);
    followersData.push({ time: item.time, views: fViews, typical: fTypical, comparison: getComparisonText(fViews, fTypical) });

    const nfViews = totalViews - fViews;
    const nfTypical = totalTypical - fTypical;
    nonFollowersData.push({ time: item.time, views: nfViews, typical: nfTypical, comparison: getComparisonText(nfViews, nfTypical) });
  });

  return { followersData, nonFollowersData };
};

// ============================================================================
// MATCHED INSTAGRAM-STYLE DONUT CHART (READS DYNAMIC VALUES)
// ============================================================================
const InstagramDonutChart = ({ followerRatio, centerLabel, centerValue }) => {
  const radius = 47;
  const strokeWidth = 6;
  const circumference = 2 * Math.PI * radius;
  
  let followersPercent = Math.min(100, Math.max(0, followerRatio * 100));
  // FIX 1: Change 0.1 to 1 to target less than 1%
  followersPercent = followersPercent < 1.9 ? 0 : followersPercent;
  const nonFollowersPercent = 100 - followersPercent;

  const capPadding = followersPercent ? strokeWidth * 1.2 : 0; 

  const followersArc = Math.max(0, (circumference * (followersPercent / 100)) - capPadding);
  const nonFollowersArc = Math.max(0, (circumference * (nonFollowersPercent / 100)) - capPadding);
  
  const followersOffset = -strokeWidth / 2;
  const nonFollowersOffset = -(followersArc + capPadding + strokeWidth / 2);

  return (
    <div className="relative w-44 h-44 my-1 flex items-center justify-center">
      <svg className="w-full h-full transform -rotate-90" viewBox="0 0 100 100">
        {/* Non-followers Arc (#7638FA) */}
        {nonFollowersPercent > 0 && (
          <circle
            cx="50"
            cy="50"
            r={radius}
            fill="transparent"
            stroke="#7638FA"
            strokeWidth={strokeWidth}
            strokeDasharray={`${nonFollowersArc} ${circumference - nonFollowersArc}`}
            strokeDashoffset={nonFollowersOffset}
            strokeLinecap="round"
          />
        )}
        {/* Followers Arc (#DC38D1) */}
        {/* FIX 2: Added conditional rendering to hide the dot when percent is 0 */}
        {followersPercent > 0 && (
          <circle
            cx="50"
            cy="50"
            r={radius}
            fill="transparent"
            stroke="#DC38D1"
            strokeWidth={strokeWidth}
            strokeDasharray={`${followersArc} ${circumference - followersArc}`}
            strokeDashoffset={followersOffset}
            strokeLinecap="round"
          />
        )}
      </svg>
      <div className="absolute inset-0 flex flex-col items-center justify-center text-center">
        <span className="text-[10px] font-normal text-[#8e8e93] tracking-wide">{centerLabel}</span>
        <span className="text-xl font-extrabold text-white tracking-tight mt-0.5">{centerValue}</span>
      </div>
    </div>
  );
};



export default function ReelInsightsDashboard() {
  const [viewFilter, setViewFilter] = useState('All');
  const [audienceTab, setAudienceTab] = useState('Gender');
  const [showConfigPanel, setShowConfigPanel] = useState(false);
  const [configTab, setConfigTab] = useState('behaviors');
  
  const [config, setConfig] = useState(DASHBOARD_CONFIG);

  const [customViewsOverTime, setCustomViewsOverTime] = useState(() => 
    generateAdvancedViewsOverTime(DASHBOARD_CONFIG.overview.views, DASHBOARD_CONFIG.seed, DASHBOARD_CONFIG.regenSalt, DASHBOARD_CONFIG.videoBehaviors, DASHBOARD_CONFIG.reel.date)
  );

  const [viewsIndex, setViewsIndex] = useState(undefined);
  const [retentionIndex, setRetentionIndex] = useState(undefined);
  const [likesIndex, setLikesIndex] = useState(undefined);

  const rng = createSeededRandom(config.seed);
  const totalViews = config.overview.views;

  // Fully dynamic generators matching your original logic when null
  const totalLikes = config.reel.likes !== null ? config.reel.likes : Math.max(1, Math.round(totalViews * (0.007 + rng() * 0.006))); 
  const totalComments = config.reel.comments !== null ? config.reel.comments : Math.max(0, Math.round(totalViews * (0.0002 + rng() * 0.0004))); 
  const totalShares = config.reel.shares !== null ? config.reel.shares : Math.max(0, Math.round(totalViews * (0.0006 + rng() * 0.0008))); 
  const totalReposts = config.reel.reposts !== null ? config.reel.reposts : Math.max(0, Math.round(totalViews * (0.0003 + rng() * 0.0004))); 
  const totalSaves = config.reel.saves !== null ? config.reel.saves : Math.max(0, Math.round(totalViews * (0.0006 + rng() * 0.0008))); 
  const totalFollows = config.reel.follows !== null ? config.reel.follows : Math.max(0, Math.round(totalViews * (0.0001 + rng() * 0.0003))); 
  
  // Dynamically sums up all interaction variables
  const totalInteractions = config.overview.interactions !== null 
    ? config.overview.interactions 
    : (totalLikes + totalComments + totalShares + totalReposts + totalSaves);

  const ageWeights = { '13-17': 0.15, '18-24': 2.5, '25-34': 3.5, '35-44': 2.0, '45-54': 0.8, '55-64': 0.3, '65+': 0.05 };
  const genderWeights = { 'Men': 3.0, 'Women': 1.0 };

  const genderBreakdown = processPercentageBreakdown(config.audience.gender, config.seed + 1, genderWeights, true);
  const countryBreakdown = processCountryBreakdownWithLuckyDraw(config.audience.countries, config.audience.countryPool, config.seed + 2);
  const ageBreakdown = processPercentageBreakdown(config.audience.age, config.seed + 3, ageWeights, false);
  
    // Inside ReelInsightsDashboard:
  const viewsSplit = generateWeightedRatio(
    config.splitRatios.targetFollowersMean || 0.06, 
    config.splitRatios.variance || 0.015, 
    config.seed, 
    77
  );

  const interactionSplit = generateWeightedRatio(
    config.interactionSplitRatios.targetFollowersMean || 0.023, 
    config.interactionSplitRatios.variance || 0.008, 
    config.seed, 
    88
  );
  
  const topSourcesWeights = { 'Reels tab': 60.0, 'Feed': 30.0, 'Explore': 8.0, 'Profile': 0.05 };
  const topSourcesBreakdown = processPercentageBreakdown(config.topSources, config.seed + 4, topSourcesWeights, true);

  const secondBySecondRetentionData = generateOrganicVolatileRetention(config.reel.duration, config.seed + 5, config.videoBehaviors);
  const secondsWiseLikesData = generateSecondsWiseLikesInteraction(config.reel.duration, config.seed + 6, totalLikes);
  const dynamicLikesYMax = Math.ceil(Math.max(...secondsWiseLikesData.map(d => d.val), 15) / 10) * 10;

  const totalViewsOverTimeData = customViewsOverTime.map(item => ({ ...item, comparison: getComparisonText(item.views, item.typical) }));
  const { followersData, nonFollowersData } = generateSplitDatasets(customViewsOverTime, config.splitRatios.followersShare);
  const currentViewsData = viewFilter === 'Followers' ? followersData : viewFilter === 'Non-followers' ? nonFollowersData : totalViewsOverTimeData;

  const dynamicTicks = getDynamicTimeLabels(config.reel.date).ticks;

  const handleBehaviorChange = (key, val) => {
    const updatedBehaviors = { ...config.videoBehaviors, [key]: val };
    const newSalt = config.regenSalt + 1;
    setConfig(prev => ({ ...prev, videoBehaviors: updatedBehaviors, regenSalt: newSalt }));
    setCustomViewsOverTime(generateAdvancedViewsOverTime(config.overview.views, config.seed, newSalt, updatedBehaviors, config.reel.date));
  };

  const handleViewsPointChange = (index, field, value) => {
    const updated = [...customViewsOverTime];
    updated[index] = { ...updated[index], [field]: Number(value) || 0 };
    setCustomViewsOverTime(updated);
  };

  const randomizeViewsCurve = () => {
    const newSalt = config.regenSalt + 1;
    setConfig(prev => ({ ...prev, regenSalt: newSalt }));
    setCustomViewsOverTime(generateAdvancedViewsOverTime(config.overview.views, config.seed, newSalt, config.videoBehaviors, config.reel.date));
  };

  const randomizeSeed = () => {
    const randomSeedVal = Math.floor(Math.random() * 999999) + 1;
    const newSalt = config.regenSalt + 1;
    setConfig(prev => ({ ...prev, seed: randomSeedVal, regenSalt: newSalt }));
    setCustomViewsOverTime(generateAdvancedViewsOverTime(config.overview.views, randomSeedVal, newSalt, config.videoBehaviors, config.reel.date));
  };

  return (
    <div className="min-h-screen bg-[#0d0e11] text-white font-sans flex flex-col items-center pb-12 select-none antialiased [-webkit-font-smoothing:antialiased]">
      
      {/* Main Container */}
      <div className="w-full max-w-[430px] bg-[#0d0e11] min-h-screen flex flex-col border-x border-zinc-900 shadow-2xl relative">
        
        {/* Sticky Header Wrapper */}
        <div className="sticky top-0 z-30 bg-[#0d0e11]/98 backdrop-blur border-b border-zinc-900/60">
          <div className="flex items-center justify-between px-3.5 py-2.5">
            <div className="flex items-center space-x-3.5">
              <button className="text-white hover:text-zinc-300 transition-colors">
                <ArrowLeft className="w-5 h-5 stroke-[2]" />
              </button>
              <h1 className="text-[16px] font-bold tracking-tight text-white">Reel insights</h1>
            </div>
            
            <button 
              onClick={() => setShowConfigPanel(!showConfigPanel)}
              className="text-white hover:text-zinc-300 transition-colors p-1.5 rounded-full hover:bg-zinc-800 cursor-pointer"
              title="Toggle Parameter Editor"
            >
              <MoreVertical className="w-4.5 h-4.5 stroke-[2]" />
            </button>
          </div>

          {/* Expanded Config Panel with Tabs */}
          {showConfigPanel && (
            <div className="absolute right-3.5 top-12 w-80 bg-zinc-900 border border-zinc-800 p-4 rounded-xl shadow-2xl text-[12px] z-40 space-y-3">
              <div className="flex justify-between items-center border-b border-zinc-800 pb-2">
                <div className="flex space-x-2">
                  <button 
                    onClick={() => setConfigTab('behaviors')} 
                    className={`px-2 py-1 rounded font-semibold text-xs ${configTab === 'behaviors' ? 'bg-purple-600 text-white' : 'text-zinc-400 hover:text-white'}`}
                  >
                    Parameters
                  </button>
                  <button 
                    onClick={() => setConfigTab('viewsEditor')} 
                    className={`px-2 py-1 rounded font-semibold text-xs ${configTab === 'viewsEditor' ? 'bg-purple-600 text-white' : 'text-zinc-400 hover:text-white'}`}
                  >
                    Views Over Time
                  </button>
                </div>
                <button onClick={() => setShowConfigPanel(false)} className="text-zinc-400 hover:text-white font-bold">✕</button>
              </div>

              {configTab === 'behaviors' ? (
                <div className="space-y-3 max-h-72 overflow-y-auto pr-1">
                  <div className="flex items-center justify-between">
                    <span className="text-[11px] text-zinc-300">Random Seed</span>
                    <div className="flex items-center space-x-1.5">
                      <input 
                        type="number" 
                        value={config.seed} 
                        onChange={(e) => {
                          const newSeed = Number(e.target.value) || 1;
                          const newSalt = config.regenSalt + 1;
                          setConfig(prev => ({ ...prev, seed: newSeed, regenSalt: newSalt }));
                          setCustomViewsOverTime(generateAdvancedViewsOverTime(config.overview.views, newSeed, newSalt, config.videoBehaviors, config.reel.date));
                        }}
                        className="w-16 bg-zinc-800 border border-zinc-700 rounded px-1.5 py-1 text-white text-center font-mono text-xs"
                      />
                      <button onClick={randomizeSeed} className="bg-purple-600 hover:bg-purple-500 text-white p-1 rounded" title="Randomize Seed & Views">
                        <Dice5 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>

                  <div className="flex items-center justify-between">
                    <span className="text-[11px] text-zinc-300">Views Growth Profile</span>
                    <select 
                      value={config.videoBehaviors.viewsProfile}
                      onChange={(e) => handleBehaviorChange('viewsProfile', e.target.value)}
                      className="bg-zinc-800 border border-zinc-700 rounded px-2 py-1 text-white text-xs font-mono"
                    >
                      <option value="viral_burst">Viral Burst</option>
                      <option value="slow_burn">Slow Burn</option>
                      <option value="rollercoaster">Rollercoaster</option>
                    </select>
                  </div>

                  <div className="flex items-center justify-between">
                    <span className="text-[11px] text-zinc-300">Chaos Volatility</span>
                    <input 
                      type="number" step="0.1" min="0.2" max="3.0"
                      value={config.videoBehaviors.chaosVolatility} 
                      onChange={(e) => handleBehaviorChange('chaosVolatility', Number(e.target.value))}
                      className="w-20 bg-zinc-800 border border-zinc-700 rounded px-2 py-1 text-white text-center font-mono"
                    />
                  </div>
                </div>
              ) : (
                <div className="space-y-2.5 max-h-72 overflow-y-auto pr-1">
                  <div className="flex justify-between items-center mb-1">
                    <span className="text-[10px] text-zinc-400">Manual checkpoint views editor:</span>
                    <button onClick={randomizeViewsCurve} className="text-[10px] bg-purple-600 hover:bg-purple-500 text-white px-2 py-0.5 rounded">Regenerate Jagged</button>
                  </div>
                  {customViewsOverTime.map((pt, idx) => (
                    <div key={idx} className="grid grid-cols-3 gap-1.5 items-center bg-zinc-800/60 p-1.5 rounded">
                      <span className="font-mono text-zinc-300 font-bold text-center">{pt.time}</span>
                      <div>
                        <span className="text-[9px] text-zinc-400 block">Views</span>
                        <input 
                          type="number" 
                          value={pt.views !== null ? pt.views : ''} 
                          onChange={(e) => handleViewsPointChange(idx, 'views', e.target.value)}
                          className="w-full bg-zinc-900 border border-zinc-700 rounded px-1 py-0.5 text-white text-xs font-mono text-center"
                        />
                      </div>
                      <div>
                        <span className="text-[9px] text-zinc-400 block">Typical</span>
                        <input 
                          type="number" 
                          value={pt.typical !== null ? pt.typical : ''} 
                          onChange={(e) => handleViewsPointChange(idx, 'typical', e.target.value)}
                          className="w-full bg-zinc-900 border border-zinc-700 rounded px-1 py-0.5 text-white text-xs font-mono text-center"
                        />
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}
        </div>

        {/* Video Thumbnail & Details */}
        <div className="px-4 pt-3 pb-4 border-b border-zinc-800/80">
          <div className="flex flex-col items-center">
            <div className="w-[105px] h-[185px] rounded-lg overflow-hidden bg-zinc-800 shadow-xl relative border border-white/10">
              <img src={config.reel.thumbnail} alt="Reel thumbnail" className="w-full h-full object-cover" />
              <div className="absolute inset-0 flex items-center justify-center bg-black/20">
                <div className="w-7 h-7 rounded-full bg-black/70 flex items-center justify-center backdrop-blur-sm">
                  <Play className="w-3.5 h-3.5 text-white fill-white ml-0.5" />
                </div>
              </div>
            </div>
            
            <p className="text-[11px] font-semibold text-white text-center mt-2.5 px-2 line-clamp-1 tracking-tight">
              {config.reel.title}
            </p>
            <p className="text-[10px] font-normal text-[#8e8e93] mt-0.5">
              {config.reel.date} · Duration {config.reel.duration}
            </p>
          </div>

          <div className="grid grid-cols-5 gap-2 mt-4 px-4 text-center">
            <div className="flex flex-col items-center space-y-0.5"><Heart className="w-4.5 h-4.5 text-white fill-white" /><span className="text-[11px] font-semibold text-white">{totalLikes}</span></div>
            <div className="flex flex-col items-center space-y-0.5"><MessageCircle className="w-4.5 h-4.5 text-white fill-white -scale-x-100" /><span className="text-[11px] font-semibold text-white">{totalComments}</span></div>
            <div className="flex flex-col items-center space-y-0.5"><Send className="w-4.5 h-4.5 text-white fill-white" /><span className="text-[11px] font-semibold text-white">{totalShares}</span></div>
            <div className="flex flex-col items-center space-y-0.5"><Repeat2 className="w-4.5 h-4.5 text-white stroke-[2]" /><span className="text-[11px] font-semibold text-white">{totalReposts}</span></div>
            <div className="flex flex-col items-center space-y-0.5"><Bookmark className="w-4.5 h-4.5 text-white fill-white" /><span className="text-[11px] font-semibold text-white">{totalSaves}</span></div>
          </div>
        </div>

        {/* Overview Section */}
        <div className="px-4 py-3.5 border-b border-zinc-800/80">
          <div className="flex items-center space-x-1.5 mb-3">
            <h2 className="text-[13px] font-semibold text-white tracking-tight">Overview</h2>
            <Info className="w-3.5 h-3.5 text-[#8e8e93] stroke-[2]" />
          </div>
          <div className="space-y-3">
            <div>
              <div className="flex justify-between items-center text-[12px]">
                <span className="font-normal text-white">Views</span>
                <span className="font-semibold text-white">{config.overview.views.toLocaleString()}</span>
              </div>
              {config.overview.instagramViews && (
                <div className="flex justify-between items-center text-[11px] text-[#8e8e93] mt-0.5 pl-2">
                  <span>Instagram</span>
                  <span>{config.overview.instagramViews.toLocaleString()}</span>
                </div>
              )}
              {config.overview.facebookViews && (
                <div className="flex justify-between items-center text-[11px] text-[#8e8e93] mt-0.5 pl-2">
                  <span>Facebook</span>
                  <span>{config.overview.facebookViews.toLocaleString()}</span>
                </div>
              )}
            </div>

            <div className="flex justify-between items-center text-[12px]">
              <span className="font-normal text-white">Watch time</span>
              <span className="font-normal text-white">{config.overview.watchTime}</span>
            </div>
            <div className="flex justify-between items-center text-[12px]">
              <span className="font-normal text-white">Interactions</span>
              <span className="font-normal text-white">{totalInteractions}</span>
            </div>
            <div className="flex justify-between items-center text-[12px]">
              <span className="font-normal text-white">Profile activity</span>
              <span className="font-normal text-white">{totalFollows}</span>
            </div>
          </div>
        </div>

        {/* Views & Donut Chart Section */}
        <div className="px-4 py-4 border-b border-zinc-800/80 flex flex-col items-center">
          <div className="w-full flex items-center justify-start space-x-1.5 mb-1.5">
            <h2 className="text-[13px] font-semibold text-white tracking-tight">Views</h2>
            <Info className="w-3.5 h-3.5 text-[#8e8e93] stroke-[2]" />
          </div>

          <InstagramDonutChart 
            followerRatio={viewsSplit.followersShare} 
            centerLabel="Views" 
            centerValue={config.overview.views.toLocaleString()} 
          />

          <div className="w-full space-y-2 mt-2 px-2">
            <div className="flex items-center justify-between text-[11px]">
              <div className="flex items-center space-x-2">
                <div className="w-2 h-2 rounded-full bg-[#DC38D1]"></div>
                <span className="font-normal text-white">Followers</span>
              </div>
              <span className="text-white font-normal">{(viewsSplit.followersShare * 100).toFixed(1)}%</span>
            </div>
            <div className="flex items-center justify-between text-[11px]">
              <div className="flex items-center space-x-2">
                <div className="w-2 h-2 rounded-full bg-[#7638FA]"></div>
                <span className="font-normal text-white">Non-followers</span>
              </div>
              <span className="text-white font-normal">{(viewsSplit.nonFollowersShare * 100).toFixed(1)}%</span>
            </div>
          </div>
        </div>

        {/* Views Over Time Section */}
        <div className="px-4 py-4 border-b border-zinc-800/80">
          <h2 className="text-[13px] font-semibold text-white mb-2.5 tracking-tight">Views over time</h2>
          
          <div className="flex space-x-1.5 mb-3">
            {['All', 'Followers', 'Non-followers'].map((tab) => (
              <button
                key={tab}
                onClick={() => setViewFilter(tab)}
                className={`px-3 py-1 rounded-full text-[11px] transition-all ${viewFilter === tab ? 'bg-white text-black font-semibold' : 'bg-[#26262a] text-white font-normal hover:bg-zinc-700'}`}
              >
                {tab}
              </button>
            ))}
          </div>

          <div className="h-56 w-full mt-2 relative" onTouchEnd={() => setViewsIndex(undefined)} onTouchCancel={() => setViewsIndex(undefined)}>
            <ResponsiveContainer width="100%" height="100%">
              <LineChart 
                data={currentViewsData} 
                margin={{ top: 28, right: 10, left: -30, bottom: 0 }}
                activeIndex={viewsIndex}
                onMouseMove={(state) => { if (state && state.activeTooltipIndex !== undefined) setViewsIndex(state.activeTooltipIndex); }}
                onTouchMove={(state) => { if (state && state.activeTooltipIndex !== undefined) setViewsIndex(state.activeTooltipIndex); }}
                onMouseLeave={() => setViewsIndex(undefined)}
              >
                <CartesianGrid strokeDasharray="3 3" stroke="#26262a" vertical={false} />
                <XAxis dataKey="time" stroke="#8e8e93" fontSize={10} tickLine={false} axisLine={false} ticks={dynamicTicks} />
                <YAxis stroke="#8e8e93" fontSize={10} tickLine={false} axisLine={false} />
                <Tooltip 
                  isAnimationActive={false}
                  cursor={{ stroke: '#ffffff', strokeWidth: 1, strokeDasharray: 'none' }}
                  position={{ y: 0 }}
                  active={viewsIndex !== undefined}
                  content={({ active, payload }) => {
                    if (active && payload && payload.length) {
                      const data = payload[0].payload;
                      if (data.views === null || data.views === undefined) return null;
                      return (
                        <div className="transform -translate-x-1/2 pointer-events-none">
                          <div className="bg-[#1e1e22] text-white px-3 py-1 rounded-md text-[11px] shadow-2xl border border-white/10 flex flex-col items-center whitespace-nowrap">
                            <span className="font-semibold text-[11px]">{data.views} views</span>
                            {data.comparison && <span className="text-[#8e8e93] text-[9px]">{data.comparison}</span>}
                          </div>
                        </div>
                      );
                    }
                    return null;
                  }} 
                />
                <Line type="linear" dataKey="views" stroke="#d946ef" strokeWidth={2.5} dot={false} activeDot={viewsIndex !== undefined ? { r: 4, fill: '#d946ef', stroke: '#fff', strokeWidth: 2 } : false} />
                <Line type="linear" dataKey="typical" stroke="#8e8e93" strokeWidth={2} strokeDasharray="4 4" dot={false} activeDot={false} />
              </LineChart>
            </ResponsiveContainer>
          </div>

          <div className="flex items-center justify-center space-x-5 mt-2.5 text-[10px] text-[#8e8e93] font-normal">
            <div className="flex items-center space-x-1.5"><div className="w-2 h-2 rounded-full bg-[#d946ef]"></div><span>This reel</span></div>
            <div className="flex items-center space-x-1.5"><div className="w-2 h-2 rounded-full bg-[#8e8e93]"></div><span>Your typical reel views</span></div>
          </div>
        </div>

        {/* Top Sources of Views Section */}
        <div className="px-4 py-4 border-b border-zinc-800/80">
          <h2 className="text-[13px] font-semibold text-white mb-3 tracking-tight">Top sources of views</h2>
          <div className="space-y-3">
            {topSourcesBreakdown.map((item, idx) => (
              <div key={idx}>
                <div className="flex justify-between text-[11px] mb-1">
                  <span className="font-normal text-white">{item.label}</span>
                  <span className="font-normal text-white">{item.percent}%</span>
                </div>
                <div className="w-full bg-[#26262a] h-1.5 rounded-full overflow-hidden">
                  <div className="bg-[#d946ef] h-full rounded-full" style={{ width: `${item.percent}%` }}></div>
                </div>
              </div>
            ))}
            <div className="flex justify-between items-center text-[11px] pt-1">
              <span className="font-normal text-white">Viewers</span>
              <span className="font-normal text-white">1,168</span>
            </div>
          </div>
        </div>

        {/* Retention Section */}
        <div className="px-4 py-4 border-b border-zinc-800/80">
          <div className="flex items-center space-x-1.5 mb-2.5">
            <h2 className="text-[13px] font-semibold text-white tracking-tight">Retention</h2>
            <Info className="w-3.5 h-3.5 text-[#8e8e93] stroke-[2]" />
          </div>

          <div className="flex justify-center my-2.5">
            <div className="w-[95px] h-[165px] rounded-lg overflow-hidden bg-zinc-800 shadow-md border border-white/10 relative">
              <img src={config.reel.thumbnail} alt="Retention frame" className="w-full h-full object-cover" />
              <div className="absolute inset-0 flex items-center justify-center bg-black/20">
                <div className="w-6 h-6 rounded-full bg-black/70 flex items-center justify-center backdrop-blur-sm">
                  <Play className="w-3 h-3 text-white fill-white ml-0.5" />
                </div>
              </div>
            </div>
          </div>

          <div className="h-44 w-full mt-2 relative" onTouchEnd={() => setRetentionIndex(undefined)} onTouchCancel={() => setRetentionIndex(undefined)}>
            <ResponsiveContainer width="100%" height="100%">
              <LineChart 
                data={secondBySecondRetentionData} 
                margin={{ top: 28, right: 10, left: -30, bottom: 0 }}
                activeIndex={retentionIndex}
                onMouseMove={(state) => { if (state && state.activeTooltipIndex !== undefined) setRetentionIndex(state.activeTooltipIndex); }}
                onTouchMove={(state) => { if (state && state.activeTooltipIndex !== undefined) setRetentionIndex(state.activeTooltipIndex); }}
                onMouseLeave={() => setRetentionIndex(undefined)}
              >
                <CartesianGrid strokeDasharray="3 3" stroke="#26262a" vertical={false} />
                <XAxis dataKey="time" stroke="#8e8e93" fontSize={10} tickLine={false} axisLine={false} ticks={['0:00', config.reel.duration]} />
                <YAxis stroke="#8e8e93" fontSize={10} tickLine={false} axisLine={false} ticks={[0, 50, 100]} />
                <Tooltip 
                  isAnimationActive={false}
                  cursor={{ stroke: '#ffffff', strokeWidth: 1, strokeDasharray: 'none' }}
                  position={{ y: 0 }}
                  active={retentionIndex !== undefined}
                  content={({ active, payload }) => {
                    if (active && payload && payload.length) {
                      const data = payload[0].payload;
                      return (
                        <div className="transform -translate-x-1/2 pointer-events-none">
                          <div className="bg-[#1e1e22] text-white px-2.5 py-1 rounded-md text-[11px] shadow-2xl border border-white/10 flex flex-col items-center whitespace-nowrap">
                            <span className="font-semibold text-[11px]">{data.retention}%</span>
                            <span className="text-[#8e8e93] text-[9px]">{data.time}</span>
                          </div>
                        </div>
                      );
                    }
                    return null;
                  }} 
                />
                <Line type="monotone" dataKey="retention" stroke="#d946ef" strokeWidth={2} dot={false} activeDot={retentionIndex !== undefined ? { r: 4, fill: '#d946ef', stroke: '#fff', strokeWidth: 2 } : false} />
              </LineChart>
            </ResponsiveContainer>
          </div>

          <div className="space-y-2 mt-3 pt-2 border-t border-zinc-900">
            <div className="flex justify-between text-[11px]"><span className="font-normal text-white">This reel's skip rate</span><span className="font-normal text-white">4.0%</span></div>
            <div className="flex justify-between text-[11px]"><span className="font-normal text-white">Your typical skip rate</span><span className="font-normal text-white">0.7%</span></div>
          </div>
        </div>

        {/* Interactions & Donut Chart Section (Reads calculated totalInteractions and interactionSplitRatios) */}
        <div className="px-4 py-4 border-b border-zinc-800/80 flex flex-col items-center">
          <div className="w-full flex items-center justify-start space-x-1.5 mb-1.5">
            <h2 className="text-[13px] font-semibold text-white tracking-tight">Interactions</h2>
            <Info className="w-3.5 h-3.5 text-[#8e8e93] stroke-[2]" />
          </div>

          <InstagramDonutChart 
            followerRatio={interactionSplit.followersShare} 
            centerLabel="Interactions" 
            centerValue={totalInteractions.toString()} 
          />

          <div className="w-full space-y-2 mt-2 px-2">
            <div className="flex items-center justify-between text-[11px]">
              <div className="flex items-center space-x-2">
                <div className="w-2 h-2 rounded-full bg-[#DC38D1]"></div>
                <span className="font-normal text-white">Followers</span>
              </div>
              <span className="text-white font-normal">{(interactionSplit.followersShare * 100).toFixed(1)}%</span>
            </div>
            <div className="flex items-center justify-between text-[11px]">
              <div className="flex items-center space-x-2">
                <div className="w-2 h-2 rounded-full bg-[#7638FA]"></div>
                <span className="font-normal text-white">Non-followers</span>
              </div>
              <span className="text-white font-normal">{(interactionSplit.nonFollowersShare * 100).toFixed(1)}%</span>
            </div>
          </div>
        </div>

        {/* When People Liked Your Reel Section */}
        <div className="px-4 py-4 border-b border-zinc-800/80">
          <h2 className="text-[13px] font-semibold text-white mb-2.5 tracking-tight">When people liked your reel</h2>

          <div className="flex justify-center my-2.5">
            <div className="w-[95px] h-[165px] rounded-lg overflow-hidden bg-zinc-800 shadow-md border border-white/10 relative">
              <img src={config.reel.thumbnail} alt="Likes frame" className="w-full h-full object-cover" />
              <div className="absolute inset-0 flex items-center justify-center bg-black/20">
                <div className="w-6 h-6 rounded-full bg-black/70 flex items-center justify-center backdrop-blur-sm">
                  <Play className="w-3 h-3 text-white fill-white ml-0.5" />
                </div>
              </div>
            </div>
          </div>

          <div className="h-44 w-full mt-2 relative" onTouchEnd={() => setLikesIndex(undefined)} onTouchCancel={() => setLikesIndex(undefined)}>
            <ResponsiveContainer width="100%" height="100%">
              <LineChart 
                data={secondsWiseLikesData} 
                margin={{ top: 28, right: 10, left: -30, bottom: 0 }}
                activeIndex={likesIndex}
                onMouseMove={(state) => { if (state && state.activeTooltipIndex !== undefined) setLikesIndex(state.activeTooltipIndex); }}
                onTouchMove={(state) => { if (state && state.activeTooltipIndex !== undefined) setLikesIndex(state.activeTooltipIndex); }}
                onMouseLeave={() => setLikesIndex(undefined)}
              >
                <CartesianGrid strokeDasharray="3 3" stroke="#26262a" vertical={false} />
                <XAxis dataKey="time" stroke="#8e8e93" fontSize={10} tickLine={false} axisLine={false} ticks={['0:00', config.reel.duration]} />
                <YAxis 
                  stroke="#8e8e93" 
                  fontSize={10} 
                  tickLine={false} 
                  axisLine={false} 
                  domain={[0, dynamicLikesYMax]} 
                  ticks={[0, dynamicLikesYMax / 2, dynamicLikesYMax]} 
                />
                <Tooltip 
                  isAnimationActive={false}
                  cursor={{ stroke: '#ffffff', strokeWidth: 1, strokeDasharray: 'none' }}
                  position={{ y: 0 }}
                  active={likesIndex !== undefined}
                  content={({ active, payload }) => {
                    if (active && payload && payload.length) {
                      const data = payload[0].payload;
                      return (
                        <div className="transform -translate-x-1/2 pointer-events-none">
                          <div className="bg-[#1e1e22] text-white px-2.5 py-1 rounded-md text-[11px] shadow-2xl border border-white/10 flex flex-col items-center whitespace-nowrap">
                            <span className="font-semibold text-[11px]">{data.val}%</span>
                            <span className="text-[#8e8e93] text-[9px]">{data.time}</span>
                          </div>
                        </div>
                      );
                    }
                    return null;
                  }} 
                />
                <Line type="linear" dataKey="val" stroke="#d946ef" strokeWidth={2} dot={false} activeDot={likesIndex !== undefined ? { r: 4, fill: '#d946ef', stroke: '#fff', strokeWidth: 2 } : false} />
              </LineChart>
            </ResponsiveContainer>
          </div>

          <div className="space-y-3 mt-3 pt-2.5 border-t border-zinc-900">
            <div className="flex justify-between items-center text-[12px]"><span className="font-normal text-white">Likes</span><span className="font-normal text-white">{totalLikes}</span></div>
            <div className="flex justify-between items-center text-[12px]"><span className="font-normal text-white">Comments</span><span className="font-normal text-white">{totalComments}</span></div>
            <div className="flex justify-between items-center text-[12px]"><span className="font-normal text-white">Reposts</span><span className="font-normal text-white">{totalReposts}</span></div>
            <div className="flex justify-between items-center text-[12px]"><span className="font-normal text-white">Saves</span><span className="font-normal text-white">{totalSaves}</span></div>
            <div className="flex justify-between items-center text-[12px]"><span className="font-normal text-white">Shares</span><span className="font-normal text-white">{totalShares}</span></div>
          </div>
        </div>

        {/* Profile Activity Section */}
        <div className="px-4 py-4 border-b border-zinc-800/80">
          <div className="flex items-center space-x-1.5 mb-2.5">
            <h2 className="text-[13px] font-semibold text-white tracking-tight">Profile activity</h2>
            <Info className="w-3.5 h-3.5 text-[#8e8e93] stroke-[2]" />
          </div>
          <div className="flex justify-between items-center text-[12px]"><span className="font-normal text-white">Follows</span><span className="font-normal text-white">{totalFollows}</span></div>
        </div>

        {/* Audience Section */}
        <div className="px-4 py-4">
          <div className="flex items-center space-x-1.5 mb-2.5">
            <h2 className="text-[13px] font-semibold text-white tracking-tight">Audience</h2>
            <Info className="w-3.5 h-3.5 text-[#8e8e93] stroke-[2]" />
          </div>

          <div className="flex space-x-1.5 mb-3">
            {['Gender', 'Country', 'Age'].map((tab) => (
              <button
                key={tab}
                onClick={() => setAudienceTab(tab)}
                className={`px-3 py-1 rounded-full text-[11px] transition-all ${audienceTab === tab ? 'bg-white text-black font-semibold' : 'bg-[#26262a] text-white font-normal hover:bg-zinc-700'}`}
              >
                {tab}
              </button>
            ))}
          </div>

          {audienceTab === 'Gender' && (
            <div className="space-y-3">
              {genderBreakdown.map((item, idx) => (
                <div key={idx}>
                  <div className="flex justify-between text-[11px] mb-1"><span className="font-normal text-white">{item.label}</span><span className="font-normal text-white">{item.percent}%</span></div>
                  <div className="w-full bg-[#26262a] h-1.5 rounded-full overflow-hidden"><div className="bg-[#d946ef] h-full rounded-full" style={{ width: `${item.percent}%` }}></div></div>
                </div>
              ))}
            </div>
          )}

          {audienceTab === 'Country' && (
            <div className="space-y-3">
              {countryBreakdown.map((item, idx) => (
                <div key={idx}>
                  <div className="flex justify-between text-[11px] mb-1"><span className="font-normal text-white">{item.label}</span><span className="font-normal text-white">{item.percent}%</span></div>
                  <div className="w-full bg-[#26262a] h-1.5 rounded-full overflow-hidden"><div className="bg-[#d946ef] h-full rounded-full" style={{ width: `${item.percent}%` }}></div></div>
                </div>
              ))}
            </div>
          )}

          {audienceTab === 'Age' && (
            <div className="space-y-2.5">
              {ageBreakdown.map((item, idx) => (
                <div key={idx}>
                  <div className="flex justify-between text-[11px] mb-1"><span className="font-normal text-white">{item.label}</span><span className="font-normal text-white">{item.percent}%</span></div>
                  <div className="w-full bg-[#26262a] h-1.5 rounded-full overflow-hidden"><div className="bg-[#d946ef] h-full rounded-full" style={{ width: `${item.percent}%` }}></div></div>
                </div>
              ))}
            </div>
          )}

        </div>

      </div>
    </div>
  );
}
