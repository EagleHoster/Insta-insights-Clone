import express from 'express';
import { exec } from 'child_process';
import util from 'util';
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const execPromise = util.promisify(exec);
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
app.use(express.json());

const CACHE_FILE = path.join(__dirname, 'video_cache.json');

function loadCache() {
    if (!fs.existsSync(CACHE_FILE)) return {};
    try { return JSON.parse(fs.readFileSync(CACHE_FILE, 'utf8')); } catch { return {}; }
}

function saveCache(cache) {
    fs.writeFileSync(CACHE_FILE, JSON.stringify(cache, null, 2), 'utf8');
}

async function checkThumbnailValid(url) {
    try {
        const res = await fetch(url, { method: 'HEAD' });
        return res.ok;
    } catch {
        return false;
    }
}

app.post('/api/fetch-reel', async (req, res) => {
    const { videoUrl } = req.body;
    if (!videoUrl) return res.status(400).json({ error: 'Missing videoUrl' });

    const match = videoUrl.match(/(?:\/reel\/|\/p\/|\/tv\/)([a-zA-Z0-9_-]+)/);
    const vidId = match ? match[1] : videoUrl.trim();

    let cache = loadCache();
    if (cache[vidId]) {
        const isValid = await checkThumbnailValid(cache[vidId].thumbnail);
        if (isValid) {
            return res.json(cache[vidId]);
        } else {
            delete cache[vidId];
            saveCache(cache);
        }
    }

    const cmd = `instaloader --login=eagleshoster --no-videos --no-captions --no-compress-json --no-pictures --metadata-json -- -${vidId}`;

    try {
        // AWAIT makes Node completely wait until instaloader finishes downloading!
        await execPromise(cmd);

        const jsonDir = path.join(process.cwd(), `-${vidId}`);
        const files = fs.readdirSync(jsonDir);
        const jsonFile = files.find(f => f.endsWith('.json'));
        if (!jsonFile) throw new Error('Metadata JSON not found');

        const rawJson = fs.readFileSync(path.join(jsonDir, jsonFile), 'utf8');
        const parsed = JSON.parse(rawJson);
        const node = parsed.node;

        const fullCaption = node.caption?.text || '';
        const firstLine = fullCaption.split('\n')[0] || '';
        const truncatedCaption = firstLine.length > 50 ? firstLine.substring(0, 50) : firstLine;
        
        const data = {
            vidId,
            views: node.video_play_count || 0,
            likes: node.edge_media_preview_like?.count || 0,
            comments: node.edge_media_to_parent_comment?.count || 0,
            caption: truncatedCaption,
            thumbnail: node.display_url,
            videoDirectUrl: node.video_url || null
        };

        cache[vidId] = data;
        saveCache(cache);
        fs.rmSync(jsonDir, { recursive: true, force: true });

        res.json(data);
    } catch (err) {
        if (fs.existsSync(jsonDir)) {
            fs.rmSync(jsonDir, { recursive: true, force: true });
        }
        res.status(500).json({ error: err.message });
    }
});

app.listen(3001, () => {
    console.log('Backend server running on http://localhost:3001');
});
